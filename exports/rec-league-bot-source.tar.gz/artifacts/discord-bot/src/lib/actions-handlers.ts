/**
 * /actions hub — all member-facing interactions with prefix ac_
 * Session TTL: 15 minutes (keyed by `${guildId}:${userId}`)
 */
import {
  ButtonInteraction, StringSelectMenuInteraction, ModalSubmitInteraction,
  EmbedBuilder, Colors,
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder, StringSelectMenuOptionBuilder,
  ModalBuilder, TextInputBuilder, TextInputStyle,
  TextChannel, PermissionFlagsBits,
} from "discord.js";
import { db } from "@workspace/db";
import {
  usersTable, userSavingsTable, userRecordsTable, globalUserRecordsTable,
  franchiseRostersTable, franchiseMcaTeamsTable, seasonsTable,
  wagersTable, interviewRequestsTable, coinTransactionsTable,
  seasonStatsTable, teamSeasonStatsTable, purchasesTable, inventoryTable,
  legendsTable, franchiseScheduleTable,
  guildTweetsTable, autoPilotRequestsTable, ruleViolationsTable,
  playerEaIdsTable, customPlayersTable,
  playerSeasonStatsTable, waitlistTable, payoutConfigTable,
  seasonStatTierConfigsTable,
} from "@workspace/db";
import { eq, and, or, desc, asc, sql, isNotNull, isNull, ne, sum, max, inArray, notInArray } from "drizzle-orm";
import type { SQL } from "drizzle-orm";
import {
  getOrCreateUser, getOrCreateActiveSeason, getRosterSeasonId, getScheduleSeasonId, getPurchasedLegendIds,
  deductBalance, logTransaction, addBalance, getGuildChannel, CHANNEL_KEYS,
  getSeasonStats, getSeasonRules, getInventoryCount,
  getOrSeedRules, getAllSections, isAdminUser, getTeamLegendCount,
} from "./db-helpers.js";
import {
  getPayoutValue, getAllPayoutConfig, getMilestoneTiers, getAllPayoutKeys, PAYOUT_KEYS,
} from "./payout-config.js";
import { getServerSettings, requireMcaEnabled } from "./server-settings.js";
import { getArticleStandings, getSeasonRecords, getAllTimeRecords } from "./gcs-fallback.js";
import { devBadge, devBadgeText, DEV_LEGEND, DEV_EMOJI, DEV_TRAIT_LABELS } from "./dev-trait.js";
import { weekLabel } from "./week-helpers.js";
import {
  INTERVIEW_QUESTIONS, pickThreeIndices, getQuestionPool, interviewTypeLabel,
  type InterviewType,
} from "../commands/interviewrequest.js";
import { buildActionsHubEmbed, buildActionsHubRows, buildUnlinkedHubEmbed, buildUnlinkedHubRows } from "../commands/actions.js";
import { buildUserProfilePages, buildProfileNavRow, buildProfileBackRow } from "./user-stats-embed.js";
import { getSavingsInterestRateBps } from "./savings-interest.js";
import { PLAYOFF_WEEK_META } from "./playoff-matchups-runner.js";
import { buildRulesPages } from "./admin-operations-handlers.js";
import {
  insufficientFunds, sendCommissionerNotification, getRosterRows, DEV_LABEL,
} from "./purchase-shared.js";
import { ATTRIBUTES, NFL_TEAMS, NFL_DIVISION_MAP, LIMITS, lookupNflDivision, eaPortraitUrl, LEGEND_CUSTOM_PURCHASE_WEEKS } from "./constants.js";
import { STAT_CATEGORIES, STAT_TIER_DEFAULTS } from "./stat-categories.js";
import { createSession } from "./custom-player-session.js";


// ── Types ──────────────────────────────────────────────────────────────────────

type AnyInteraction = ButtonInteraction | StringSelectMenuInteraction | ModalSubmitInteraction;

interface ActionsSession {
  guildId: string;
  userId: string;
  flow?: string;
  // wager flow
  scheduleGameId?: string;
  wagerTeam?: string;
  wagerOpponentId?: string;
  wagerOpponentTeam?: string;
  wagerAmount?: number;
  wagerChallengerId?: string;
  wagerChallengerTeam?: string;
  wagerSpread?: number;
  wagerSide?: "home" | "away";
  wagerHomeTeam?: string;
  wagerAwayTeam?: string;
  wagerHomeDiscordId?: string;
  wagerAwayDiscordId?: string;
  // roster flow (legacy — purchase flow still uses these)
  selectedTeamId?: number;
  selectedTeamName?: string;
  // roster card / player-card flow
  rosterViewTeamId?: number;
  rosterViewTeamName?: string;
  rosterViewSource?: "my" | "any";
  rosterViewSeasonId?: number;
  rosterViewPosition?: string;
  rosterCardPlayerId?: number;
  rosterCardPage?: number;
  // purchase flow
  purchaseType?: string;
  rosterPosition?: string;
  selectedPlayerId?: number;
  selectedPlayerName?: string;
  selectedPlayerPos?: string;
  selectedPlayerDev?: number;
  selectedPlayerAge?: number;
  selectedLegendId?: number;
  selectedLegendName?: string;
  selectedLegendCost?: number;
  // training package flow
  trainingTier?: string;
  trainingGoal?: "speed" | "power" | "balanced" | "position";
  trainingPlayerId?: number;
  trainingPlayerName?: string;
  trainingPlayerPos?: string;
  trainingPlayerOvr?: number;
  // standings flow
  standingsConf?: "AFC" | "NFC" | "ALL";
  // rules view flow
  acRulesSection?: string;
  acRulesPage?: number;
  // team request / waitlist flow
  pendingTeamRequest?: string;
  // free agent player-card flow
  faPos?: string;
  faCardPlayerId?: number;
  faCardPage?: number;
  faSeasonId?: number;
  faDevFilters?: number[];   // multi-select: 0=normal,1=star,2=ss,3=xf (empty=all)
  faSortStack?: string[];    // ordered sort keys, priority = index 0 first (max 5)
  faSortPage?: number;       // current sort-button page (0=special, 1-5=attrs)
  faNameFilter?: string;
  // all-players browse/filter flow
  apPos?: string;
  apCardPlayerId?: number;
  apCardPage?: number;
  apSeasonId?: number;
  apNameFilter?: string;
  apDevFilters?: number[];   // multi-select: 0=normal,1=star,2=ss,3=xf (empty=all)
  apSortStack?: string[];    // ordered sort keys, priority = index 0 first (max 5)
  apSortPage?: number;       // current sort-button page (0=special, 1-5=attrs)
  expiresAt: number;
}

// ── Session store ──────────────────────────────────────────────────────────────

const sessions = new Map<string, ActionsSession>();
const SESSION_TTL_MS = 15 * 60 * 1000;

function sessionKey(guildId: string, userId: string) {
  return `${guildId}:${userId}`;
}

function getSession(guildId: string, userId: string): ActionsSession {
  const key = sessionKey(guildId, userId);
  const existing = sessions.get(key);
  if (existing && existing.expiresAt > Date.now()) return existing;
  const fresh: ActionsSession = { guildId, userId, expiresAt: Date.now() + SESSION_TTL_MS };
  sessions.set(key, fresh);
  return fresh;
}

function touchSession(sess: ActionsSession) {
  sess.expiresAt = Date.now() + SESSION_TTL_MS;
}

// ── Shared helpers ─────────────────────────────────────────────────────────────

function backToHubRow(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_hub").setLabel("← Back to Hub").setStyle(ButtonStyle.Secondary),
  );
}

function cancelRow(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_hub").setLabel("✖ Cancel").setStyle(ButtonStyle.Secondary),
  );
}

// Position groups for roster display (mirrors my-roster.ts)
const OFFENSE_GROUPS: { label: string; positions: string[] }[] = [
  { label: "Quarterback",    positions: ["QB"] },
  { label: "Running Back",   positions: ["HB", "FB"] },
  { label: "Wide Receiver",  positions: ["WR"] },
  { label: "Tight End",      positions: ["TE"] },
  { label: "Offensive Line", positions: ["LT", "LG", "C", "RG", "RT"] },
];
const DEFENSE_GROUPS: { label: string; positions: string[] }[] = [
  { label: "Defensive Line",  positions: ["LE", "RE", "DT", "DE", "LEDGE", "REDGE"] },
  { label: "MIKE Linebacker", positions: ["MLB", "MIKE"] },
  { label: "SAM Linebacker",  positions: ["LOLB", "SAM"] },
  { label: "WILL Linebacker", positions: ["ROLB", "WILL"] },
  { label: "Cornerback",      positions: ["CB"] },
  { label: "Safety",          positions: ["FS", "SS", "S"] },
];
const SPECIAL_TEAMS_POSITIONS = ["K", "P", "KR", "PR", "LS"];
const OFFENSE_SET = new Set(OFFENSE_GROUPS.flatMap(g => g.positions));
const DEFENSE_SET = new Set(DEFENSE_GROUPS.flatMap(g => g.positions));

// ── Roster card / player-card constants ────────────────────────────────────────

const ROSTER_CARD_POSITIONS = [
  "QB","HB","FB","WR","TE","LT","LG","C","RG","RT",
  "LEDGE","REDGE","DT","WILL","MIKE","SAM","CB","FS","SS","K","P","LS",
];

// Canonical sort order for all position dropdowns
const CANONICAL_POS_ORDER = ["QB","HB","FB","WR","TE","LT","LG","C","RG","RT","LEDGE","REDGE","DT","WILL","MIKE","SAM","CB","FS","SS","K","P","LS"];
const CANONICAL_POS_IDX   = new Map(CANONICAL_POS_ORDER.map((p, i) => [p, i]));
function sortByCanonical(positions: string[]): string[] {
  return [...positions].sort((a, b) => {
    const ai = CANONICAL_POS_IDX.get(a) ?? 999;
    const bi = CANONICAL_POS_IDX.get(b) ?? 999;
    return ai !== bi ? ai - bi : a.localeCompare(b);
  });
}

// ── Keys that are displayed elsewhere (page 1/bio) and should NOT appear on the attributes page ──
const ATTR_PAGE_SKIP = new Set([
  "height", "heightInches", "weight",
  "throwAcc", "throwAccuracy", "throwAccRating", "throwAccuracyRating",
  "handedness", "throwingHand", "playerHandedness",
  "college", "collegeName", "playerCollege",
  "conf", "confidence", "confRating", "confidenceRating", // shown on page 1 bio section
  // contract / financial — shown separately if non-zero, not in raw attr dump
  "desiredBonus", "contractBonus", "signingBonus", "contractSalary", "capHit",
]);

// ── Player trait system ────────────────────────────────────────────────────────
// Boolean traits: value 1 = Yes, value 0 = No (skip the 0s).
// Scale traits: map each numeric value to a label.
const BOOL_TRAIT_LABELS: Record<string, string> = {
  clutchTrait:        "Clutch",
  highMotorTrait:     "High Motor",
  dropOpenPassTrait:  "Drops Open Passes",
  yacTrait:           "YAC Em Up",
  sensePressTrait:    "Sense Pressure",
  bigGameTrait:       "Big Game",
  playBallTrait:      "Play Ball",
  tightSpiralTrait:   "Tight Spiral",
  coverBallTrait:     "Covers Ball",
  fightForYardsTrait: "Fight for Yards",
  heavyBallTrait:     "Heavy Ball",
  posFeetTrait:       "Positive Feet",
  catcherTrait:       "Possession Receiver",
  stripBallTrait:     "Strip Ball",
  fakeOutTrait:       "Fake Out",
  hunchbackTrait:     "Hunchback",
  dlBullRushTrait:    "DL Bull Rush",
  dlSpinTrait:        "DL Spin Move",
  dlSwimTrait:        "DL Swim Move",
};

const SCALE_TRAIT_LABELS: Record<string, string[]> = {
  penaltyTrait:   ["Disciplined", "Normal", "Penalty"],
  forcePassTrait: ["Paranoid",    "Ideal",  "Aggressive"],
  lBStyleTrait:   ["Balanced",    "Run Stop","Pass Rush"],
  qBStyleTrait:   ["Pocket",      "Scrambler","Balanced"],
};

function renderTraitSection(attrs: Record<string, number | string>): string | null {
  const active: string[] = [];
  for (const [k, v] of Object.entries(attrs)) {
    const num = Number(v);
    if (isNaN(num)) continue;

    if (BOOL_TRAIT_LABELS[k]) {
      if (num === 1) active.push(`✅ ${BOOL_TRAIT_LABELS[k]}`);
    } else if (SCALE_TRAIT_LABELS[k]) {
      const label = SCALE_TRAIT_LABELS[k]![num];
      if (label) active.push(`${SCALE_TRAIT_LABELS[k]!.join("/")} → **${label}**`);
    } else if (k.endsWith("Trait") || k.endsWith("trait")) {
      // Unknown trait — show label + value only when non-zero
      if (num !== 0) active.push(`${k.replace(/Trait$/, "").replace(/([A-Z])/g, " $1").trim()} **${num}**`);
    }
  }
  return active.length > 0 ? active.join("\n") : null;
}

const ATTR_ABBR: Record<string, string> = {
  // ── Full Rating-suffixed keys ────────────────────────────────────────────────
  speedRating: "SPD", accelerationRating: "ACC", agilityRating: "AGI",
  strengthRating: "STR", jumpingRating: "JMP", awareRating: "AWR",
  staminaRating: "STA", injuryRating: "INJ", toughnessRating: "TGH",
  throwPowerRating: "THP", throwAccuracyShortRating: "SAC", throwAccuracyMidRating: "MAC",
  throwAccuracyDeepRating: "DAC", throwOnRunRating: "TOR", throwUnderPressureRating: "TUP",
  breakSackRating: "BSK", playActionRating: "PAC",
  caryingRating: "CAR", carryingRating: "CAR", bCVisionRating: "BCV", ballCarrierVisionRating: "BCV",
  elusivenessRating: "ELU", breakTackleRating: "BTK", stiffArmRating: "SFA",
  spinMoveRating: "SPM", jukeMoveRating: "JKM", truckingRating: "TRK", changeOfDirectionRating: "COD",
  catchRating: "CTH", catchInTrafficRating: "CIT", spectacularCatchRating: "SPC",
  shortRouteRunRating: "SRR", medRouteRunRating: "MRR", deepRouteRunRating: "DRR", releaseRating: "RLS",
  passBlockRating: "PBK", runBlockRating: "RBK", impactBlockRating: "IBL",
  passBlockPowerRating: "PBP", passBlockFinesseRating: "PBF",
  runBlockPowerRating: "RBP", runBlockFinesseRating: "RBF", leadBlockRating: "LBK",
  powerMovesRating: "PMV", finessMovesRating: "FMV", blockShedRating: "BSH",
  pursuitRating: "PUR", tackleRating: "TAK", hitPowerRating: "HPW",
  manCoverRating: "MCV", zoneCoverRating: "ZCV", pressRating: "PRS", playRecRating: "PRC",
  kickPowerRating: "KPW", kickAccuracyRating: "KAC",
  puntPowerRating: "PNP", puntAccuracyRating: "PNA", kickReturnRating: "KR",
  // ── Abbreviated aliases (short form, no "Rating" suffix) ────────────────────
  accel: "ACC", jump: "JMP", tough: "TGH",
  bCV: "BCV", carry: "CAR",
  cIT: "CIT", routeRunDeep: "DRR", routeRunMed: "MRR", routeRunShort: "SRR", specCatch: "SPC",
  finesseMoves: "FMV",
  kickAcc: "KAC", kickRet: "KR", longSnap: "LSN",
  throwAccDeep: "DAC", throwAccMid: "MAC", throwAccShort: "SAC",
  truck: "TRK",
  conf: "CNF", confidence: "CNF",
  // ── Short-Rating hybrid variants (EA exports "accelRating" vs "accelerationRating") ──
  accelRating: "ACC", jumpRating: "JMP", toughRating: "TGH",
  bCVRating: "BCV", carryRating: "CAR",
  cITRating: "CIT", routeRunDeepRating: "DRR", routeRunMedRating: "MRR",
  routeRunShortRating: "SRR", specCatchRating: "SPC",
  finesseMovesRating: "FMV",  // also fixes the "finessMovesRating" typo variant already above
  kickAccRating: "KAC", kickRetRating: "KR", longSnapRating: "LSN",
  throwAccDeepRating: "DAC", throwAccMidRating: "MAC", throwAccShortRating: "SAC",
  truckRating: "TRK",
};

/**
 * Groups are defined by ABBREVIATION (not raw DB key).
 * We first convert every raw DB key → abbreviation using ATTR_ABBR,
 * then bucket by group using these abbr lists. This makes the display
 * robust regardless of whether the DB stores "speedRating" or "speed".
 */
const ATTR_GROUPS: { label: string; abbrs: string[] }[] = [
  { label: "⚡ Physical / Athletic", abbrs: ["SPD","ACC","AGI","STR","JMP","AWR","COD","STA","INJ","TGH"] },
  { label: "🏈 Throwing",            abbrs: ["THP","SAC","MAC","DAC","TOR","TUP","BSK","PAC"] },
  { label: "🏃 Ball Carrying",       abbrs: ["CAR","BCV","ELU","BTK","TRK","SFA","SPM","JKM","KR"] },
  { label: "🙌 Receiving",           abbrs: ["CTH","CIT","SPC","SRR","MRR","DRR","RLS"] },
  { label: "🛡️ Blocking",            abbrs: ["PBK","RBK","IBL","PBP","PBF","RBP","RBF","LBK"] },
  { label: "🔴 Pass Rush",           abbrs: ["PMV","FMV","BSH"] },
  { label: "💪 Run Defense",         abbrs: ["PUR","TAK","HPW"] },
  { label: "🔒 Coverage",            abbrs: ["MCV","ZCV","PRS","PRC"] },
  { label: "🦵 Kicking / Punting",   abbrs: ["KPW","KAC","PNP","PNA","LSN"] },
];

interface StatDef { key: string; label: string; isFloat?: boolean }
const STAT_SECTIONS: { title: string; stats: StatDef[] }[] = [
  { title: "🏈 Passing",   stats: [
    { key: "passYds", label: "Pass Yards" }, { key: "passTDs", label: "TDs" },
    { key: "passInts", label: "INTs" }, { key: "passComp", label: "Comp" },
    { key: "passAtt", label: "Att" }, { key: "timesSacked", label: "Sacked" },
  ]},
  { title: "🏃 Rushing",   stats: [
    { key: "rushYds", label: "Rush Yards" }, { key: "rushTDs", label: "TDs" },
    { key: "rushAtt", label: "Att" }, { key: "fumbles", label: "Fumbles" },
  ]},
  { title: "🙌 Receiving", stats: [
    { key: "recRec", label: "Receptions" }, { key: "recYds", label: "Rec Yards" }, { key: "recTDs", label: "TDs" },
  ]},
  { title: "🛡️ Defense",   stats: [
    { key: "totalTackles", label: "Tackles" }, { key: "tackleSolo", label: "Solo" },
    { key: "tackleAssist", label: "Assist" }, { key: "sacks", label: "Sacks", isFloat: true },
    { key: "defInts", label: "INTs" }, { key: "forcedFumbles", label: "FF" },
    { key: "defFumblesRec", label: "Fum Rec" }, { key: "tacklesForLoss", label: "TFLs", isFloat: true },
    { key: "defTDs", label: "Def TDs" },
  ]},
  { title: "🦵 Kicking",   stats: [
    { key: "fgMade", label: "FG Made" }, { key: "fgAtt", label: "FG Att" },
    { key: "fgLong", label: "FG Long" }, { key: "xpMade", label: "XP Made" }, { key: "xpAtt", label: "XP Att" },
  ]},
  { title: "💨 Punting",   stats: [
    { key: "puntAtt", label: "Punts" }, { key: "puntYds", label: "Yds" },
    { key: "puntLong", label: "Long" }, { key: "puntIn20", label: "In-20" }, { key: "puntTouchbacks", label: "TBs" },
  ]},
  { title: "↩️ Returns",   stats: [
    { key: "krYds", label: "KR Yds" }, { key: "krTDs", label: "KR TDs" }, { key: "krAtt", label: "KR Att" },
    { key: "prYds", label: "PR Yds" }, { key: "prTDs", label: "PR TDs" }, { key: "prAtt", label: "PR Att" },
  ]},
];

// ── Roster card — shared UI helpers ───────────────────────────────────────────

function buildRosterNavRows(source: "my" | "any"): ActionRowBuilder<ButtonBuilder>[] {
  const backId = source === "my" ? "ac_hub" : "ac_anyroster";
  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId("ac_rc_cards").setLabel("🃏 View Player Cards").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId("ac_rc_teamstats").setLabel("📊 View Team Stats").setStyle(ButtonStyle.Secondary),
    ),
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId(backId).setLabel("← Back").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
    ),
  ];
}

function buildCardPageRow(page: number, total: number): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`ac_rc_cardpage:${page - 1}`).setLabel("◀ Prev").setStyle(ButtonStyle.Secondary).setDisabled(page <= 1),
    new ButtonBuilder().setCustomId("ac_rc_cardpage_num").setLabel(`Page ${page} / ${total}`).setStyle(ButtonStyle.Secondary).setDisabled(true),
    new ButtonBuilder().setCustomId(`ac_rc_cardpage:${page + 1}`).setLabel("Next ▶").setStyle(ButtonStyle.Secondary).setDisabled(page >= total),
  );
}
function buildCardBackRow(): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_rc_back_to_players").setLabel("← Back to Players").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
  );
}

// ── Roster card — page builder ─────────────────────────────────────────────────

type RosterRow  = typeof franchiseRostersTable.$inferSelect;
type StatsRow   = typeof playerSeasonStatsTable.$inferSelect;

function buildPlayerCardPages(roster: RosterRow, stats: StatsRow | undefined, seasonNum: number): EmbedBuilder[] {
  const fullName  = `${roster.firstName} ${roster.lastName}`;
  const jersey    = roster.jerseyNum != null ? `#${roster.jerseyNum}` : "";
  const title     = `${fullName} — ${jersey} ${roster.position}`;
  const teamLine  = `**Team:** ${roster.teamName}`;
  const devLabel  = DEV_TRAIT_LABELS[roster.devTrait] ?? `Dev ${roster.devTrait}`;
  const devBadgeVal = devBadge(roster.devTrait ?? 0);
  const attrs     = (roster.attributes ?? {}) as Record<string, number | string>;
  const abilities = roster.abilities as { zone?: string; superstar?: string[] } | null;
  const TOTAL     = 3;
  const portrait  = roster.portraitUrl ?? eaPortraitUrl(roster.playerId);

  // ── Bio helpers ────────────────────────────────────────────────────────────
  const contractStr = roster.contractYearsLeft == null ? "Unknown"
    : roster.contractYearsLeft <= 0 ? "Free Agent"
    : roster.contractYearsLeft === 1 ? "Contract Year"
    : `${roster.contractYearsLeft} yrs remaining`;

  const rawH = attrs["height"] ?? attrs["heightInches"];
  const heightIn = rawH != null ? Number(rawH) : NaN;
  const heightStr = !isNaN(heightIn) && heightIn > 0 ? `${Math.floor(heightIn / 12)}'${heightIn % 12}"` : null;
  const rawW = attrs["weight"];
  const weightStr = rawW != null && Number(rawW) > 0 ? `${Number(rawW)} lbs` : null;
  const physLine = heightStr && weightStr ? `${heightStr} / ${weightStr}` : heightStr ?? weightStr ?? null;

  const rawCollege = attrs["college"] ?? attrs["collegeName"] ?? attrs["playerCollege"];
  const collegeStr = rawCollege != null && String(rawCollege).trim() !== "" ? String(rawCollege) : null;

  // ── Season stats helpers ───────────────────────────────────────────────────
  const statLines: { title: string; line: string }[] = [];
  if (stats) {
    for (const section of STAT_SECTIONS) {
      const parts = section.stats
        .filter(s => { const v = (stats as any)[s.key]; return v != null && v !== 0; })
        .map(s => {
          const v = (stats as any)[s.key] as number;
          return `**${s.label}:** ${s.isFloat ? v.toFixed(1) : v.toLocaleString()}`;
        });
      // Inject completion % directly into passing section
      if (section.title.includes("Pass") && stats.passAtt > 0) {
        const pct = ((stats.passComp / stats.passAtt) * 100).toFixed(1);
        parts.push(`**Pct:** ${pct}%`);
      }
      if (parts.length) statLines.push({ title: section.title, line: parts.join("  ·  ") });
    }
  }

  // ── Page 1: Bio + Season Stats ─────────────────────────────────────────────
  const p1 = new EmbedBuilder()
    .setColor(Colors.Blue)
    .setTitle(title)
    .setDescription(teamLine)
    .addFields(
      { name: "Overall",    value: String(roster.overall),                        inline: true },
      { name: "Age",        value: roster.age != null ? String(roster.age) : "—", inline: true },
      { name: "Jersey",     value: jersey || "—",                                  inline: true },
      { name: "Dev Trait",  value: devBadgeVal ? `${devBadgeVal} ${devLabel}` : devLabel, inline: true },
      { name: "Contract",   value: contractStr,                                    inline: true },
    );
  if (physLine)   p1.addFields({ name: "Height / Weight", value: physLine,   inline: true });
  if (collegeStr) p1.addFields({ name: "College",         value: collegeStr, inline: true });
  const rawConf = attrs["conf"] ?? attrs["confidence"];
  const confVal = rawConf != null ? Number(rawConf) : NaN;
  if (!isNaN(confVal) && confVal > 0) p1.addFields({ name: "🧠 Confidence", value: String(confVal), inline: true });
  const rawBonus = attrs["desiredBonus"] ?? attrs["contractBonus"] ?? attrs["signingBonus"];
  const bonusVal = rawBonus != null ? Number(rawBonus) : NaN;
  if (!isNaN(bonusVal) && bonusVal > 0) p1.addFields({ name: "💰 Desired Bonus", value: `$${bonusVal.toLocaleString()}`, inline: true });

  // Stats section on page 1
  if (statLines.length) {
    for (const { title: stTitle, line } of statLines) {
      p1.addFields({ name: stTitle, value: line, inline: false });
    }
  } else {
    p1.addFields({ name: "Season Stats", value: "*No stats recorded yet this season.*", inline: false });
  }
  p1.setFooter({ text: `Page 1/${TOTAL} · Season ${seasonNum} · ${roster.position} · ID ${roster.playerId}` });

  // ── Page 2: Abilities ─────────────────────────────────────────────────────
  const p2 = new EmbedBuilder()
    .setColor(Colors.Green)
    .setTitle(title)
    .setDescription(teamLine);

  const hasAbils = abilities && (abilities.zone || abilities.superstar?.length);
  if (hasAbils) {
    if (abilities.zone) {
      p2.addFields({ name: `${DEV_EMOJI.xfactor} X-Factor Zone Ability`, value: abilities.zone, inline: false });
    }
    if (abilities.superstar?.length) {
      const lines = abilities.superstar.map(a => `${DEV_EMOJI.superstar} ${a}`);
      p2.addFields({ name: "Superstar Abilities", value: lines.join("\n"), inline: false });
    }
  } else {
    p2.addFields({ name: "💥 Abilities", value: "*No active abilities.*", inline: false });
  }
  const traitText = renderTraitSection(attrs);
  p2.addFields({ name: "🧠 Traits", value: traitText ?? "*No active traits.*", inline: false });
  p2.setFooter({ text: `Page 2/${TOTAL} · Season ${seasonNum} · ${roster.position} · ID ${roster.playerId}` });

  // ── Page 3: In-Game Attributes ────────────────────────────────────────────
  const p3 = new EmbedBuilder()
    .setColor(0x2b2d31)
    .setTitle(title)
    .setDescription(teamLine);

  // ── Step 1: Build abbr→value map from raw attributes ─────────────────────
  // Convert every raw DB key to its abbreviation first, dedup by abbr.
  // This works regardless of whether the DB stores "speedRating", "speed", etc.
  // Skip trait fields — they are rendered on Page 2 instead.
  const isTraitKey = (k: string) => k.endsWith("Trait") || k.endsWith("trait");
  const abbrValMap = new Map<string, number>();
  for (const [rawKey, rawVal] of Object.entries(attrs)) {
    if (ATTR_PAGE_SKIP.has(rawKey)) continue;
    if (isTraitKey(rawKey)) continue;
    if (typeof rawVal !== "number") continue;
    const abbr = ATTR_ABBR[rawKey];
    if (abbr && !abbrValMap.has(abbr)) {
      abbrValMap.set(abbr, rawVal);
    }
  }

  // ── Step 2: Render by group using the abbr map ────────────────────────────
  let hasAnyAttr = false;
  const renderedAbbrs = new Set<string>();

  for (const group of ATTR_GROUPS) {
    const pairs: string[] = [];
    for (const abbr of group.abbrs) {
      const val = abbrValMap.get(abbr);
      if (val == null) continue;
      renderedAbbrs.add(abbr);
      pairs.push(`${abbr} **${val}**`);
    }
    if (pairs.length) {
      hasAnyAttr = true;
      p3.addFields({ name: group.label, value: pairs.join("  "), inline: false });
    }
  }

  // ── Step 3: Anything with an abbr not in any group goes to "Other" ────────
  const otherPairs: string[] = [];
  for (const [abbr, val] of abbrValMap) {
    if (!renderedAbbrs.has(abbr)) otherPairs.push(`${abbr} **${val}**`);
  }
  // Also show raw keys that had NO abbreviation entry (truly unknown attrs)
  // Skip trait keys (shown on Page 2) and zero-value entries (meaningless for unknown fields)
  for (const [rawKey, rawVal] of Object.entries(attrs)) {
    if (ATTR_PAGE_SKIP.has(rawKey)) continue;
    if (isTraitKey(rawKey)) continue;
    if (typeof rawVal !== "number") continue;
    if (rawVal === 0) continue;
    if (!ATTR_ABBR[rawKey]) otherPairs.push(`${rawKey.replace(/Rating$/, "")} **${rawVal}**`);
  }
  if (otherPairs.length) {
    hasAnyAttr = true;
    p3.addFields({ name: "📦 Other", value: otherPairs.slice(0, 20).join("  "), inline: false });
  }
  if (!hasAnyAttr) p3.addFields({ name: "Attributes", value: "*No attribute data available.*", inline: false });
  p3.setFooter({ text: `Page 3/${TOTAL} · Season ${seasonNum} · ${roster.position} · ID ${roster.playerId}` });

  if (portrait) p1.setThumbnail(portrait);

  return [p1, p2, p3];
}

// ── Roster card — shared team-stats embed builder ──────────────────────────────

function buildTeamStatsEmbed(
  teamName: string,
  seasonNum: number,
  statsRow: typeof teamSeasonStatsTable.$inferSelect,
): EmbedBuilder {
  const ppg    = statsRow.offPtsPerGame > 0 ? statsRow.offPtsPerGame.toFixed(1) : "N/A";
  const offPct = statsRow.offRedZonePct > 0 ? `${statsRow.offRedZonePct.toFixed(1)}%` : "N/A";
  const defPct = statsRow.defRedZonePct > 0 ? `${statsRow.defRedZonePct.toFixed(1)}%` : "N/A";
  return new EmbedBuilder()
    .setColor(Colors.Blue)
    .setTitle(`🏟️ ${teamName} — Season ${seasonNum} Stats`)
    .setDescription(`**Record: ${statsRow.wins}W-${statsRow.losses}L**`)
    .addFields(
      { name: "📤 Offense", value: `Pass: ${statsRow.offPassYds.toLocaleString()} yds\nRush: ${statsRow.offRushYds.toLocaleString()} yds\nTotal: ${statsRow.offYds.toLocaleString()} yds\nPts/Game: ${ppg}\nRed Zone%: ${offPct}`, inline: true },
      { name: "📥 Defense", value: `Pass Yds Allowed: ${statsRow.defPassYds.toLocaleString()}\nRush Yds Allowed: ${statsRow.defRushYds.toLocaleString()}\nSacks: ${statsRow.teamSacks}\nINTs: ${statsRow.teamInts}\nRZ% Allowed: ${defPct}`, inline: true },
      { name: "🔄 Turnovers", value: `Turnover Diff: **${statsRow.turnoverDiff >= 0 ? "+" : ""}${statsRow.turnoverDiff}**\nFumbles Rec: ${statsRow.defFumblesRec}`, inline: true },
    )
    .setTimestamp();
}

function formatPlayerLine(p: {
  firstName: string; lastName: string;
  position: string; overall: number; devTrait: number;
  jerseyNum: number | null; age: number | null;
  contractYearsLeft: number | null;
}): string {
  const num  = p.jerseyNum != null ? `#${p.jerseyNum} ` : "";
  const age  = p.age != null ? ` | Age ${p.age}` : "";
  const flag = p.contractYearsLeft === 1 ? " 📋" : "";
  return `${num}**${p.firstName} ${p.lastName}** (${p.position}) — OVR ${p.overall}${age}${devBadge(p.devTrait)}${flag}`;
}

function fieldChunks(label: string, lines: string[]): { name: string; value: string }[] {
  if (!lines.length) return [];
  const chunks: { name: string; value: string }[] = [];
  let cur: string[] = [], len = 0;
  for (const line of lines) {
    const add = (cur.length ? 1 : 0) + line.length;
    if (len + add > 1020 && cur.length) {
      chunks.push({ name: chunks.length === 0 ? label : `${label} (cont.)`, value: cur.join("\n") });
      cur = []; len = 0;
    }
    cur.push(line); len += add;
  }
  if (cur.length) chunks.push({ name: chunks.length === 0 ? label : `${label} (cont.)`, value: cur.join("\n") });
  return chunks;
}

async function buildRosterEmbed(guildId: string, seasonId: number, teamId: number, teamLabel: string, embed: EmbedBuilder) {
  const rows = await db.select({
    firstName: franchiseRostersTable.firstName,
    lastName:  franchiseRostersTable.lastName,
    position:  franchiseRostersTable.position,
    overall:   franchiseRostersTable.overall,
    devTrait:  franchiseRostersTable.devTrait,
    jerseyNum: franchiseRostersTable.jerseyNum,
    age:       franchiseRostersTable.age,
    contractYearsLeft: franchiseRostersTable.contractYearsLeft,
  }).from(franchiseRostersTable)
    .where(and(eq(franchiseRostersTable.seasonId, seasonId), eq(franchiseRostersTable.teamId, teamId)))
    .orderBy(franchiseRostersTable.overall);

  if (!rows.length) {
    embed.setDescription("No roster data found for this team. Make sure MCA data has been imported.");
    return embed;
  }

  const sorted = [...rows].sort((a, b) => (b.overall ?? 0) - (a.overall ?? 0));
  const offense = sorted.filter(p => OFFENSE_SET.has(p.position ?? ""));
  const defense = sorted.filter(p => DEFENSE_SET.has(p.position ?? ""));
  const special = sorted.filter(p => SPECIAL_TEAMS_POSITIONS.includes(p.position ?? ""));

  const addGroup = (group: { label: string; positions: string[] }, players: typeof sorted) => {
    const grpRows = group.positions.flatMap(pos =>
      players.filter(p => p.position?.toUpperCase() === pos).map(p => formatPlayerLine(p as any))
    );
    for (const chunk of fieldChunks(`⚡ ${group.label}`, grpRows)) {
      embed.addFields(chunk);
    }
  };

  embed.setTitle(`🏈 ${teamLabel} Roster`).setColor(Colors.Blue).setTimestamp();
  // Custom emojis only render in description/fields — not in footers
  embed.setDescription(DEV_LEGEND);
  embed.addFields({ name: "📤 Offense", value: "━━━━━━━━━━━", inline: false });
  for (const g of OFFENSE_GROUPS) addGroup(g, offense);
  embed.addFields({ name: "📥 Defense", value: "━━━━━━━━━━━", inline: false });
  for (const g of DEFENSE_GROUPS) addGroup(g, defense);
  if (special.length) {
    const lines = special.map(p => formatPlayerLine(p as any));
    for (const chunk of fieldChunks("🏟️ Special Teams", lines)) embed.addFields(chunk);
  }
  return embed;
}

// ── PR helpers (mirrors records.ts) ───────────────────────────────────────────

function calcPRScore(wins: number, losses: number, pointDiff: number): number {
  return 0.6 * (wins - losses) + 0.4 * pointDiff;
}
function ordinal(n: number): string {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return n + (s[(v - 20) % 10] ?? s[v] ?? s[0]!);
}
function fmtDiff(n: number): string { return n >= 0 ? `+${n}` : `${n}`; }

// ── Main dispatch ──────────────────────────────────────────────────────────────

export async function handleActionsInteraction(
  interaction: ButtonInteraction | StringSelectMenuInteraction | ModalSubmitInteraction,
): Promise<boolean> {
  const id  = interaction.customId;
  const gid = interaction.guildId;
  const uid = interaction.user.id;
  if (!gid) return false;

  const sess = getSession(gid, uid);
  touchSession(sess);

  // ── Close ────────────────────────────────────────────────────────────────────
  if (id === "ac_close") {
    await (interaction as ButtonInteraction).update({
      embeds: [new EmbedBuilder().setColor(Colors.DarkGrey).setDescription("✖ Hub closed.")],
      components: [],
    });
    return true;
  }

  // ── Hub restore ─────────────────────────────────────────────────────────────
  if (id === "ac_hub") {
    const btn = interaction as ButtonInteraction;
    await btn.deferUpdate();
    const [settings, member, user, season] = await Promise.all([
      getServerSettings(gid),
      btn.guild?.members.cache.get(uid) ?? btn.guild?.members.fetch(uid).catch(() => null),
      getOrCreateUser(uid, btn.user.username, gid),
      getOrCreateActiveSeason(gid),
    ]);
    const isDiscordAdmin = (member as import("discord.js").GuildMember | null | undefined)?.permissions?.has(PermissionFlagsBits.Administrator) ?? false;
    const isDbAdmin      = await isAdminUser(uid, gid);
    const isAdmin        = isDiscordAdmin || isDbAdmin;
    const seasonNum      = season.seasonNumber;
    const wkStr          = weekLabel(season.currentWeek);

    if (!user.team && !isAdmin) {
      await btn.editReply({ embeds: [buildUnlinkedHubEmbed(seasonNum, wkStr)], components: buildUnlinkedHubRows() });
      return true;
    }

    await btn.editReply({
      embeds:     [buildActionsHubEmbed(settings, isAdmin, seasonNum, wkStr)],
      components: buildActionsHubRows(settings, isAdmin),
    });
    return true;
  }

  // ── My Profile (page 1) ──────────────────────────────────────────────────────
  if (id === "ac_myprofile" || id === "ac_profile_p1" || id === "ac_profile_p2" || id === "ac_profile_p3") {
    const btn = interaction as ButtonInteraction;
    await btn.deferUpdate();
    const page: 1 | 2 | 3 = id === "ac_profile_p2" ? 2 : id === "ac_profile_p3" ? 3 : 1;
    const [settings, user, season] = await Promise.all([
      getServerSettings(gid),
      getOrCreateUser(uid, btn.user.username, gid),
      getOrCreateActiveSeason(gid),
    ]);
    const rules = await getSeasonRules(season);
    const pages = await buildUserProfilePages(
      uid, gid, user, season, settings, rules,
      btn.user.displayAvatarURL(),
      (btn.member as import("discord.js").GuildMember | null)?.nickname ?? btn.user.displayName ?? btn.user.username,
    );
    await btn.editReply({
      embeds:     [pages[page - 1]],
      components: [buildProfileNavRow(page), buildProfileBackRow()],
    });
    return true;
  }

  // ── Row 1: Economy & Social ─────────────────────────────────────────────────

  if (id === "ac_purchase")     { await handlePurchaseMenu(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_wager")        { await handleWagerStart(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_coins")        { await handleCoins(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_interview")    { await handleInterview(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_tweet")        { await handleTweetModal(interaction as ButtonInteraction); return true; }

  // Purchase sub-buttons
  if (id === "ac_buy_agereset") { await handleBuyAgeResetPosPick(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_buy_devup")    { await handleBuyDevUpPosPick(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_buy_legend")   { await handleBuyLegendPick(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_buy_custom")   { await handleBuyCustomInfo(interaction as ButtonInteraction); return true; }
  if (id.startsWith("ac_buy_arpos:"))       { await handleBuyARPlayerPick(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id.startsWith("ac_buy_dupos:"))       { await handleBuyDUPlayerPick(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id.startsWith("ac_buy_arplayer:"))    { await handleBuyARConfirm(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id.startsWith("ac_buy_duplayer:"))    { await handleBuyDUConfirm(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id === "ac_buy_ar_confirm")           { await handleBuyAgeResetExecute(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_buy_du_confirm")           { await handleBuyDevUpExecute(interaction as ButtonInteraction, sess); return true; }
  if (id.startsWith("ac_buy_legendpos:"))   { await handleBuyLegendPositionPick(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id.startsWith("ac_buy_legendsel:"))   { await handleBuyLegendConfirm(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id === "ac_buy_legend_confirm")       { await handleBuyLegendExecute(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_buy_training")               { await handleBuyTrainingPosPick(interaction as ButtonInteraction, sess); return true; }
  if (id.startsWith("ac_buy_trainingpos:"))   { await handleBuyTrainingPlayerPick(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id.startsWith("ac_buy_trainingplayer:")) { await handleBuyTrainingTierPick(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id.startsWith("ac_buy_training_tier:")) {
    const tier = id.split(":")[1] as TrainingTier;
    if (tier in TRAINING_TIERS) { await handleBuyTrainingGoalPick(interaction as ButtonInteraction, sess, tier); return true; }
  }
  if (id.startsWith("ac_buy_training_goal:"))  { await handleBuyTrainingConfirm(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id === "ac_buy_training_execute")        { await handleBuyTrainingExecute(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_buy_contract_ext")  { await handleBuyContractModPosPick(interaction as ButtonInteraction, sess, "contract_extension"); return true; }
  if (id === "ac_buy_salary_red")    { await handleBuyContractModPosPick(interaction as ButtonInteraction, sess, "salary_reduction"); return true; }
  if (id === "ac_buy_bonus_red")     { await handleBuyContractModPosPick(interaction as ButtonInteraction, sess, "bonus_reduction"); return true; }
  if (id.startsWith("ac_buy_cmpos:"))  { await handleBuyContractModPlayerPick(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id.startsWith("ac_buy_cmpick:")) { await handleBuyContractModConfirm(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id === "ac_buy_cm_confirm")      { await handleBuyContractModExecute(interaction as ButtonInteraction, sess); return true; }

  // Coins sub
  if (id === "ac_send_coins_modal")             { await handleSendCoinsModal(interaction as ButtonInteraction); return true; }
  if (id === "ac_transfer")                     { await handleBankTransfer(interaction as ButtonInteraction, sess); return true; }
  if (id.startsWith("ac_transfer_dir:"))        { await handleBankTransferDir(interaction as ButtonInteraction); return true; }

  // Wager sub
  if (id === "ac_wager_game")                  { await handleWagerGameSelect(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id.startsWith("ac_wager_pick:"))         { await handleWagerTeamPick(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_wager_spread")                { await handleWagerSpreadSelect(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id === "ac_wager_spread_next")           { await handleWagerSpreadNext(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_wager_back_to_team")          { await handleWagerBackToTeam(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_wager_back_to_spread")        { await handleWagerBackToSpread(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_wager_opponent_afc")          { await handleWagerOpponentSelect(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id === "ac_wager_opponent_nfc")          { await handleWagerOpponentSelect(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id === "ac_wager_send")                  { await handleWagerSend(interaction as ButtonInteraction, sess); return true; }

  // ── Row 2: Rosters ───────────────────────────────────────────────────────────

  if (id === "ac_myroster")       { await handleMyRoster(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_anyroster")      { await handleAnyRosterTeamPick(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_anyroster_sel_afc" || id === "ac_anyroster_sel_nfc" || id === "ac_anyroster_sel") { await handleAnyRosterShow(interaction as StringSelectMenuInteraction, sess); return true; }
  // Roster card — player cards + team stats from within roster view
  if (id === "ac_rc_cards")          { await handleRcPosPick(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_rc_possel")         { await handleRcPosSel(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id === "ac_rc_playersel")      { await handleRcPlayerSel(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id.startsWith("ac_rc_cardpage:")) { await handleRcCardPage(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_rc_back_to_players")  { await handleRcBackToPlayers(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_rc_teamstats")        { await handleRcTeamStats(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_rc_back_to_roster")   { await handleRcBackToRoster(interaction as ButtonInteraction, sess); return true; }
  // Free Agents — now launched from Rosters screen
  if (id === "ac_freeagents")            { await handleFreeAgentsPosPick(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_fa_pos")                { await handleFaPosSel(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id === "ac_fa_player")             { await handleFaPlayerSel(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id.startsWith("ac_fa_cardpage:"))  { await handleFaCardPage(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_fa_back_to_players")    { await handleFaBackToPlayers(interaction as ButtonInteraction, sess); return true; }
  // All Players
  if (id === "ac_allplayers")            { await handleAllPlayersPosPick(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_ap_pos")                { await handleAllPlayersPosSel(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id === "ac_ap_player")             { await handleApPlayerSel(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id.startsWith("ac_ap_cardpage:"))  { await handleApCardPage(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_ap_back_to_players")    { await handleApBackToPlayers(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_ap_filter")             { await handleApFilterScreen(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_ap_filter_apply")       { await handleApFilterApply(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_ap_filter_clear")       { await handleApFilterClear(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_ap_filter_name")        { await handleApFilterNameModal(interaction as ButtonInteraction); return true; }
  if (id === "ac_modal_ap_name")         { await handleApFilterNameSubmit(interaction as ModalSubmitInteraction, sess); return true; }
  if (id === "ac_ap_sprev")              { await handleApSortPage(interaction as ButtonInteraction, sess, "prev"); return true; }
  if (id === "ac_ap_snext")              { await handleApSortPage(interaction as ButtonInteraction, sess, "next"); return true; }
  if (id === "ac_ap_sort_clear")         { await handleApSortClear(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_ap_dev_clear")          { await handleApDevClear(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_ap_spage_lbl")          { return true; } // disabled display button
  if (id.startsWith("ac_ap_stog|"))      { await handleApSortToggle(interaction as ButtonInteraction, sess, id.slice("ac_ap_stog|".length)); return true; }
  if (id.startsWith("ac_ap_dtog|"))      { await handleApDevToggle(interaction as ButtonInteraction, sess, Number(id.slice("ac_ap_dtog|".length))); return true; }
  // FA Filter
  if (id === "ac_fa_filter")             { await handleFaFilterScreen(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_fa_filter_apply")       { await handleFaFilterApply(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_fa_filter_clear")       { await handleFaFilterClear(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_fa_filter_name")        { await handleFaFilterNameModal(interaction as ButtonInteraction); return true; }
  if (id === "ac_modal_fa_name")         { await handleFaFilterNameSubmit(interaction as ModalSubmitInteraction, sess); return true; }
  if (id === "ac_fa_sprev")              { await handleFaSortPage(interaction as ButtonInteraction, sess, "prev"); return true; }
  if (id === "ac_fa_snext")              { await handleFaSortPage(interaction as ButtonInteraction, sess, "next"); return true; }
  if (id === "ac_fa_sort_clear")         { await handleFaSortClear(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_fa_dev_clear")          { await handleFaDevClear(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_fa_spage_lbl")          { return true; } // disabled display button
  if (id.startsWith("ac_fa_stog|"))      { await handleFaSortToggle(interaction as ButtonInteraction, sess, id.slice("ac_fa_stog|".length)); return true; }
  if (id.startsWith("ac_fa_dtog|"))      { await handleFaDevToggle(interaction as ButtonInteraction, sess, Number(id.slice("ac_fa_dtog|".length))); return true; }
  if (id === "ac_teamstats")             { await handleTeamStatsTeamPick(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_teamstats_sel")         { await handleTeamStatsShow(interaction as StringSelectMenuInteraction, sess); return true; }

  // ── Row 3: League Info ───────────────────────────────────────────────────────

  if (id === "ac_standings")    { await handleStandingsConfPick(interaction as ButtonInteraction, sess); return true; }
  if (id.startsWith("ac_standings_conf:"))   { await handleStandingsShow(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_inthehunt")    { await handleInTheHunt(interaction as ButtonInteraction, sess);    return true; }
  if (id === "ac_teamstowatch") { await handleTeamsToWatch(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_anyuserstats")         { await handleAnyUserStatsTeamPick(interaction as ButtonInteraction, sess); return true; }
  if (id.startsWith("ac_anyus_conf:")) { await handleAnyUserStatsConfPick(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_anyus_sel")            { await handleAnyUserStatsShow(interaction as StringSelectMenuInteraction, sess); return true; }

  // ── Row 4: Rankings & Payouts ────────────────────────────────────────────────

  if (id === "ac_seasonpr")     { await handleSeasonPR(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_alltimepr")    { await handleAllTimePR(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_globalpr")     { await handleGlobalPR(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_weeklypayouts")    { await handleWeeklyPayouts(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_eospayouts")   { await handleEosPayouts(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_milestonepayouts") { await handleMilestonePayouts(interaction as ButtonInteraction, sess); return true; }

  // ── Row 5: Requests ──────────────────────────────────────────────────────────

  if (id === "ac_activeteams")  { await handleActiveTeams(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_openteams")    { await handleOpenTeams(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_schedule")     { await handleSchedule(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_autopilot")    { await handleAutoPilotModal(interaction as ButtonInteraction); return true; }
  if (id === "ac_rules")        { await handleRulesStart(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_rules_section")         { await handleRulesSection(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id.startsWith("ac_rules_page:"))   { await handleRulesPage(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_rules_goback")          { await handleRulesStart(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_rules_display")         { await handleRulesDisplayChoice(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_rules_display_full")    { await handleRulesDisplayFull(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_rules_display_bynum")   { await handleRulesDisplayByNumModal(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_rules_close")           { await handleRulesClose(interaction as ButtonInteraction); return true; }
  if (id === "ac_modal_rules_bynum")     { await handleRulesByNumSubmit(interaction as ModalSubmitInteraction, sess); return true; }
  if (id === "ac_violation")         { await handleViolationModal(interaction as ButtonInteraction); return true; }
  if (id === "ac_req_openteam")          { await handleReqOpenTeam(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_req_openteam_sel_afc" ||
      id === "ac_req_openteam_sel_nfc")  { await handleReqOpenTeamSel(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id === "ac_req_openteam_submit")   { await handleReqOpenTeamSubmit(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_req_addwaitlist")       { await handleReqAddWaitlist(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_req_waitlist_sel_afc" ||
      id === "ac_req_waitlist_sel_nfc")  { await handleReqWaitlistSel(interaction as StringSelectMenuInteraction, sess); return true; }
  if (id === "ac_req_waitlist_next")     { await handleReqWaitlistNext(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_req_rmwaitlist")        { await handleReqRmWaitlist(interaction as ButtonInteraction, sess); return true; }
  if (id === "ac_req_rmwl_confirm")      { await handleReqRmWaitlistConfirm(interaction as ButtonInteraction, sess); return true; }

  // Modal submits
  if (id === "ac_modal_tweet")      { await handleTweetSubmit(interaction as ModalSubmitInteraction, sess); return true; }
  if (id === "ac_modal_sendcoins")              { await handleSendCoinsSubmit(interaction as ModalSubmitInteraction, sess); return true; }
  if (id.startsWith("ac_modal_transfer:"))      { await handleBankTransferSubmit(interaction as ModalSubmitInteraction); return true; }
  if (id === "ac_modal_wageramount") { await handleWagerAmountSubmit(interaction as ModalSubmitInteraction, sess); return true; }
  if (id === "ac_modal_autopilot")  { await handleAutoPilotSubmit(interaction as ModalSubmitInteraction, sess); return true; }
  if (id === "ac_modal_violation")  { await handleViolationSubmit(interaction as ModalSubmitInteraction, sess); return true; }

  // Commissioner autopilot approve/deny
  if (id.startsWith("ac_ap_approve:")) { await handleApproveAutoPilot(interaction as ButtonInteraction); return true; }
  if (id.startsWith("ac_ap_deny:"))    { await handleDenyAutoPilot(interaction as ButtonInteraction); return true; }
  if (id.startsWith("ac_rv_note:"))         { await handleViolationNote(interaction as ButtonInteraction); return true; }
  if (id.startsWith("ac_rv_approve:"))      { await handleViolationApprove(interaction as ButtonInteraction); return true; }
  if (id.startsWith("ac_rv_deny:"))         { await handleViolationDeny(interaction as ButtonInteraction); return true; }
  if (id.startsWith("ac_rv_deny_submit:"))  { await handleViolationDenySubmit(interaction as ModalSubmitInteraction); return true; }

  return false;
}

// ═══════════════════════════════════════════════════════════════════════════════
//  ROW 1 — Economy & Social
// ═══════════════════════════════════════════════════════════════════════════════

async function handlePurchaseMenu(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  const settings = await getServerSettings(gid);

  const trainingOn  = settings.coinEconomy;
  const ageOn       = settings.coinEconomy && settings.ageResetsEnabled;
  const devOn       = settings.coinEconomy && settings.devUpgradesEnabled;
  const customOn    = settings.coinEconomy && settings.customSuperstarsEnabled;
  const legOn       = settings.coinEconomy && settings.legendsEnabled;
  const contractOn  = settings.coinEconomy && (settings.contractExtensionsEnabled ?? false);
  const salaryOn    = settings.coinEconomy && (settings.salaryReductionsEnabled ?? false);
  const bonusOn     = settings.coinEconomy && (settings.bonusReductionsEnabled ?? false);

  const allButtons: ButtonBuilder[] = [];
  if (trainingOn)  allButtons.push(new ButtonBuilder().setCustomId("ac_buy_training").setLabel("🎓 Training Package").setStyle(ButtonStyle.Primary));
  if (ageOn)      allButtons.push(new ButtonBuilder().setCustomId("ac_buy_agereset").setLabel("🔄 Age Reset").setStyle(ButtonStyle.Primary));
  if (devOn)      allButtons.push(new ButtonBuilder().setCustomId("ac_buy_devup").setLabel("📈 Dev Trait Upgrade").setStyle(ButtonStyle.Primary));
  if (customOn)   allButtons.push(new ButtonBuilder().setCustomId("ac_buy_custom").setLabel("🎨 Custom Player").setStyle(ButtonStyle.Success));
  if (legOn)      allButtons.push(new ButtonBuilder().setCustomId("ac_buy_legend").setLabel("🏆 Buy a Legend").setStyle(ButtonStyle.Success));
  if (contractOn) allButtons.push(new ButtonBuilder().setCustomId("ac_buy_contract_ext").setLabel("📋 Contract Extension").setStyle(ButtonStyle.Secondary));
  if (salaryOn)   allButtons.push(new ButtonBuilder().setCustomId("ac_buy_salary_red").setLabel("💵 Salary Reduction").setStyle(ButtonStyle.Secondary));
  if (bonusOn)    allButtons.push(new ButtonBuilder().setCustomId("ac_buy_bonus_red").setLabel("🎁 Bonus Reduction").setStyle(ButtonStyle.Secondary));

  const rows: ActionRowBuilder<ButtonBuilder>[] = [];
  for (let i = 0; i < allButtons.length; i += 5) {
    rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(...allButtons.slice(i, i + 5)));
  }
  rows.push(cancelRow());

  const embed = new EmbedBuilder()
    .setColor(0x1a1a2e)
    .setTitle("💳 Make a Purchase")
    .setDescription(
      allButtons.length === 0
        ? "❌ No purchase types are currently enabled. Please contact a commissioner."
        : "Select a purchase type below."
    )
    .setTimestamp();

  await interaction.update({ embeds: [embed], components: rows });
}

// ── Age Reset ─────────────────────────────────────────────────────────────────

async function handleBuyAgeResetPosPick(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  const seasonId = await getRosterSeasonId(gid);
  sess.purchaseType = "agereset";

  const rows = await getRosterRows(interaction as any, seasonId, { position: franchiseRostersTable.position });
  const positions = sortByCanonical([...new Set(rows.map((r: any) => r.position as string).filter(Boolean))]);

  if (!positions.length) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ No roster data found.")], components: [backToHubRow()] });
    return;
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_buy_arpos:")
    .setPlaceholder("Select position…")
    .addOptions(positions.slice(0, 25).map(p => new StringSelectMenuOptionBuilder().setLabel(p).setValue(p)));

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Orange).setTitle("🔄 Age Reset — Step 1").setDescription("Pick the **position** of the player whose age you want to reset.")],
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu), cancelRow()],
  });
}

async function handleBuyARPlayerPick(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const position = interaction.values[0]!;
  const gid = interaction.guildId!;
  const seasonId = await getRosterSeasonId(gid);

  const rows = await getRosterRows(interaction as any, seasonId, {
    playerId: franchiseRostersTable.playerId,
    firstName: franchiseRostersTable.firstName,
    lastName: franchiseRostersTable.lastName,
    overall: franchiseRostersTable.overall,
    age: franchiseRostersTable.age,
    position: franchiseRostersTable.position,
  });
  const filtered = (rows as any[]).filter(r => r.position?.toUpperCase() === position.toUpperCase());

  if (!filtered.length) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ No players at ${position}.`)], components: [backToHubRow()] });
    return;
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_buy_arplayer:")
    .setPlaceholder("Select player…")
    .addOptions(
      filtered.slice(0, 25).map(r =>
        new StringSelectMenuOptionBuilder()
          .setLabel(`${r.firstName} ${r.lastName} — Age ${r.age ?? "?"} | OVR ${r.overall}`)
          .setValue(String(r.playerId)),
      ),
    );

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Orange).setTitle("🔄 Age Reset — Step 2").setDescription(`Position: **${position}** — Select the player.`)],
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu), cancelRow()],
  });
}

async function handleBuyARConfirm(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const playerId = Number(interaction.values[0]);
  const gid = interaction.guildId!;
  const seasonId = await getRosterSeasonId(gid);

  const rows = await db.select({
    firstName: franchiseRostersTable.firstName,
    lastName:  franchiseRostersTable.lastName,
    age:       franchiseRostersTable.age,
    position:  franchiseRostersTable.position,
    playerId:  franchiseRostersTable.playerId,
  }).from(franchiseRostersTable)
    .where(and(eq(franchiseRostersTable.seasonId, seasonId), eq(franchiseRostersTable.playerId, playerId)))
    .limit(1);

  if (!rows.length) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Player not found.")], components: [backToHubRow()] });
    return;
  }

  const player = rows[0]!;
  sess.selectedPlayerId = playerId;
  sess.selectedPlayerName = `${player.firstName} ${player.lastName}`.trim();
  sess.selectedPlayerPos  = player.position ?? "";
  sess.selectedPlayerAge  = player.age ?? 0;

  const arSeason = await getOrCreateActiveSeason(gid);
  const [rules, user] = await Promise.all([
    getSeasonRules(arSeason),
    getOrCreateUser(interaction.user.id, interaction.user.username, gid),
  ]);
  const cost = rules?.ageResetCost ?? 500;

  const embed = new EmbedBuilder()
    .setColor(Colors.Orange)
    .setTitle("🔄 Confirm Age Reset")
    .setDescription(
      `**${sess.selectedPlayerName}** (${sess.selectedPlayerPos}) — Current Age: **${player.age ?? "?"}**\n\n` +
      `Cost: **${cost.toLocaleString()} coins**\nYour balance: **${user.balance.toLocaleString()} coins**`
    );

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_buy_ar_confirm").setLabel("✅ Confirm Reset").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId("ac_hub").setLabel("✖ Cancel").setStyle(ButtonStyle.Secondary),
  );

  await interaction.update({ embeds: [embed], components: [row] });
}

async function handleBuyAgeResetExecute(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  if (!sess.selectedPlayerId || !sess.selectedPlayerName) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Session expired. Please start over.")], components: [backToHubRow()] });
    return;
  }

  const season = await getOrCreateActiveSeason(gid);
  const [rules, user, seasonStats] = await Promise.all([
    getSeasonRules(season),
    getOrCreateUser(interaction.user.id, interaction.user.username, gid),
    getSeasonStats(interaction.user.id, season.id),
  ]);

  const cost      = rules?.ageResetCost ?? 500;
  const maxResets = rules?.ageResetsCap ?? 2;
  const used      = seasonStats?.ageResetsPurchased ?? 0;

  if (used >= maxResets) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ You have used all ${maxResets} age resets this season.`)], components: [backToHubRow()] });
    return;
  }
  if (user.balance < cost) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ Insufficient coins. You need **${cost.toLocaleString()}** but only have **${user.balance.toLocaleString()}**.`)], components: [backToHubRow()] });
    return;
  }

  await deductBalance(interaction.user.id, cost, gid);
  await logTransaction(interaction.user.id, -cost, "purchase", `Age reset — ${sess.selectedPlayerName}`, gid);

  const [inserted] = await db.insert(purchasesTable).values({
    discordId: interaction.user.id,
    seasonId: season.id,
    purchaseType: "age_reset",
    playerName: sess.selectedPlayerName,
    playerPosition: sess.selectedPlayerPos ?? "",
    cost,
    status: "pending",
    notes: `Age reset for ${sess.selectedPlayerName} (age ${sess.selectedPlayerAge} → 23)`,
  }).returning({ id: purchasesTable.id });

  await sendCommissionerNotification(interaction as any, "age_reset", inserted!.id, {
    playerName:   sess.selectedPlayerName,
    playerPosition: sess.selectedPlayerPos ?? "",
    currentAge:   sess.selectedPlayerAge,
    costPer:      cost,
  });

  await interaction.update({
    embeds: [new EmbedBuilder()
      .setColor(Colors.Yellow)
      .setTitle("⏳ Age Reset Submitted")
      .setDescription(`Your age reset for **${sess.selectedPlayerName}** has been submitted for commissioner approval.\nCost: **${cost.toLocaleString()} coins** deducted.`)],
    components: [backToHubRow()],
  });
}

// ── Contract / Salary / Bonus Mod Purchases ───────────────────────────────────

type ContractModType = "contract_extension" | "salary_reduction" | "bonus_reduction";

const CM_LABEL: Record<ContractModType, string> = {
  contract_extension: "Contract Extension",
  salary_reduction:   "Salary Reduction",
  bonus_reduction:    "Bonus Reduction",
};
const CM_EMOJI: Record<ContractModType, string> = {
  contract_extension: "📋",
  salary_reduction:   "💵",
  bonus_reduction:    "🎁",
};

async function handleBuyContractModPosPick(
  interaction: ButtonInteraction,
  sess: ActionsSession,
  type: ContractModType,
) {
  const gid      = interaction.guildId!;
  const seasonId = await getRosterSeasonId(gid);
  sess.purchaseType = type;

  const rows = await getRosterRows(interaction as any, seasonId, { position: franchiseRostersTable.position });
  const positions = sortByCanonical([...new Set(rows.map((r: any) => r.position as string).filter(Boolean))]);

  if (!positions.length) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ No roster data found.")], components: [backToHubRow()] });
    return;
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_buy_cmpos:")
    .setPlaceholder("Select your player's position…")
    .addOptions(positions.slice(0, 25).map(p => new StringSelectMenuOptionBuilder().setLabel(p).setValue(p)));

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Blue)
      .setTitle(`${CM_EMOJI[type]} ${CM_LABEL[type]} — Step 1`)
      .setDescription("Pick the **position** of the player.")],
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu), cancelRow()],
  });
}

async function handleBuyContractModPlayerPick(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const position = interaction.values[0]!;
  const gid      = interaction.guildId!;
  const seasonId = await getRosterSeasonId(gid);
  const type     = (sess.purchaseType ?? "contract_extension") as ContractModType;

  const rows = await getRosterRows(interaction as any, seasonId, {
    playerId:  franchiseRostersTable.playerId,
    firstName: franchiseRostersTable.firstName,
    lastName:  franchiseRostersTable.lastName,
    overall:   franchiseRostersTable.overall,
    position:  franchiseRostersTable.position,
    contractYearsLeft: franchiseRostersTable.contractYearsLeft,
  });
  const filtered = (rows as any[]).filter(r => r.position?.toUpperCase() === position.toUpperCase());

  if (!filtered.length) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ No players at position **${position}**.`)], components: [backToHubRow()] });
    return;
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_buy_cmpick:")
    .setPlaceholder("Select a player…")
    .addOptions(
      filtered.slice(0, 25).map(r => {
        const contractInfo = (r.contractYearsLeft != null) ? ` | Yrs: ${r.contractYearsLeft}` : "";
        return new StringSelectMenuOptionBuilder()
          .setLabel(`${r.firstName} ${r.lastName} — OVR ${r.overall}${contractInfo}`)
          .setValue(String(r.playerId));
      }),
    );

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Blue)
      .setTitle(`${CM_EMOJI[type]} ${CM_LABEL[type]} — Step 2`)
      .setDescription(`**Position: ${position}**\nNow pick the player.`)],
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu), cancelRow()],
  });
}

async function handleBuyContractModConfirm(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const playerId = Number(interaction.values[0]);
  const gid      = interaction.guildId!;
  const seasonId = await getRosterSeasonId(gid);
  const type     = (sess.purchaseType ?? "contract_extension") as ContractModType;

  const rows = await db.select({
    firstName:         franchiseRostersTable.firstName,
    lastName:          franchiseRostersTable.lastName,
    position:          franchiseRostersTable.position,
    overall:           franchiseRostersTable.overall,
    contractYearsLeft: franchiseRostersTable.contractYearsLeft,
    playerId:          franchiseRostersTable.playerId,
  }).from(franchiseRostersTable)
    .where(and(eq(franchiseRostersTable.seasonId, seasonId), eq(franchiseRostersTable.playerId, playerId)))
    .limit(1);

  if (!rows.length) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Player not found.")], components: [backToHubRow()] });
    return;
  }

  const player = rows[0]!;
  sess.selectedPlayerId   = playerId;
  sess.selectedPlayerName = `${player.firstName} ${player.lastName}`.trim();
  sess.selectedPlayerPos  = player.position ?? "";

  const season = await getOrCreateActiveSeason(gid);
  const [rules, user, seasonStats] = await Promise.all([
    getSeasonRules(season),
    getOrCreateUser(interaction.user.id, interaction.user.username, gid),
    getSeasonStats(interaction.user.id, season.id),
  ]);

  const costMap: Record<ContractModType, number> = {
    contract_extension: rules.contractExtensionCost,
    salary_reduction:   rules.salaryReductionCost,
    bonus_reduction:    rules.bonusReductionCost,
  };
  const capMap: Record<ContractModType, number> = {
    contract_extension: rules.contractExtensionCap,
    salary_reduction:   rules.salaryReductionCap,
    bonus_reduction:    rules.bonusReductionCap,
  };
  const usedMap: Record<ContractModType, number> = {
    contract_extension: seasonStats?.contractExtensionsPurchased ?? 0,
    salary_reduction:   seasonStats?.salaryReductionsPurchased   ?? 0,
    bonus_reduction:    seasonStats?.bonusReductionsPurchased     ?? 0,
  };

  const cost    = costMap[type];
  const cap     = capMap[type];
  const used    = usedMap[type];
  const contractInfo = (player.contractYearsLeft != null) ? `\nContract Years Left: **${player.contractYearsLeft}**` : "";

  const embed = new EmbedBuilder()
    .setColor(Colors.Blue)
    .setTitle(`${CM_EMOJI[type]} Confirm ${CM_LABEL[type]}`)
    .setDescription(
      `**${sess.selectedPlayerName}** (${sess.selectedPlayerPos})${contractInfo}\n\n` +
      `**Cost:** ${cost.toLocaleString()} coins\n` +
      `**Your Balance:** ${user.balance.toLocaleString()} coins\n` +
      `**Used this season:** ${used}/${cap}`,
    );

  if (user.balance < cost) {
    embed.setColor(Colors.Red).setDescription(
      `❌ **Insufficient coins.** You need **${cost.toLocaleString()}** but only have **${user.balance.toLocaleString()}**.\n\n` +
      `**${sess.selectedPlayerName}** (${sess.selectedPlayerPos})`,
    );
    await interaction.update({ embeds: [embed], components: [backToHubRow()] });
    return;
  }
  if (used >= cap) {
    embed.setColor(Colors.Red).setDescription(
      `❌ **Season cap reached.** You've used all ${cap} ${CM_LABEL[type]} slots this season.\n\n` +
      `**${sess.selectedPlayerName}** (${sess.selectedPlayerPos})`,
    );
    await interaction.update({ embeds: [embed], components: [backToHubRow()] });
    return;
  }

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_buy_cm_confirm").setLabel(`✅ Confirm ${CM_LABEL[type]}`).setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId("ac_hub").setLabel("✖ Cancel").setStyle(ButtonStyle.Secondary),
  );
  await interaction.update({ embeds: [embed], components: [row] });
}

async function handleBuyContractModExecute(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid  = interaction.guildId!;
  const type = (sess.purchaseType ?? "contract_extension") as ContractModType;

  if (!sess.selectedPlayerId || !sess.selectedPlayerName) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Session expired. Please start over.")], components: [backToHubRow()] });
    return;
  }

  const season = await getOrCreateActiveSeason(gid);
  const [rules, user, seasonStats] = await Promise.all([
    getSeasonRules(season),
    getOrCreateUser(interaction.user.id, interaction.user.username, gid),
    getSeasonStats(interaction.user.id, season.id),
  ]);

  const costMap: Record<ContractModType, number> = {
    contract_extension: rules.contractExtensionCost,
    salary_reduction:   rules.salaryReductionCost,
    bonus_reduction:    rules.bonusReductionCost,
  };
  const capMap: Record<ContractModType, number> = {
    contract_extension: rules.contractExtensionCap,
    salary_reduction:   rules.salaryReductionCap,
    bonus_reduction:    rules.bonusReductionCap,
  };
  const usedMap: Record<ContractModType, number> = {
    contract_extension: seasonStats?.contractExtensionsPurchased ?? 0,
    salary_reduction:   seasonStats?.salaryReductionsPurchased   ?? 0,
    bonus_reduction:    seasonStats?.bonusReductionsPurchased     ?? 0,
  };

  const cost = costMap[type];
  const cap  = capMap[type];
  const used = usedMap[type];

  if (used >= cap) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ Season cap reached. You've used all ${cap} ${CM_LABEL[type]} slots this season.`)], components: [backToHubRow()] });
    return;
  }
  if (user.balance < cost) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ Insufficient coins. You need **${cost.toLocaleString()}** but only have **${user.balance.toLocaleString()}**.`)], components: [backToHubRow()] });
    return;
  }

  // Career cap enforcement (salary_reduction + bonus_reduction only)
  if (type === "salary_reduction" || type === "bonus_reduction") {
    const settings = await getServerSettings(gid);
    const careerCapKey = type === "salary_reduction" ? "salaryReductionCareerCap" : "bonusReductionCareerCap";
    const careerCap = (settings as Record<string, unknown>)[careerCapKey] as number | null | undefined;
    if (careerCap != null) {
      const guildSeasons = await db.select({ id: seasonsTable.id }).from(seasonsTable).where(eq(seasonsTable.guildId, gid));
      const guildSeasonIds = guildSeasons.map(s => s.id);
      if (guildSeasonIds.length > 0) {
        const [row] = await db
          .select({ count: sql<number>`COUNT(*)::int` })
          .from(purchasesTable)
          .where(and(
            inArray(purchasesTable.seasonId, guildSeasonIds),
            eq(purchasesTable.purchaseType, type),
            sql`lower(${purchasesTable.playerName}) = lower(${sess.selectedPlayerName})`,
            ne(purchasesTable.status, "refunded"),
          ));
        if ((row?.count ?? 0) >= careerCap) {
          await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ **${sess.selectedPlayerName}** has reached the career cap of **${careerCap}** ${CM_LABEL[type]}(s) in this franchise.`)], components: [backToHubRow()] });
          return;
        }
      }
    }
  }

  await deductBalance(interaction.user.id, cost, gid);
  await logTransaction(interaction.user.id, -cost, "purchase", `${CM_LABEL[type]} — ${sess.selectedPlayerName} (${sess.selectedPlayerPos ?? ""})`, gid);

  const statsIncrement =
    type === "contract_extension"
      ? { contractExtensionsPurchased: sql`${seasonStatsTable.contractExtensionsPurchased} + 1` }
      : type === "salary_reduction"
        ? { salaryReductionsPurchased: sql`${seasonStatsTable.salaryReductionsPurchased} + 1` }
        : { bonusReductionsPurchased:  sql`${seasonStatsTable.bonusReductionsPurchased}  + 1` };

  await db.update(seasonStatsTable)
    .set(statsIncrement)
    .where(and(eq(seasonStatsTable.discordId, interaction.user.id), eq(seasonStatsTable.seasonId, season.id)));

  const [inserted] = await db.insert(purchasesTable).values({
    discordId:      interaction.user.id,
    seasonId:       season.id,
    purchaseType:   type,
    status:         "pending",
    cost,
    playerName:     sess.selectedPlayerName,
    playerPosition: sess.selectedPlayerPos ?? "",
  }).returning({ id: purchasesTable.id });

  await db.insert(inventoryTable).values({
    discordId:      interaction.user.id,
    seasonId:       season.id,
    purchaseId:     inserted!.id,
    itemType:       type,
    playerName:     sess.selectedPlayerName,
    playerPosition: sess.selectedPlayerPos ?? "",
  });

  await sendCommissionerNotification(interaction as any, type, inserted!.id, {
    playerName:     sess.selectedPlayerName,
    playerPosition: sess.selectedPlayerPos ?? "",
    costPer:        cost,
  });

  await interaction.update({
    embeds: [new EmbedBuilder()
      .setColor(Colors.Yellow)
      .setTitle(`⏳ ${CM_LABEL[type]} Submitted`)
      .setDescription(
        `**${CM_LABEL[type]}** for **${sess.selectedPlayerName}** (${sess.selectedPlayerPos ?? ""}) submitted!\n\n` +
        `A commissioner will apply it in-game.\n` +
        `**Cost:** ${cost.toLocaleString()} coins deducted.\n` +
        `**Used this season:** ${used + 1}/${cap}`,
      )],
    components: [backToHubRow()],
  });
}

// ── Dev Trait Upgrade ─────────────────────────────────────────────────────────

async function handleBuyDevUpPosPick(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  const seasonId = await getRosterSeasonId(gid);
  sess.purchaseType = "devup";

  const rows = await getRosterRows(interaction as any, seasonId, {
    position: franchiseRostersTable.position,
    devTrait: franchiseRostersTable.devTrait,
  });
  const eligible = (rows as any[]).filter(r => r.devTrait <= 1);
  const positions = sortByCanonical([...new Set(eligible.map((r: any) => r.position as string).filter(Boolean))]);

  if (!positions.length) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ No eligible players (Normal/Star dev only).")], components: [backToHubRow()] });
    return;
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_buy_dupos:")
    .setPlaceholder("Select position…")
    .addOptions(positions.slice(0, 25).map(p => new StringSelectMenuOptionBuilder().setLabel(p).setValue(p)));

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Green).setTitle("📈 Dev Trait Upgrade — Step 1").setDescription("Pick the position of the player you want to upgrade.\n\n*Only Normal and Star players are eligible.*")],
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu), cancelRow()],
  });
}

async function handleBuyDUPlayerPick(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const position = interaction.values[0]!;
  const gid = interaction.guildId!;
  const seasonId = await getRosterSeasonId(gid);

  const rows = await getRosterRows(interaction as any, seasonId, {
    playerId: franchiseRostersTable.playerId,
    firstName: franchiseRostersTable.firstName,
    lastName: franchiseRostersTable.lastName,
    overall: franchiseRostersTable.overall,
    devTrait: franchiseRostersTable.devTrait,
    position: franchiseRostersTable.position,
  });
  const filtered = (rows as any[]).filter(r =>
    r.position?.toUpperCase() === position.toUpperCase() && r.devTrait <= 1
  );

  if (!filtered.length) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ No eligible players at ${position}.`)], components: [backToHubRow()] });
    return;
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_buy_duplayer:")
    .setPlaceholder("Select player…")
    .addOptions(
      filtered.slice(0, 25).map(r =>
        new StringSelectMenuOptionBuilder()
          .setLabel(`${r.firstName} ${r.lastName} — OVR ${r.overall} | ${DEV_LABEL[r.devTrait] ?? "Normal"}`)
          .setValue(String(r.playerId)),
      ),
    );

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Green).setTitle("📈 Dev Trait Upgrade — Step 2").setDescription(`Position: **${position}** — Select the player.`)],
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu), cancelRow()],
  });
}

async function handleBuyDUConfirm(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const playerId = Number(interaction.values[0]);
  const gid = interaction.guildId!;
  const seasonId = await getRosterSeasonId(gid);

  const rows = await db.select({
    firstName: franchiseRostersTable.firstName,
    lastName:  franchiseRostersTable.lastName,
    devTrait:  franchiseRostersTable.devTrait,
    position:  franchiseRostersTable.position,
    playerId:  franchiseRostersTable.playerId,
  }).from(franchiseRostersTable)
    .where(and(eq(franchiseRostersTable.seasonId, seasonId), eq(franchiseRostersTable.playerId, playerId)))
    .limit(1);

  if (!rows.length) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Player not found.")], components: [backToHubRow()] });
    return;
  }

  const player = rows[0]!;
  sess.selectedPlayerId   = playerId;
  sess.selectedPlayerName = `${player.firstName} ${player.lastName}`.trim();
  sess.selectedPlayerPos  = player.position ?? "";
  sess.selectedPlayerDev  = player.devTrait ?? 0;

  const duSeason = await getOrCreateActiveSeason(gid);
  const [rules, user] = await Promise.all([
    getSeasonRules(duSeason),
    getOrCreateUser(interaction.user.id, interaction.user.username, gid),
  ]);
  const cost    = rules?.devUpsCost ?? 1500;
  const curDev  = DEV_LABEL[player.devTrait ?? 0] ?? "Normal";
  const nextDev = DEV_LABEL[(player.devTrait ?? 0) + 1] ?? "Star";

  const embed = new EmbedBuilder()
    .setColor(Colors.Green)
    .setTitle("📈 Confirm Dev Trait Upgrade")
    .setDescription(
      `**${sess.selectedPlayerName}** (${sess.selectedPlayerPos})\n` +
      `Dev Upgrade: **${curDev} → ${nextDev}**\n\n` +
      `Cost: **${cost.toLocaleString()} coins**\nYour balance: **${user.balance.toLocaleString()} coins**`
    );

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_buy_du_confirm").setLabel("✅ Confirm Upgrade").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("ac_hub").setLabel("✖ Cancel").setStyle(ButtonStyle.Secondary),
  );

  await interaction.update({ embeds: [embed], components: [row] });
}

async function handleBuyDevUpExecute(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  if (!sess.selectedPlayerId || !sess.selectedPlayerName) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Session expired. Please start over.")], components: [backToHubRow()] });
    return;
  }

  const season = await getOrCreateActiveSeason(gid);
  const [rules, user, seasonStats] = await Promise.all([
    getSeasonRules(season),
    getOrCreateUser(interaction.user.id, interaction.user.username, gid),
    getSeasonStats(interaction.user.id, season.id),
  ]);

  const cost      = rules?.devUpsCost ?? 1500;
  const maxDevUps = rules?.devUpsCap ?? 2;
  const used      = seasonStats?.devUpsPurchased ?? 0;

  if (used >= maxDevUps) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ You have used all ${maxDevUps} dev upgrades this season.`)], components: [backToHubRow()] });
    return;
  }
  if (user.balance < cost) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ Insufficient coins. You need **${cost.toLocaleString()}** but only have **${user.balance.toLocaleString()}**.`)], components: [backToHubRow()] });
    return;
  }

  await deductBalance(interaction.user.id, cost, gid);
  await logTransaction(interaction.user.id, -cost, "purchase", `Dev trait upgrade — ${sess.selectedPlayerName}`, gid);

  const [duInserted] = await db.insert(purchasesTable).values({
    discordId: interaction.user.id,
    seasonId: season.id,
    purchaseType: "dev_up",
    playerName: sess.selectedPlayerName,
    playerPosition: sess.selectedPlayerPos ?? "",
    cost,
    status: "pending",
    notes: `Dev up for ${sess.selectedPlayerName}`,
  }).returning({ id: purchasesTable.id });

  await sendCommissionerNotification(interaction as any, "dev_upgrade", duInserted!.id, {
    playerName:     sess.selectedPlayerName,
    playerPosition: sess.selectedPlayerPos ?? "",
    currentDevLabel: DEV_LABEL[sess.selectedPlayerDev ?? 0] ?? "Normal",
    devUpType:       DEV_LABEL[(sess.selectedPlayerDev ?? 0) + 1] ?? "Star",
    costPer:         cost,
  });

  await interaction.update({
    embeds: [new EmbedBuilder()
      .setColor(Colors.Yellow)
      .setTitle("⏳ Dev Upgrade Submitted")
      .setDescription(`Dev upgrade for **${sess.selectedPlayerName}** has been submitted for commissioner approval.\nCost: **${cost.toLocaleString()} coins** deducted.`)],
    components: [backToHubRow()],
  });
}

// ── Buy Custom Player info ─────────────────────────────────────────────────────

async function handleBuyCustomInfo(interaction: ButtonInteraction) {
  await interaction.deferUpdate();

  const gid       = interaction.guildId!;
  const discordId = interaction.user.id;
  const season    = await getOrCreateActiveSeason(gid);

  const invCount   = await getInventoryCount(discordId, season.id);
  const customsCap = LIMITS.customPlayersPerDraft;

  if (invCount.customs >= customsCap) {
    await interaction.editReply({
      embeds: [new EmbedBuilder()
        .setColor(Colors.Red)
        .setTitle("❌ Custom Player Limit Reached")
        .setDescription(
          `You have already purchased **${invCount.customs}** custom player this season ` +
          `(max **${customsCap}** per season). You cannot purchase another until next season.`,
        )],
      components: [backToHubRow()],
    });
    return;
  }

  const sessionId = createSession(discordId, gid, season.id);

  const warningEmbed = new EmbedBuilder()
    .setColor(Colors.Yellow)
    .setTitle("⚠️ Before You Start — Draft Pick Required")
    .setDescription(
      "Purchasing a custom player **does not automatically place them on your roster**.\n\n" +
      "You must use **a draft pick** to select your custom player during the annual draft. " +
      "If you do not have a draft pick available, you will not be able to add this player to your team.",
    )
    .addFields(
      {
        name: "What happens after you purchase?",
        value:
          "1. You build your player's position, archetype, attributes, and appearance.\n" +
          "2. A commissioner adds them to the MCA draft class.\n" +
          "3. You use a draft pick to select them in the draft.\n" +
          "4. They join your roster once drafted.",
      },
      {
        name: "Custom player limit",
        value: `You have used **${invCount.customs}** of **${customsCap}** custom player slot this season.`,
      },
    )
    .setFooter({ text: "Make sure you have a draft pick saved before proceeding." });

  const confirmRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`ccp_preconfirm:${sessionId}`)
      .setLabel("✅ I understand, start building")
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`ccp_cancel:${sessionId}`)
      .setLabel("❌ Cancel")
      .setStyle(ButtonStyle.Secondary),
  );

  await interaction.editReply({ embeds: [warningEmbed], components: [confirmRow] });
}

// ── Buy Legend ─────────────────────────────────────────────────────────────────

const LEGEND_POSITION_LABELS: Record<string, string> = {
  QB:   "QB — Quarterback",
  HB:   "HB — Halfback",
  FB:   "FB — Fullback",
  WR:   "WR — Wide Receiver",
  TE:   "TE — Tight End",
  OL:   "OL — Offensive Line",
  LT:   "LT — Left Tackle",
  LG:   "LG — Left Guard",
  C:    "C — Center",
  RG:   "RG — Right Guard",
  RT:   "RT — Right Tackle",
  DB:   "DB — Defensive Back",
  LE:   "LE — Left Defensive End",
  RE:   "RE — Right Defensive End",
  DT:   "DT — Defensive Tackle",
  DL:   "DL — Defensive Line",
  LOLB: "LOLB — Left Outside LB",
  LB:   "LB — Linebacker",
  MLB:  "MLB — Middle Linebacker",
  ROLB: "ROLB — Right Outside LB",
  CB:   "CB — Cornerback",
  FS:   "FS — Free Safety",
  SS:   "SS — Strong Safety",
  K:    "K — Kicker",
  P:    "P — Punter",
};

// Canonical position display order for the legend picker
const LEGEND_POSITION_ORDER = ["QB", "HB", "FB", "WR", "TE", "OL", "DL", "LB", "DB"];

// Step 1 — position picker
async function handleBuyLegendPick(interaction: ButtonInteraction, sess: ActionsSession) {
  const purchasedIds = await getPurchasedLegendIds(interaction.guildId!);
  const rows = await db
    .selectDistinct({ position: legendsTable.position })
    .from(legendsTable)
    .where(and(
      eq(legendsTable.isAvailable, true),
      ...(purchasedIds.length > 0 ? [notInArray(legendsTable.id, purchasedIds)] : []),
    ));

  if (!rows.length) {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ No legends are currently available in the store.")],
      components: [backToHubRow()],
    });
    return;
  }

  // Sort by explicit canonical order; unknown positions fall to end alphabetically
  const positionSet = new Set(rows.map(r => r.position));
  const positions = [
    ...LEGEND_POSITION_ORDER.filter(p => positionSet.has(p)),
    ...[...positionSet].filter(p => !LEGEND_POSITION_ORDER.includes(p)).sort(),
  ];

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_buy_legendpos:")
    .setPlaceholder("Select a position…")
    .addOptions(
      positions.map(p =>
        new StringSelectMenuOptionBuilder()
          .setLabel(LEGEND_POSITION_LABELS[p] ?? p)
          .setValue(p),
      ),
    );

  await interaction.update({
    embeds: [
      new EmbedBuilder()
        .setColor(Colors.Gold)
        .setTitle("🏆 Buy a Legend — Step 1: Choose a Position")
        .setDescription(
          "Select a position to see available legends.\n\n" +
          "Max **2 legends per team** · Purchase window: **Weeks 1–18** (closes at Wildcard week)\n" +
          "Legends stay with the team if ownership changes.",
        ),
    ],
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu), cancelRow()],
  });
}

// Step 2 — legend picker for the chosen position
async function handleBuyLegendPositionPick(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const position = interaction.values[0]!;
  const purchasedIds = await getPurchasedLegendIds(interaction.guildId!);

  const rows = await db.select({
    id:       legendsTable.id,
    name:     legendsTable.name,
    position: legendsTable.position,
    cost:     legendsTable.cost,
  }).from(legendsTable)
    .where(and(
      eq(legendsTable.isAvailable, true),
      eq(legendsTable.position, position),
      ...(purchasedIds.length > 0 ? [notInArray(legendsTable.id, purchasedIds)] : []),
    ))
    .orderBy(legendsTable.name);

  if (!rows.length) {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ No **${position}** legends are currently available.`)],
      components: [backToHubRow()],
    });
    return;
  }

  const legendMenu = new StringSelectMenuBuilder()
    .setCustomId("ac_buy_legendsel:")
    .setPlaceholder(`Select a ${position} legend…`)
    .addOptions(
      rows.slice(0, 25).map(l =>
        new StringSelectMenuOptionBuilder()
          .setLabel(`${l.name} (${(l.cost ?? 0).toLocaleString()} coins)`)
          .setValue(String(l.id)),
      ),
    );

  const backRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_buy_legend").setLabel("← Back to Positions").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_hub").setLabel("✖ Cancel").setStyle(ButtonStyle.Secondary),
  );

  await interaction.update({
    embeds: [
      new EmbedBuilder()
        .setColor(Colors.Gold)
        .setTitle(`🏆 Buy a Legend — ${LEGEND_POSITION_LABELS[position] ?? position}`)
        .setDescription(`**${rows.length}** legend${rows.length === 1 ? "" : "s"} available at this position. Select one to continue.`),
    ],
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(legendMenu), backRow],
  });
}

async function handleBuyLegendConfirm(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const legendId = Number(interaction.values[0]);
  const row = (await db.select().from(legendsTable).where(eq(legendsTable.id, legendId)).limit(1))[0];
  if (!row) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Legend not found.")], components: [backToHubRow()] });
    return;
  }

  const gid  = interaction.guildId!;
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username, gid);
  sess.selectedLegendId   = legendId;
  sess.selectedLegendName = row.name;
  sess.selectedLegendCost = row.cost ?? 0;

  const embed = new EmbedBuilder()
    .setColor(Colors.Gold)
    .setTitle("🏆 Confirm Legend Purchase")
    .setDescription(
      `**${row.name}** — ${row.position}\n\n` +
      `Cost: **${(row.cost ?? 0).toLocaleString()} coins**\nYour balance: **${user.balance.toLocaleString()} coins**`
    );

  const btnRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_buy_legend_confirm").setLabel("✅ Confirm Purchase").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("ac_hub").setLabel("✖ Cancel").setStyle(ButtonStyle.Secondary),
  );

  await interaction.update({ embeds: [embed], components: [btnRow] });
}

async function handleBuyLegendExecute(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  if (!sess.selectedLegendId || !sess.selectedLegendName) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Session expired.")], components: [backToHubRow()] });
    return;
  }

  const [legend, season, user] = await Promise.all([
    db.select().from(legendsTable).where(eq(legendsTable.id, sess.selectedLegendId)).limit(1).then(r => r[0]),
    getOrCreateActiveSeason(gid),
    getOrCreateUser(interaction.user.id, interaction.user.username, gid),
  ]);

  if (!legend) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Legend no longer available.")], components: [backToHubRow()] });
    return;
  }

  // Purchase window: legends available through Week 18; closes once Wildcard week is reached
  if (!LEGEND_CUSTOM_PURCHASE_WEEKS.has(season.currentWeek ?? "")) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Orange).setDescription(`❌ Legend purchases must be submitted before the league advances to Wildcard week. Current week: **Week ${season.currentWeek ?? "?"}**.`)], components: [backToHubRow()] });
    return;
  }

  // Team-based cap check
  const teamCount = await getTeamLegendCount(user.team, interaction.user.id, season.id);
  if (teamCount.legends >= LIMITS.legendsPerTeam) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ Your team has reached the maximum of **${LIMITS.legendsPerTeam} legends** allowed.`)], components: [backToHubRow()] });
    return;
  }

  const cost = legend.cost ?? 0;
  if (user.balance < cost) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ Insufficient coins. You need **${cost.toLocaleString()}** but only have **${user.balance.toLocaleString()}**.`)], components: [backToHubRow()] });
    return;
  }

  await deductBalance(interaction.user.id, cost, gid);
  await logTransaction(interaction.user.id, -cost, "purchase", `Legend purchase — ${legend.name}`, gid);

  const [lgInserted] = await db.insert(purchasesTable).values({
    discordId: interaction.user.id,
    seasonId: season.id,
    purchaseType: "legend",
    legendId: legend.id,
    playerName: legend.name,
    playerPosition: legend.position ?? "",
    cost,
    status: "pending",
    notes: `Legend: ${legend.name}`,
  }).returning({ id: purchasesTable.id });

  await sendCommissionerNotification(interaction as any, "legend", lgInserted!.id, {
    legendName:     legend.name,
    legendPosition: legend.position ?? "",
    costPer:        cost,
  });

  await interaction.update({
    embeds: [new EmbedBuilder()
      .setColor(Colors.Yellow)
      .setTitle("⏳ Legend Submitted")
      .setDescription(`**${legend.name}** submitted for commissioner approval. Cost: **${cost.toLocaleString()} coins** deducted.`)],
    components: [backToHubRow()],
  });
}

// ── Training Package ───────────────────────────────────────────────────────────

const TRAINING_TIERS = {
  gold:   { label: "🥇 Gold",   cost: 1000, points: 4, purchaseType: "training_gold"   as const, seasonStatKey: "trainingGoldPurchased",   limit: 2 },
  silver: { label: "🥈 Silver", cost: 500,  points: 2, purchaseType: "training_silver" as const, seasonStatKey: "trainingSilverPurchased", limit: 2 },
  bronze: { label: "🥉 Bronze", cost: 250,  points: 1, purchaseType: "training_bronze" as const, seasonStatKey: null,                      limit: 999 },
} as const;
type TrainingTier = keyof typeof TRAINING_TIERS;

// Attribute pools for weighted lottery (1.5× chance when goal matches)
const TRAINING_SPEED_ATTRS = new Set([
  "Speed", "Acceleration", "Agility", "Change of Direction",
  "Juke Move", "Spin Move", "Release",
  "Pass Block Finesse", "Run Block Finesse", "Finesse Moves",
  "Pursuit", "Man Coverage", "Zone Coverage", "Kick/Punt Return",
]);
const TRAINING_POWER_ATTRS = new Set([
  "Strength", "Trucking", "Stiff Arm", "Break Tackle",
  "Hit Power", "Throwing Power", "Power Moves",
  "Pass Block Power", "Run Block Power",
  "Lead Block", "Impact Blocking", "Block Shedding", "Tackling",
]);

// Position-focused boost sets — 2× weight on these when goal === "position"
const TRAINING_POS_FOCUS: Record<string, Set<string>> = {
  QB:    new Set(["Throwing Power","Short Accuracy","Medium Accuracy","Deep Accuracy","Throw on the Run","Throw Under Pressure","Break Sack","Play Action"]),
  HB:    new Set(["Carrying","BC Vision","Break Tackle","Trucking","Stiff Arm","Spin Move","Juke Move"]),
  FB:    new Set(["Carrying","Break Tackle","Trucking","Stiff Arm","Lead Block","Impact Blocking"]),
  WR:    new Set(["Catching","Catch in Traffic","Spectacular Catch","Short Route Running","Medium Route Running","Deep Route Running","Release"]),
  TE:    new Set(["Catching","Catch in Traffic","Spectacular Catch","Short Route Running","Medium Route Running","Deep Route Running","Release","Lead Block","Impact Blocking"]),
  LT:    new Set(["Pass Blocking","Pass Block Power","Pass Block Finesse","Run Blocking","Run Block Power","Run Block Finesse","Lead Block","Impact Blocking"]),
  LG:    new Set(["Pass Blocking","Pass Block Power","Pass Block Finesse","Run Blocking","Run Block Power","Run Block Finesse","Lead Block","Impact Blocking"]),
  C:     new Set(["Pass Blocking","Pass Block Power","Pass Block Finesse","Run Blocking","Run Block Power","Run Block Finesse","Lead Block","Impact Blocking"]),
  RG:    new Set(["Pass Blocking","Pass Block Power","Pass Block Finesse","Run Blocking","Run Block Power","Run Block Finesse","Lead Block","Impact Blocking"]),
  RT:    new Set(["Pass Blocking","Pass Block Power","Pass Block Finesse","Run Blocking","Run Block Power","Run Block Finesse","Lead Block","Impact Blocking"]),
  LEDGE: new Set(["Block Shedding","Finesse Moves","Power Moves","Pursuit","Tackling","Hit Power"]),
  REDGE: new Set(["Block Shedding","Finesse Moves","Power Moves","Pursuit","Tackling","Hit Power"]),
  DT:    new Set(["Block Shedding","Finesse Moves","Power Moves","Pursuit","Tackling","Hit Power"]),
  MIKE:  new Set(["Tackling","Hit Power","Block Shedding","Finesse Moves","Power Moves","Pursuit","Play Recognition","Man Coverage","Zone Coverage"]),
  WILL:  new Set(["Tackling","Hit Power","Block Shedding","Finesse Moves","Power Moves","Pursuit","Play Recognition","Man Coverage","Zone Coverage"]),
  SAM:   new Set(["Tackling","Hit Power","Block Shedding","Finesse Moves","Power Moves","Pursuit","Play Recognition","Man Coverage","Zone Coverage"]),
  CB:    new Set(["Man Coverage","Zone Coverage","Press","Play Recognition","Tackling","Hit Power","Pursuit"]),
  FS:    new Set(["Man Coverage","Zone Coverage","Press","Play Recognition","Tackling","Hit Power","Pursuit"]),
  SS:    new Set(["Man Coverage","Zone Coverage","Press","Play Recognition","Tackling","Hit Power","Pursuit"]),
  K:     new Set(["Kicking Power","Kicking Accuracy"]),
  P:     new Set(["Kicking Power","Kicking Accuracy"]),
  LS:    new Set(["Long Snap"]),
};

// Position-relevant attribute sets — only eligible attrs for a given roster spot
const _A = (...attrs: string[]) => new Set(attrs);
const SHARED_ATHLETE   = ["Speed","Acceleration","Agility","Strength","Awareness","Change of Direction","Jumping","Stamina","Toughness","Injury"] as const;
const SHARED_COVERAGE  = ["Tackling","Hit Power","Pursuit","Play Recognition","Man Coverage","Zone Coverage","Press"] as const;
const SHARED_DLINE     = ["Tackling","Hit Power","Block Shedding","Finesse Moves","Power Moves","Pursuit"] as const;
const SHARED_OL_BLOCKS = ["Pass Blocking","Pass Block Power","Pass Block Finesse","Run Blocking","Run Block Power","Run Block Finesse","Lead Block","Impact Blocking"] as const;

const TRAINING_POS_ATTRS: Record<string, Set<string>> = {
  QB:    _A(...SHARED_ATHLETE, "Throwing Power","Short Accuracy","Medium Accuracy","Deep Accuracy","Throw on the Run","Throw Under Pressure","Break Sack","Play Action"),
  HB:    _A(...SHARED_ATHLETE, "Carrying","BC Vision","Break Tackle","Trucking","Stiff Arm","Spin Move","Juke Move","Catching","Catch in Traffic","Kick/Punt Return"),
  FB:    _A(...SHARED_ATHLETE, "Carrying","Break Tackle","Trucking","Stiff Arm","Catching","Catch in Traffic",...SHARED_OL_BLOCKS),
  WR:    _A(...SHARED_ATHLETE, "Carrying","Catching","Catch in Traffic","Spectacular Catch","Short Route Running","Medium Route Running","Deep Route Running","Release","Kick/Punt Return"),
  TE:    _A(...SHARED_ATHLETE, "Carrying","Catching","Catch in Traffic","Spectacular Catch","Short Route Running","Medium Route Running","Deep Route Running","Release",...SHARED_OL_BLOCKS),
  LT:    _A(...SHARED_ATHLETE, ...SHARED_OL_BLOCKS),
  LG:    _A(...SHARED_ATHLETE, ...SHARED_OL_BLOCKS),
  C:     _A(...SHARED_ATHLETE, ...SHARED_OL_BLOCKS),
  RG:    _A(...SHARED_ATHLETE, ...SHARED_OL_BLOCKS),
  RT:    _A(...SHARED_ATHLETE, ...SHARED_OL_BLOCKS),
  LEDGE: _A(...SHARED_ATHLETE, ...SHARED_DLINE),
  REDGE: _A(...SHARED_ATHLETE, ...SHARED_DLINE),
  DT:    _A(...SHARED_ATHLETE, ...SHARED_DLINE),
  WILL:  _A(...SHARED_ATHLETE, ...SHARED_DLINE, "Play Recognition","Man Coverage","Zone Coverage"),
  MIKE:  _A(...SHARED_ATHLETE, ...SHARED_DLINE, "Play Recognition","Man Coverage","Zone Coverage"),
  SAM:   _A(...SHARED_ATHLETE, ...SHARED_DLINE, "Play Recognition","Man Coverage","Zone Coverage"),
  CB:    _A(...SHARED_ATHLETE, "Catching",...SHARED_COVERAGE,"Kick/Punt Return"),
  FS:    _A(...SHARED_ATHLETE, "Catching",...SHARED_COVERAGE),
  SS:    _A(...SHARED_ATHLETE, "Catching",...SHARED_COVERAGE),
  K:     _A("Kicking Power","Kicking Accuracy","Stamina","Toughness","Injury"),
  P:     _A("Kicking Power","Kicking Accuracy","Stamina","Toughness","Injury"),
  LS:    _A("Strength","Awareness","Long Snap","Stamina","Toughness","Injury"),
};

// How many attributes can be upgraded per tier — strictly ordered so Gold > Silver > Bronze always
const TRAINING_ATTR_COUNT_RANGE = {
  gold:   { min: 4, max: 5 },  // 4 or 5, biased toward 5
  silver: { min: 3, max: 3 },  // always 3
  bronze: { min: 2, max: 2 },  // always 2
} as const;

/** Roll how many attributes to improve this purchase (ascending weights → biased toward tier max). */
function rollAttrCount(tier: TrainingTier): number {
  const { min, max } = TRAINING_ATTR_COUNT_RANGE[tier];
  if (min === max) return min;
  const range = max - min + 1;
  // weights: count[min]=1, count[min+1]=2, …, count[max]=range → higher count is more likely
  const total = (range * (range + 1)) / 2;
  let rng = Math.random() * total;
  for (let i = 0; i < range; i++) {
    rng -= (i + 1);
    if (rng <= 0) return min + i;
  }
  return max;
}

/** Roll N distinct attributes via weighted lottery (without replacement).
 *  - Position-filtered, excludes attrs already at 99.
 *  - Goal attrs get boosted weight (1.5× for speed/power, 2× for position). */
function rollTrainingAttrs(
  goal: "speed" | "power" | "balanced" | "position",
  playerAttrs: Record<string, number>,
  position: string,
  count: number,
): string[] {
  const pos       = position.toUpperCase();
  const boostSet  = goal === "speed"    ? TRAINING_SPEED_ATTRS
                  : goal === "power"    ? TRAINING_POWER_ATTRS
                  : goal === "position" ? (TRAINING_POS_FOCUS[pos] ?? null)
                  : null;
  const boostMult = goal === "position" ? 2.0 : 1.5;
  const posFilter = TRAINING_POS_ATTRS[pos];
  const allAttrs  = [...ATTRIBUTES] as string[];
  const eligible  = allAttrs.filter(a =>
    (!posFilter || posFilter.has(a)) &&
    (playerAttrs[a] ?? 0) < 99,
  );
  const pool = eligible.length > 0 ? eligible : allAttrs;

  // Weighted selection without replacement
  const remaining        = pool.slice();
  const remainingWeights = remaining.map(a => (boostSet && boostSet.has(a) ? boostMult : 1.0));
  const results: string[] = [];
  const n = Math.min(count, remaining.length);

  for (let i = 0; i < n; i++) {
    const total = remainingWeights.reduce((s, w) => s + w, 0);
    let rng     = Math.random() * total;
    let sel     = remaining.length - 1;
    for (let j = 0; j < remaining.length; j++) {
      rng -= remainingWeights[j]!;
      if (rng <= 0) { sel = j; break; }
    }
    results.push(remaining[sel]!);
    remaining.splice(sel, 1);
    remainingWeights.splice(sel, 1);
  }
  return results;
}

/** Roll points for one attribute: ascending weights → biased toward tier max.
 *  Capped so the attribute won't exceed 99. */
function rollTierPoints(tierMax: number, currentValue: number): number {
  const cap = Math.min(tierMax, 99 - currentValue);
  if (cap <= 0) return 0;
  if (cap === 1) return 1;
  // weights: +1=1, +2=2, …, +cap=cap → higher rolls more likely for better tiers
  const total = (cap * (cap + 1)) / 2;
  let rng = Math.random() * total;
  for (let pts = 1; pts <= cap; pts++) {
    rng -= pts;
    if (rng <= 0) return pts;
  }
  return cap;
}

// Step 1 — Pick a position
async function handleBuyTrainingPosPick(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  const seasonId = await getRosterSeasonId(gid);
  sess.trainingTier = undefined;
  sess.trainingGoal = undefined;
  sess.trainingPlayerId = undefined;
  sess.trainingPlayerName = undefined;
  sess.trainingPlayerPos = undefined;
  sess.trainingPlayerOvr = undefined;

  const rows = await getRosterRows(interaction as any, seasonId, { position: franchiseRostersTable.position });
  const positions = sortByCanonical([...new Set((rows as any[]).map((r: any) => r.position as string).filter(Boolean))]);

  if (!positions.length) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ No roster data found. Ask a commissioner to import MCA data.")], components: [backToHubRow()] });
    return;
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_buy_trainingpos:")
    .setPlaceholder("Select your player's position…")
    .addOptions(positions.slice(0, 25).map(p => new StringSelectMenuOptionBuilder().setLabel(p).setValue(p)));

  await interaction.update({
    embeds: [new EmbedBuilder()
      .setColor(0x3a7bd5)
      .setTitle("🎓 Training Package — Step 1 of 4")
      .setDescription(
        "Training packages give your player a **multi-attribute lottery upgrade**. Higher tiers always roll more attributes and larger point gains.\n\n" +
        "**Gold** — 1,000 coins · **4-5 attributes** · up to **+4 pts** each · max 2/season\n" +
        "**Silver** — 500 coins · **3 attributes** · up to **+2 pts** each · max 2/season\n" +
        "**Bronze** — 250 coins · **2 attributes** · **+1 pt** each · unlimited\n\n" +
        "First, pick the **position** of the player you want to train.",
      )],
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu), cancelRow()],
  });
}

// Step 2 — Pick a player from the chosen position
async function handleBuyTrainingPlayerPick(interaction: StringSelectMenuInteraction, _sess: ActionsSession) {
  const position = interaction.values[0]!;
  const gid      = interaction.guildId!;
  const seasonId = await getRosterSeasonId(gid);

  const rows = await getRosterRows(interaction as any, seasonId, {
    playerId:  franchiseRostersTable.playerId,
    firstName: franchiseRostersTable.firstName,
    lastName:  franchiseRostersTable.lastName,
    overall:   franchiseRostersTable.overall,
    devTrait:  franchiseRostersTable.devTrait,
    position:  franchiseRostersTable.position,
  });
  const filtered = (rows as any[]).filter(r => r.position?.toUpperCase() === position.toUpperCase());

  if (!filtered.length) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ No players found at position **${position}**.`)], components: [backToHubRow()] });
    return;
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_buy_trainingplayer:")
    .setPlaceholder("Select a player…")
    .addOptions(
      filtered.slice(0, 25).map(r =>
        new StringSelectMenuOptionBuilder()
          .setLabel(`${r.firstName} ${r.lastName} — OVR ${r.overall} ${DEV_LABEL[r.devTrait] ?? ""}`.trim())
          .setValue(`${r.playerId}|${r.firstName} ${r.lastName}|${position}|${r.overall}`),
      ),
    );

  await interaction.update({
    embeds: [new EmbedBuilder()
      .setColor(0x3a7bd5)
      .setTitle("🎓 Training Package — Step 2 of 4")
      .setDescription(`**Position: ${position}**\nNow pick the specific player you want to train.`)],
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu), cancelRow()],
  });
}

// Step 3 — Pick a tier
async function handleBuyTrainingTierPick(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const parts = interaction.values[0]!.split("|");
  sess.trainingPlayerId   = Number(parts[0]);
  sess.trainingPlayerName = parts[1] ?? "";
  sess.trainingPlayerPos  = parts[2] ?? "";
  sess.trainingPlayerOvr  = Number(parts[3] ?? 0);

  const gid    = interaction.guildId!;
  const season = await getOrCreateActiveSeason(gid);
  const stats  = await getSeasonStats(interaction.user.id, season.id);
  const user   = await getOrCreateUser(interaction.user.id, interaction.user.username, gid);

  const goldUsed   = (stats as any)["trainingGoldPurchased"]   as number ?? 0;
  const silverUsed = (stats as any)["trainingSilverPurchased"] as number ?? 0;

  const goldDisabled   = goldUsed   >= TRAINING_TIERS.gold.limit;
  const silverDisabled = silverUsed >= TRAINING_TIERS.silver.limit;

  const tierRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("ac_buy_training_tier:gold")
      .setLabel(`🥇 Gold — 1,000 coins (4-5 attrs · up to +4 pts each)${goldDisabled ? " [LIMIT REACHED]" : ""}`)
      .setStyle(ButtonStyle.Primary)
      .setDisabled(goldDisabled || user.balance < TRAINING_TIERS.gold.cost),
    new ButtonBuilder()
      .setCustomId("ac_buy_training_tier:silver")
      .setLabel(`🥈 Silver — 500 coins (3 attrs · up to +2 pts each)${silverDisabled ? " [LIMIT REACHED]" : ""}`)
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(silverDisabled || user.balance < TRAINING_TIERS.silver.cost),
    new ButtonBuilder()
      .setCustomId("ac_buy_training_tier:bronze")
      .setLabel("🥉 Bronze — 250 coins (2 attrs · +1 pt each)")
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(user.balance < TRAINING_TIERS.bronze.cost),
  );

  const lines = [
    `**Player:** ${sess.trainingPlayerName} (${sess.trainingPlayerPos}) — OVR ${sess.trainingPlayerOvr}`,
    `**Your balance:** ${user.balance.toLocaleString()} coins`,
    "",
    `**Gold** — 1,000 coins · 4-5 attrs · up to +4 pts each · ${goldUsed}/${TRAINING_TIERS.gold.limit} used this season`,
    `**Silver** — 500 coins · 3 attrs · up to +2 pts each · ${silverUsed}/${TRAINING_TIERS.silver.limit} used this season`,
    "**Bronze** — 250 coins · 2 attrs · +1 pt each · unlimited",
    "",
    "Select the tier you want to buy. You'll choose a **training goal** next to bias the roll.",
  ];

  await interaction.update({
    embeds: [new EmbedBuilder()
      .setColor(0x3a7bd5)
      .setTitle("🎓 Training Package — Step 3 of 4")
      .setDescription(lines.join("\n"))],
    components: [tierRow, cancelRow()],
  });
}

// Step 4 — Pick a training goal (after tier button, before confirmation)
async function handleBuyTrainingGoalPick(interaction: ButtonInteraction, sess: ActionsSession, tier: TrainingTier) {
  const meta = TRAINING_TIERS[tier];
  const gid  = interaction.guildId!;
  sess.trainingTier = tier;
  sess.trainingGoal = undefined;

  if (!sess.trainingPlayerName) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Session expired. Please start again.")], components: [backToHubRow()] });
    return;
  }

  // Re-check balance & season limits before showing goal picker
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username, gid);
  if (user.balance < meta.cost) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ Insufficient coins. You need **${meta.cost.toLocaleString()}** but only have **${user.balance.toLocaleString()}**.`)], components: [backToHubRow()] });
    return;
  }
  if (meta.limit < 999 && meta.seasonStatKey) {
    const season = await getOrCreateActiveSeason(gid);
    const stats  = await getSeasonStats(interaction.user.id, season.id);
    const used   = (stats as any)[meta.seasonStatKey] as number ?? 0;
    if (used >= meta.limit) {
      await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ You have used all **${meta.limit}** ${meta.label} training packages this season.`)], components: [backToHubRow()] });
      return;
    }
  }

  const goalMenu = new StringSelectMenuBuilder()
    .setCustomId("ac_buy_training_goal:")
    .setPlaceholder("Choose a training focus…")
    .addOptions([
      new StringSelectMenuOptionBuilder()
        .setLabel("⚡ Speed")
        .setDescription("50% higher chance of rolling Speed, Agility, Acceleration, and other movement attributes")
        .setValue("speed"),
      new StringSelectMenuOptionBuilder()
        .setLabel("💪 Power")
        .setDescription("50% higher chance of rolling Strength, Trucking, Hit Power, and other physical attributes")
        .setValue("power"),
      new StringSelectMenuOptionBuilder()
        .setLabel("⚖️ Balanced")
        .setDescription("Even chance across all attributes — no bias")
        .setValue("balanced"),
      new StringSelectMenuOptionBuilder()
        .setLabel("🎯 Position Focused")
        .setDescription("100% higher chance of rolling the core attributes for this player's position")
        .setValue("position"),
    ]);

  const attrRange = TRAINING_ATTR_COUNT_RANGE[tier];
  const attrRangeLabel = attrRange.min === attrRange.max
    ? `${attrRange.min} attributes`
    : `${attrRange.min}-${attrRange.max} attributes`;

  await interaction.update({
    embeds: [new EmbedBuilder()
      .setColor(0x3a7bd5)
      .setTitle("🎓 Training Package — Step 4 of 4")
      .setDescription(
        `**Player:** ${sess.trainingPlayerName} (${sess.trainingPlayerPos})\n` +
        `**Tier:** ${meta.label} — **${attrRangeLabel}** rolled · up to +${meta.points} pts each\n\n` +
        "Choose a **training goal** to bias which attributes get selected:\n\n" +
        "⚡ **Speed** — 50% boost to rolls for quickness, finesse & movement attributes\n" +
        "💪 **Power** — 50% boost to rolls for strength, power & physical attributes\n" +
        "⚖️ **Balanced** — all attributes equally likely\n" +
        "🎯 **Position Focused** — 100% boost to rolls for this player's core position attributes\n\n" +
        "_The boost increases the probability, not a guarantee. The result is still a lottery._",
      )],
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(goalMenu), cancelRow()],
  });
}

// Confirmation screen (after goal selected)
async function handleBuyTrainingConfirm(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const goal = interaction.values[0] as "speed" | "power" | "balanced" | "position";
  sess.trainingGoal = goal;

  const tier = sess.trainingTier as TrainingTier | undefined;
  if (!tier || !TRAINING_TIERS[tier] || !sess.trainingPlayerName) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Session expired. Please start again.")], components: [backToHubRow()] });
    return;
  }

  const meta  = TRAINING_TIERS[tier];
  const gid   = interaction.guildId!;
  const user  = await getOrCreateUser(interaction.user.id, interaction.user.username, gid);
  const cRange = TRAINING_ATTR_COUNT_RANGE[tier];
  const cLabel = cRange.min === cRange.max ? `${cRange.min}` : `${cRange.min}-${cRange.max}`;

  const goalLabel = goal === "speed"    ? "⚡ Speed"
                  : goal === "power"    ? "💪 Power"
                  : goal === "position" ? "🎯 Position Focused"
                  : "⚖️ Balanced";
  const goalDesc  = goal === "balanced"  ? "all attributes rolled evenly"
                  : goal === "speed"     ? "movement/quickness attributes have 50% higher roll chance"
                  : goal === "power"     ? "strength/power attributes have 50% higher roll chance"
                  : `core ${sess.trainingPlayerPos ?? "position"} attributes have 100% higher roll chance`;

  await interaction.update({
    embeds: [new EmbedBuilder()
      .setColor(Colors.Yellow)
      .setTitle(`🎓 Confirm ${meta.label} Training Package`)
      .setDescription(
        `**Player:** ${sess.trainingPlayerName} (${sess.trainingPlayerPos})\n` +
        `**Tier:** ${meta.label} — **${cLabel} attributes** rolled · up to +${meta.points} pts each\n` +
        `**Training Goal:** ${goalLabel} — ${goalDesc}\n` +
        `**Cost:** ${meta.cost.toLocaleString()} coins\n` +
        `**Your balance:** ${user.balance.toLocaleString()} coins\n\n` +
        "The lottery will roll when you confirm. All rolled attribute changes will be posted to your commissioner.",
      )],
    components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_buy_training_execute").setLabel("✅ Confirm Purchase").setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId("ac_hub").setLabel("✖ Cancel").setStyle(ButtonStyle.Secondary),
      ),
    ],
  });
}

// Execute — lottery roll, deduct, record, notify commissioner with before/after values
async function handleBuyTrainingExecute(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid  = interaction.guildId!;
  const tier = sess.trainingTier as TrainingTier | undefined;
  const goal = sess.trainingGoal ?? "balanced";
  if (!tier || !TRAINING_TIERS[tier] || !sess.trainingPlayerName) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Session expired. Please start again.")], components: [backToHubRow()] });
    return;
  }

  const meta   = TRAINING_TIERS[tier];
  const season = await getOrCreateActiveSeason(gid);
  const user   = await getOrCreateUser(interaction.user.id, interaction.user.username, gid);

  if (user.balance < meta.cost) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ Insufficient coins. You need **${meta.cost.toLocaleString()}** but only have **${user.balance.toLocaleString()}**.`)], components: [backToHubRow()] });
    return;
  }

  if (meta.limit < 999 && meta.seasonStatKey) {
    const stats = await getSeasonStats(interaction.user.id, season.id);
    const used  = (stats as any)[meta.seasonStatKey] as number ?? 0;
    if (used >= meta.limit) {
      await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ You have used all **${meta.limit}** ${meta.label} training packages this season.`)], components: [backToHubRow()] });
      return;
    }
  }

  // Fetch player attributes first so we can filter 99-capped attrs from the lottery pool
  let playerAttrs: Record<string, number> = {};
  if (sess.trainingPlayerId) {
    const seasonId   = await getRosterSeasonId(gid);
    const rosterRows = await db.select({ attributes: franchiseRostersTable.attributes })
      .from(franchiseRostersTable)
      .where(and(
        eq(franchiseRostersTable.seasonId, seasonId),
        eq(franchiseRostersTable.playerId, sess.trainingPlayerId),
      ))
      .limit(1);
    playerAttrs = (rosterRows[0]?.attributes as Record<string, number> | null | undefined) ?? {};
  }

  // 🎲 Step 1 — Roll how many attributes are upgraded (tier-biased, higher tier → more attrs)
  const attrCount   = rollAttrCount(tier);
  // 🎲 Step 2 — Roll which attributes (weighted by goal, without replacement, excludes 99s)
  const rolledAttrs = rollTrainingAttrs(goal, playerAttrs, sess.trainingPlayerPos ?? "", attrCount);
  // 🎲 Step 3 — Roll points per attribute (ascending weights → biased toward tier max)
  type TrainingResult = { attr: string; before: number | null; after: number | null; points: number };
  const results: TrainingResult[] = rolledAttrs.map(attr => {
    const before = playerAttrs[attr] !== undefined ? playerAttrs[attr]! : null;
    const points = rollTierPoints(meta.points, before ?? 0);
    const after  = before !== null ? before + points : null;
    return { attr, before, after, points };
  });

  const resultLines     = results.map(r =>
    r.before !== null
      ? `• **${r.attr}:** ${r.before} → **${r.after}** (+${r.points})`
      : `• +${r.points} ${r.attr}`,
  );
  const beforeAfterText  = `**${results.length} attribute${results.length !== 1 ? "s" : ""} upgraded:**\n${resultLines.join("\n")}`;
  const attrNamesSummary = results.map(r => `${r.attr} +${r.points}`).join(", ");

  await deductBalance(interaction.user.id, meta.cost, gid);
  await logTransaction(
    interaction.user.id, -meta.cost, "purchase",
    `${meta.label} Training Package — ${sess.trainingPlayerName} — ${goal} goal — ${attrNamesSummary}`, gid,
  );

  const [inserted] = await db.insert(purchasesTable).values({
    discordId:      interaction.user.id,
    seasonId:       season.id,
    purchaseType:   meta.purchaseType,
    playerName:     sess.trainingPlayerName,
    playerPosition: sess.trainingPlayerPos ?? "",
    attributeName:  attrNamesSummary,
    cost:           meta.cost,
    status:         "pending",
    notes:          `Training ${tier} (${goal} goal) — ${sess.trainingPlayerName} — ${attrNamesSummary}`,
  }).returning({ id: purchasesTable.id });

  if (meta.seasonStatKey === "trainingGoldPurchased") {
    await db.update(seasonStatsTable)
      .set({ trainingGoldPurchased: sql`${seasonStatsTable.trainingGoldPurchased} + 1` })
      .where(and(eq(seasonStatsTable.discordId, interaction.user.id), eq(seasonStatsTable.seasonId, season.id)));
  } else if (meta.seasonStatKey === "trainingSilverPurchased") {
    await db.update(seasonStatsTable)
      .set({ trainingSilverPurchased: sql`${seasonStatsTable.trainingSilverPurchased} + 1` })
      .where(and(eq(seasonStatsTable.discordId, interaction.user.id), eq(seasonStatsTable.seasonId, season.id)));
  }

  await sendCommissionerNotification(interaction as any, meta.purchaseType as any, inserted!.id, {
    playerName:      sess.trainingPlayerName,
    playerPos:       sess.trainingPlayerPos ?? "",
    trainingGoal:    goal,
    trainingResults: beforeAfterText,
    attributeName:   attrNamesSummary,
    tier,
  });

  await interaction.update({
    embeds: [new EmbedBuilder()
      .setColor(Colors.Green)
      .setTitle("🎓 Training Package Purchased!")
      .setDescription(
        `**${meta.label} Training Package** purchased for **${sess.trainingPlayerName}** (${sess.trainingPlayerPos})!\n\n` +
        `🎲 **Lottery Result:** ${beforeAfterText}\n\n` +
        `Your commissioner has been notified and will apply this upgrade. **${meta.cost.toLocaleString()} coins** deducted.`,
      )],
    components: [backToHubRow()],
  });
}

// ── Wager ─────────────────────────────────────────────────────────────────────

/** Convert a currentWeek string (e.g. "1", "wildcard") to the integer weekIndex
 *  stored in franchise_schedule rows. Regular seasons are 0-based; playoffs use
 *  the canonical 1018/1019/1020/1022 values from PLAYOFF_WEEK_META. */
function weekKeyToIndex(weekKey: string): number | null {
  const num = parseInt(weekKey, 10);
  if (!isNaN(num) && num >= 1 && num <= 18) return num - 1;
  const meta = PLAYOFF_WEEK_META[weekKey];
  return meta ? meta.weekIndex : null;
}

// ── Wager helpers ─────────────────────────────────────────────────────────────

function spreadLabel(spread: number): string {
  return spread > 0 ? `+${spread}` : `${spread}`;
}

function spreadDescription(myTeam: string, theirTeam: string, spread: number): string {
  if (spread < 0) return `**${myTeam}** must win by more than **${Math.abs(spread)}** points\n\`${myTeam} score − ${Math.abs(spread)} > ${theirTeam} score\``;
  if (spread === 0) return `**${myTeam}** must win outright\n\`${myTeam} score > ${theirTeam} score\``;
  return `**${myTeam}** can lose by up to **${spread}** points and still cover\n\`${myTeam} score > ${theirTeam} score − ${spread}\``;
}

async function buildOpponentSelectRows(
  gid: string,
  excludeDiscordId: string,
  selectedOpponentId?: string,
): Promise<ActionRowBuilder<StringSelectMenuBuilder | ButtonBuilder>[]> {
  const linkedUsers = await db.select({
    discordId: usersTable.discordId,
    discordUsername: usersTable.discordUsername,
    team: usersTable.team,
  }).from(usersTable)
    .where(and(
      eq(usersTable.guildId, gid),
      isNotNull(usersTable.team),
      ne(usersTable.team, ""),
      ne(usersTable.discordId, excludeDiscordId),
    ));

  const afcUsers = linkedUsers.filter(u => lookupNflDivision(u.team!)?.conference === "AFC");
  const nfcUsers = linkedUsers.filter(u => lookupNflDivision(u.team!)?.conference === "NFC");

  const rows: ActionRowBuilder<StringSelectMenuBuilder | ButtonBuilder>[] = [];

  if (afcUsers.length > 0) {
    const menu = new StringSelectMenuBuilder()
      .setCustomId("ac_wager_opponent_afc")
      .setPlaceholder("AFC — Pick Opponent")
      .addOptions(afcUsers.slice(0, 25).map(u =>
        new StringSelectMenuOptionBuilder()
          .setLabel(`${u.team} — ${u.discordUsername}`)
          .setValue(u.discordId)
          .setDefault(u.discordId === selectedOpponentId),
      ));
    rows.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu));
  }

  if (nfcUsers.length > 0) {
    const menu = new StringSelectMenuBuilder()
      .setCustomId("ac_wager_opponent_nfc")
      .setPlaceholder("NFC — Pick Opponent")
      .addOptions(nfcUsers.slice(0, 25).map(u =>
        new StringSelectMenuOptionBuilder()
          .setLabel(`${u.team} — ${u.discordUsername}`)
          .setValue(u.discordId)
          .setDefault(u.discordId === selectedOpponentId),
      ));
    rows.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu));
  }

  rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("ac_wager_send")
      .setLabel("📨 Send Wager")
      .setStyle(ButtonStyle.Success)
      .setDisabled(!selectedOpponentId),
    new ButtonBuilder().setCustomId("ac_wager_back_to_spread").setLabel("← Back").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_hub").setLabel("✖ Close").setStyle(ButtonStyle.Secondary),
  ));

  return rows;
}

// ── Wager Step 1: Game Select ─────────────────────────────────────────────────

async function handleWagerStart(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  const settings = await getServerSettings(gid);
  if (!settings.coinEconomy || !settings.wagerEnabled) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Wagers are currently disabled by the commissioners.")], components: [backToHubRow()] });
    return;
  }

  const season = await getOrCreateActiveSeason(gid);
  const weekIndex = weekKeyToIndex((season as any).currentWeek ?? "1");

  if (weekIndex === null) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Orange).setTitle("⚔️ Place a Wager").setDescription("No schedule data found for the current week. Ask a commissioner to import the schedule from MCA.")], components: [backToHubRow()] });
    return;
  }

  let scheduleRows = await db.select({
    id: franchiseScheduleTable.id, homeTeamId: franchiseScheduleTable.homeTeamId,
    awayTeamId: franchiseScheduleTable.awayTeamId, homeTeamName: franchiseScheduleTable.homeTeamName,
    awayTeamName: franchiseScheduleTable.awayTeamName,
  }).from(franchiseScheduleTable)
    .where(and(eq(franchiseScheduleTable.seasonId, season.id), eq(franchiseScheduleTable.weekIndex, weekIndex)))
    .limit(32);

  if (scheduleRows.length === 0 && weekIndex >= 1000) {
    scheduleRows = await db.select({
      id: franchiseScheduleTable.id, homeTeamId: franchiseScheduleTable.homeTeamId,
      awayTeamId: franchiseScheduleTable.awayTeamId, homeTeamName: franchiseScheduleTable.homeTeamName,
      awayTeamName: franchiseScheduleTable.awayTeamName,
    }).from(franchiseScheduleTable)
      .where(and(eq(franchiseScheduleTable.seasonId, season.id), eq(franchiseScheduleTable.weekIndex, weekIndex - 1000)))
      .limit(32);
  }

  if (!scheduleRows.length) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Orange).setTitle("⚔️ Place a Wager").setDescription("No schedule data found for the current week. Ask a commissioner to import the schedule from MCA.")], components: [backToHubRow()] });
    return;
  }

  // Filter to H2H: both teams must have a linked discord user via franchise_mca_teams
  const mcaTeams = await db.select({
    teamId: franchiseMcaTeamsTable.teamId,
    discordId: franchiseMcaTeamsTable.discordId,
  }).from(franchiseMcaTeamsTable)
    .where(and(eq(franchiseMcaTeamsTable.seasonId, season.id), isNotNull(franchiseMcaTeamsTable.discordId)));

  const linkedTeamIds = new Set(mcaTeams.filter(m => m.discordId).map(m => m.teamId));
  const h2hGames = scheduleRows.filter(g => linkedTeamIds.has(g.homeTeamId) && linkedTeamIds.has(g.awayTeamId));

  if (!h2hGames.length) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Orange).setTitle("⚔️ Place a Wager").setDescription("No head-to-head games found this week (both teams must be linked to active users).")], components: [backToHubRow()] });
    return;
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_wager_game")
    .setPlaceholder("Select a game to wager on…")
    .addOptions(h2hGames.slice(0, 25).map(g =>
      new StringSelectMenuOptionBuilder()
        .setLabel(`${g.homeTeamName} vs ${g.awayTeamName}`)
        .setValue(String(g.id)),
    ));

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Orange).setTitle("⚔️ Place a Wager — Step 1 of 4").setDescription("Select the head-to-head game you want to wager on.\n\nOnly games where **both teams are linked to active users** are shown.")],
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu), cancelRow()],
  });
}

// ── Wager Step 2: Team Pick ───────────────────────────────────────────────────

async function handleWagerGameSelect(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const gameId = Number(interaction.values[0]);
  sess.scheduleGameId = String(gameId);

  const gid = interaction.guildId!;
  const season = await getOrCreateActiveSeason(gid);

  const game = (await db.select().from(franchiseScheduleTable).where(eq(franchiseScheduleTable.id, gameId)).limit(1))[0];
  if (!game) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Game not found.")], components: [backToHubRow()] });
    return;
  }

  // Resolve which discord users are linked to each side
  const [homeMca] = await db.select({ discordId: franchiseMcaTeamsTable.discordId })
    .from(franchiseMcaTeamsTable)
    .where(and(eq(franchiseMcaTeamsTable.seasonId, season.id), eq(franchiseMcaTeamsTable.teamId, game.homeTeamId)))
    .limit(1);
  const [awayMca] = await db.select({ discordId: franchiseMcaTeamsTable.discordId })
    .from(franchiseMcaTeamsTable)
    .where(and(eq(franchiseMcaTeamsTable.seasonId, season.id), eq(franchiseMcaTeamsTable.teamId, game.awayTeamId)))
    .limit(1);

  sess.wagerHomeTeam      = game.homeTeamName;
  sess.wagerAwayTeam      = game.awayTeamName;
  sess.wagerHomeDiscordId = homeMca?.discordId ?? undefined;
  sess.wagerAwayDiscordId = awayMca?.discordId ?? undefined;

  const userLine = (homeMca?.discordId && awayMca?.discordId)
    ? `\n🏠 <@${homeMca.discordId}> vs ✈️ <@${awayMca.discordId}>`
    : "";

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_wager_pick:home").setLabel(`🏠 ${game.homeTeamName}`).setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ac_wager_pick:away").setLabel(`✈️ ${game.awayTeamName}`).setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ac_hub").setLabel("✖ Cancel").setStyle(ButtonStyle.Secondary),
  );

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Orange).setTitle("⚔️ Place a Wager — Step 2 of 4").setDescription(`**${game.homeTeamName} vs ${game.awayTeamName}**${userLine}\n\nWhich team are you backing?`)],
    components: [row],
  });
}

// ── Wager Step 3: Spread Select ───────────────────────────────────────────────

async function handleWagerTeamPick(interaction: ButtonInteraction, sess: ActionsSession) {
  const side = interaction.customId.split(":")[1]! as "home" | "away";
  sess.wagerSide = side;
  sess.wagerTeam = side === "home" ? sess.wagerHomeTeam : sess.wagerAwayTeam;
  sess.wagerChallengerTeam = sess.wagerTeam;

  const myTeam    = sess.wagerTeam ?? "Your Team";
  const theirTeam = side === "home" ? (sess.wagerAwayTeam ?? "Opponent") : (sess.wagerHomeTeam ?? "Opponent");

  const spreadOptions: StringSelectMenuOptionBuilder[] = [];
  for (let s = -10; s <= 10; s++) {
    const label = s === 0 ? "0 (straight win)" : s > 0 ? `+${s}` : `${s}`;
    const desc  = s < 0 ? `${myTeam} must win by more than ${Math.abs(s)}`
      : s === 0        ? `${myTeam} must win outright`
      :                  `${myTeam} can lose by up to ${s} and still cover`;
    spreadOptions.push(new StringSelectMenuOptionBuilder().setLabel(label).setValue(String(s)).setDescription(desc));
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_wager_spread")
    .setPlaceholder("Select your point spread…")
    .addOptions(spreadOptions);

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Orange).setTitle("⚔️ Place a Wager — Step 3 of 4").setDescription(`You're backing **${myTeam}** vs **${theirTeam}**.\n\nSelect your point spread. Negative means your team must win by more; positive means they can lose by that much and still cover.`)],
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu), cancelRow()],
  });
}

async function handleWagerSpreadSelect(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const spread = parseInt(interaction.values[0]!, 10);
  sess.wagerSpread = spread;

  const myTeam    = sess.wagerTeam ?? "Your Team";
  const theirTeam = sess.wagerSide === "home" ? (sess.wagerAwayTeam ?? "Opponent") : (sess.wagerHomeTeam ?? "Opponent");

  await interaction.update({
    embeds: [new EmbedBuilder()
      .setColor(Colors.Orange)
      .setTitle("⚔️ Place a Wager — Step 3 of 4 (Spread Confirmed)")
      .setDescription(
        `**Spread: ${spreadLabel(spread)}**\n\n` +
        spreadDescription(myTeam, theirTeam, spread) + "\n\n" +
        `If scores are tied after the spread is applied, the bet is a **push** — both players get their coins back.\n\n` +
        `Click **Next** to enter your wager amount.`,
      )],
    components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId("ac_wager_spread_next").setLabel("Next →").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId("ac_wager_back_to_team").setLabel("← Back").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("ac_hub").setLabel("✖ Close").setStyle(ButtonStyle.Secondary),
    )],
  });
}

async function handleWagerBackToTeam(interaction: ButtonInteraction, sess: ActionsSession) {
  const homeTeam = sess.wagerHomeTeam ?? "Home";
  const awayTeam = sess.wagerAwayTeam ?? "Away";
  const userLine = (sess.wagerHomeDiscordId && sess.wagerAwayDiscordId)
    ? `\n🏠 <@${sess.wagerHomeDiscordId}> vs ✈️ <@${sess.wagerAwayDiscordId}>`
    : "";
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_wager_pick:home").setLabel(`🏠 ${homeTeam}`).setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ac_wager_pick:away").setLabel(`✈️ ${awayTeam}`).setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ac_hub").setLabel("✖ Cancel").setStyle(ButtonStyle.Secondary),
  );
  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Orange).setTitle("⚔️ Place a Wager — Step 2 of 4").setDescription(`**${homeTeam} vs ${awayTeam}**${userLine}\n\nWhich team are you backing?`)],
    components: [row],
  });
}

async function handleWagerSpreadNext(interaction: ButtonInteraction, _sess: ActionsSession) {
  await interaction.showModal(
    new ModalBuilder()
      .setCustomId("ac_modal_wageramount")
      .setTitle("Wager Amount")
      .addComponents(
        new ActionRowBuilder<TextInputBuilder>().addComponents(
          new TextInputBuilder()
            .setCustomId("amount")
            .setLabel("Coins to wager (each player stakes this)")
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("e.g. 500")
            .setRequired(true)
            .setMaxLength(10),
        ),
      ),
  );
}

// ── Wager Step 4: Opponent Select → Send ─────────────────────────────────────

async function handleWagerAmountSubmit(interaction: ModalSubmitInteraction, sess: ActionsSession) {
  const amountStr = interaction.fields.getTextInputValue("amount").trim();
  const amount    = parseInt(amountStr, 10);

  if (isNaN(amount) || amount < 1) {
    await interaction.reply({ content: "❌ Invalid amount. Enter a positive whole number.", ephemeral: true });
    return;
  }

  const gid  = interaction.guildId!;
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username, gid);
  if (user.balance < amount) {
    await interaction.reply({ content: `❌ Insufficient coins. You have **${user.balance.toLocaleString()}**, wager is **${amount.toLocaleString()}**.`, ephemeral: true });
    return;
  }

  sess.wagerAmount = amount;

  const myTeam    = sess.wagerTeam ?? "Your Team";
  const theirTeam = sess.wagerSide === "home" ? (sess.wagerAwayTeam ?? "Opponent") : (sess.wagerHomeTeam ?? "Opponent");
  const spread    = sess.wagerSpread ?? 0;

  const rows = await buildOpponentSelectRows(gid, interaction.user.id);

  if (rows.length === 1) {
    await interaction.reply({ content: "❌ No other linked users found to wager against.", ephemeral: true });
    return;
  }

  await interaction.reply({
    ephemeral: true,
    embeds: [new EmbedBuilder()
      .setColor(Colors.Orange)
      .setTitle("⚔️ Place a Wager — Step 4 of 4")
      .setDescription(
        `**Your pick:** ${myTeam} (${spreadLabel(spread)})\n` +
        `**Amount:** ${amount.toLocaleString()} coins each\n\n` +
        spreadDescription(myTeam, theirTeam, spread) + "\n\n" +
        `Select the opponent you want to challenge from the dropdowns below, then click **Send Wager**.`,
      )],
    components: rows as ActionRowBuilder<any>[],
  });
}

async function handleWagerOpponentSelect(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const opponentId = interaction.values[0]!;
  sess.wagerOpponentId = opponentId;

  const gid = interaction.guildId!;
  const [oppRecord] = await db.select({ discordUsername: usersTable.discordUsername, team: usersTable.team })
    .from(usersTable).where(and(eq(usersTable.discordId, opponentId), eq(usersTable.guildId, gid))).limit(1);
  sess.wagerOpponentTeam = oppRecord?.team ?? undefined;

  const myTeam    = sess.wagerTeam ?? "Your Team";
  const theirTeam = sess.wagerSide === "home" ? (sess.wagerAwayTeam ?? "Opponent") : (sess.wagerHomeTeam ?? "Opponent");
  const spread    = sess.wagerSpread ?? 0;
  const amount    = sess.wagerAmount ?? 0;

  const rows = await buildOpponentSelectRows(gid, interaction.user.id, opponentId);

  await interaction.update({
    embeds: [new EmbedBuilder()
      .setColor(Colors.Orange)
      .setTitle("⚔️ Place a Wager — Step 4 of 4")
      .setDescription(
        `**Your pick:** ${myTeam} (${spreadLabel(spread)})\n` +
        `**Amount:** ${amount.toLocaleString()} coins each\n\n` +
        `✅ **Opponent selected:** <@${opponentId}> (${oppRecord?.team ?? "Unknown"})\n\n` +
        `Click **Send Wager** to challenge them, or pick a different opponent above.`,
      )],
    components: rows as ActionRowBuilder<any>[],
  });
}

async function handleWagerBackToSpread(interaction: ButtonInteraction, sess: ActionsSession) {
  const myTeam    = sess.wagerTeam ?? "Your Team";
  const theirTeam = sess.wagerSide === "home" ? (sess.wagerAwayTeam ?? "Opponent") : (sess.wagerHomeTeam ?? "Opponent");
  const spread    = sess.wagerSpread ?? 0;

  await interaction.update({
    embeds: [new EmbedBuilder()
      .setColor(Colors.Orange)
      .setTitle("⚔️ Place a Wager — Step 3 of 4 (Spread Confirmed)")
      .setDescription(
        `**Spread: ${spreadLabel(spread)}**\n\n` +
        spreadDescription(myTeam, theirTeam, spread) + "\n\n" +
        `Click **Next** to set your wager amount.`,
      )],
    components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId("ac_wager_spread_next").setLabel("Next →").setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId("ac_wager_back_to_team").setLabel("← Back").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId("ac_hub").setLabel("✖ Close").setStyle(ButtonStyle.Secondary),
    )],
  });
}

async function handleWagerSend(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;

  if (!sess.wagerOpponentId || !sess.wagerTeam || !sess.wagerAmount || sess.wagerSpread === undefined || !sess.wagerSide) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Missing wager details. Please start over from the hub.")], components: [backToHubRow()] });
    return;
  }

  const challenger = await getOrCreateUser(interaction.user.id, interaction.user.username, gid);
  if (challenger.balance < sess.wagerAmount) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ Insufficient coins. Your balance: **${challenger.balance.toLocaleString()}**, wager: **${sess.wagerAmount.toLocaleString()}**.`)], components: [backToHubRow()] });
    return;
  }

  const teamFor     = sess.wagerTeam;
  const teamAgainst = sess.wagerSide === "home" ? (sess.wagerAwayTeam ?? "Opponent") : (sess.wagerHomeTeam ?? "Opponent");

  const [oppRecord] = await db.select({ discordUsername: usersTable.discordUsername })
    .from(usersTable).where(and(eq(usersTable.discordId, sess.wagerOpponentId), eq(usersTable.guildId, gid))).limit(1);

  await getOrCreateUser(sess.wagerOpponentId, oppRecord?.discordUsername ?? "Unknown", gid);

  const [wager] = await db.insert(wagersTable).values({
    guildId:            gid,
    challengerId:       interaction.user.id,
    challengerUsername: interaction.user.username,
    opponentId:         sess.wagerOpponentId,
    opponentUsername:   oppRecord?.discordUsername ?? "Unknown",
    amount:             sess.wagerAmount,
    pot:                sess.wagerAmount * 2,
    teamFor,
    teamAgainst,
    status:             "pending",
    spread:             sess.wagerSpread,
    challengerSide:     sess.wagerSide,
    scheduleGameId:     sess.scheduleGameId ? parseInt(sess.scheduleGameId, 10) : undefined,
  }).returning();

  if (!wager) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Failed to create wager record. Please try again.")], components: [backToHubRow()] });
    return;
  }

  // Close the ephemeral menu
  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Green).setTitle("✅ Wager Challenge Sent").setDescription(`Challenge sent to <@${sess.wagerOpponentId}>! Check the channel for the challenge message.\n\n**Wager #${wager.id}**`)],
    components: [],
  });

  // Post public challenge to the channel
  const [challengerMember, opponentMember] = await Promise.all([
    interaction.guild?.members.fetch(interaction.user.id).catch(() => null),
    interaction.guild?.members.fetch(sess.wagerOpponentId).catch(() => null),
  ]);
  const challengerName = challengerMember?.displayName ?? interaction.user.username;
  const opponentName   = opponentMember?.displayName ?? oppRecord?.discordUsername ?? "Opponent";

  const spread    = sess.wagerSpread;
  const spreadStr = spreadLabel(spread);
  const spreadDesc = spreadDescription(teamFor, teamAgainst, spread);

  const challengeEmbed = new EmbedBuilder()
    .setColor(Colors.Yellow)
    .setTitle("⚔️ Wager Challenge!")
    .setDescription(`<@${interaction.user.id}> has challenged <@${sess.wagerOpponentId}> to a coin wager!`)
    .addFields(
      { name: "💰 Stake",                         value: `**${sess.wagerAmount.toLocaleString()} coins** each (pot: **${(sess.wagerAmount * 2).toLocaleString()}**)` },
      { name: `🏈 ${challengerName} is backing`,  value: `**${teamFor}** (spread: ${spreadStr})`, inline: true },
      { name: `🏈 ${opponentName} is backing`,    value: `**${teamAgainst}**`,                    inline: true },
      { name: "📊 Challenger's Spread",            value: spreadDesc },
      { name: "📋 Status",                         value: "⏳ Waiting for opponent to respond…" },
    )
    .setFooter({ text: `Wager #${wager.id}` })
    .setTimestamp();

  const challengeRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`wager_accept:${wager.id}`).setLabel("✅ Accept Wager").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`wager_refuse:${wager.id}`).setLabel("❌ Refuse").setStyle(ButtonStyle.Danger),
  );

  try {
    if (interaction.channel) {
      const msg = await (interaction.channel as any).send({
        content: `<@${sess.wagerOpponentId}> — you have a wager challenge!`,
        embeds:  [challengeEmbed],
        components: [challengeRow],
      });
      await db.update(wagersTable).set({ challengeMessageId: msg.id }).where(eq(wagersTable.id, wager.id));
    }
  } catch (err) {
    console.error("Failed to send wager challenge message:", err);
  }
}

// ── Coins ─────────────────────────────────────────────────────────────────────

async function handleCoins(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid  = interaction.guildId!;
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username, gid);

  const savingsRow = (await db.select({ balance: userSavingsTable.balance }).from(userSavingsTable)
    .where(eq(userSavingsTable.discordId, interaction.user.id))
    .limit(1))[0];

  const savings = savingsRow?.balance ?? 0;
  const total   = user.balance + savings;

  const embed = new EmbedBuilder()
    .setColor(Colors.Gold)
    .setTitle("🪙 Your Coin Balance")
    .addFields(
      { name: "💰 Wallet",  value: `**${user.balance.toLocaleString()}** coins`, inline: true },
      { name: "🏦 Savings", value: `**${savings.toLocaleString()}** coins`, inline: true },
      { name: "📊 Total",   value: `**${total.toLocaleString()}** coins`, inline: true },
    )
    .setTimestamp();

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_send_coins_modal").setLabel("📤 Send Coins").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ac_transfer").setLabel("💸 Transfer").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_hub").setLabel("← Back").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close").setStyle(ButtonStyle.Danger),
  );

  await interaction.update({ embeds: [embed], components: [row] });
}

async function handleBankTransfer(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid  = interaction.guildId!;
  const [user, savingsRow, rateBps, lastRunRow] = await Promise.all([
    getOrCreateUser(interaction.user.id, interaction.user.username, gid),
    db.select({ balance: userSavingsTable.balance }).from(userSavingsTable)
      .where(eq(userSavingsTable.discordId, interaction.user.id)).limit(1).then(r => r[0]),
    getSavingsInterestRateBps(),
    db.select({ value: payoutConfigTable.value }).from(payoutConfigTable)
      .where(eq(payoutConfigTable.key, "savings_last_interest_at")).limit(1).then(r => r[0]),
  ]);
  const savings = savingsRow?.balance ?? 0;

  // Projected daily interest
  const projectedInterest = rateBps > 0 && savings > 0
    ? Math.ceil(savings * rateBps / 10000)
    : 0;
  const ratePercent = (rateBps / 100).toFixed(2);

  // Time until next payout
  let nextPayoutStr = "~24h from last payout";
  if (lastRunRow?.value) {
    const lastRunMs   = lastRunRow.value * 1000;
    const nextRunMs   = lastRunMs + 24 * 60 * 60 * 1000;
    const msleft      = nextRunMs - Date.now();
    if (msleft > 0) {
      const hLeft = Math.floor(msleft / (60 * 60 * 1000));
      const mLeft = Math.floor((msleft % (60 * 60 * 1000)) / 60000);
      nextPayoutStr = `~${hLeft}h ${mLeft}m`;
    } else {
      nextPayoutStr = "very soon";
    }
  }

  let interestFieldValue: string;
  if (rateBps <= 0) {
    interestFieldValue = "No interest rate currently set.";
  } else if (savings <= 0) {
    interestFieldValue = `Rate: **${ratePercent}%**/day\nDeposit coins to start earning.`;
  } else {
    interestFieldValue = `**+${projectedInterest.toLocaleString()} coins** next payout\nRate: **${ratePercent}%**/day · Next: **${nextPayoutStr}**`;
  }

  const embed = new EmbedBuilder()
    .setColor(Colors.Gold)
    .setTitle("💸 Transfer — Choose Direction")
    .setDescription("Move coins between your wallet and savings account.")
    .addFields(
      { name: "💰 Wallet",  value: `**${user.balance.toLocaleString()}** coins`, inline: true },
      { name: "🏦 Savings", value: `**${savings.toLocaleString()}** coins`, inline: true },
      { name: "📈 Projected Interest", value: interestFieldValue, inline: false },
    );

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_transfer_dir:IN").setLabel("➡ Wallet → Savings").setStyle(ButtonStyle.Primary).setDisabled(user.balance <= 0),
    new ButtonBuilder().setCustomId("ac_transfer_dir:OUT").setLabel("⬅ Savings → Wallet").setStyle(ButtonStyle.Success).setDisabled(savings <= 0),
    new ButtonBuilder().setCustomId("ac_coins").setLabel("← Back").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close").setStyle(ButtonStyle.Danger),
  );

  await interaction.update({ embeds: [embed], components: [row] });
}

async function handleBankTransferDir(interaction: ButtonInteraction) {
  const dir   = interaction.customId.split(":")[1] as "IN" | "OUT";
  const label = dir === "IN" ? "Wallet → Savings" : "Savings → Wallet";
  const modal = new ModalBuilder()
    .setCustomId(`ac_modal_transfer:${dir}`)
    .setTitle(`Transfer: ${label}`)
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("amount")
          .setLabel("Amount to transfer (coins)")
          .setStyle(TextInputStyle.Short)
          .setPlaceholder("e.g. 500")
          .setRequired(true)
          .setMaxLength(20),
      ),
    );
  await interaction.showModal(modal);
}

async function handleBankTransferSubmit(interaction: ModalSubmitInteraction) {
  const dir       = interaction.customId.split(":")[1] as "IN" | "OUT";
  const amountStr = interaction.fields.getTextInputValue("amount").trim();
  const amount    = parseInt(amountStr, 10);
  const gid       = interaction.guildId!;

  if (isNaN(amount) || amount < 1) {
    await interaction.reply({ content: "❌ Please enter a valid positive amount.", ephemeral: true });
    return;
  }

  const user = await getOrCreateUser(interaction.user.id, interaction.user.username, gid);
  const savingsRow = (await db.select({ balance: userSavingsTable.balance }).from(userSavingsTable)
    .where(eq(userSavingsTable.discordId, interaction.user.id)).limit(1))[0];
  const savings = savingsRow?.balance ?? 0;

  if (dir === "IN") {
    if (user.balance < amount) {
      await interaction.reply({ content: `❌ Insufficient wallet balance. You have **${user.balance.toLocaleString()}** coins.`, ephemeral: true });
      return;
    }
    await db.transaction(async (tx) => {
      await tx.update(usersTable)
        .set({ balance: user.balance - amount })
        .where(and(eq(usersTable.discordId, interaction.user.id), eq(usersTable.guildId, gid)));
      if (savingsRow) {
        await tx.update(userSavingsTable)
          .set({ balance: savings + amount })
          .where(eq(userSavingsTable.discordId, interaction.user.id));
      } else {
        await tx.insert(userSavingsTable).values({ discordId: interaction.user.id, balance: amount });
      }
    });
    await interaction.reply({
      content: `✅ Transferred **${amount.toLocaleString()}** coins to savings.\n💰 Wallet: **${(user.balance - amount).toLocaleString()}** | 🏦 Savings: **${(savings + amount).toLocaleString()}**`,
      ephemeral: true,
    });
  } else {
    if (savings < amount) {
      await interaction.reply({ content: `❌ Insufficient savings balance. You have **${savings.toLocaleString()}** coins in savings.`, ephemeral: true });
      return;
    }
    await db.transaction(async (tx) => {
      await tx.update(usersTable)
        .set({ balance: user.balance + amount })
        .where(and(eq(usersTable.discordId, interaction.user.id), eq(usersTable.guildId, gid)));
      if (savingsRow) {
        await tx.update(userSavingsTable)
          .set({ balance: savings - amount })
          .where(eq(userSavingsTable.discordId, interaction.user.id));
      }
    });
    await interaction.reply({
      content: `✅ Transferred **${amount.toLocaleString()}** coins to wallet.\n💰 Wallet: **${(user.balance + amount).toLocaleString()}** | 🏦 Savings: **${(savings - amount).toLocaleString()}**`,
      ephemeral: true,
    });
  }
}

async function handleSendCoinsModal(interaction: ButtonInteraction) {
  const modal = new ModalBuilder()
    .setCustomId("ac_modal_sendcoins")
    .setTitle("Send Coins")
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder().setCustomId("recipient").setLabel("Recipient's Discord username or @mention").setStyle(TextInputStyle.Short).setRequired(true),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder().setCustomId("amount").setLabel("Amount (coins)").setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder("e.g. 100"),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder().setCustomId("note").setLabel("Note (optional)").setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(100),
      ),
    );
  await interaction.showModal(modal);
}

async function handleSendCoinsSubmit(interaction: ModalSubmitInteraction, sess: ActionsSession) {
  const recipientInput = interaction.fields.getTextInputValue("recipient").trim().replace(/[<@!>]/g, "");
  const amountStr      = interaction.fields.getTextInputValue("amount").trim();
  const note           = interaction.fields.getTextInputValue("note").trim();
  const gid            = interaction.guildId!;
  const amount         = parseInt(amountStr, 10);

  if (isNaN(amount) || amount < 1) {
    await interaction.reply({ content: "❌ Invalid amount.", ephemeral: true }); return;
  }

  // Try to find recipient by Discord ID or username
  const recipientRow = (await db.select({ discordId: usersTable.discordId, discordUsername: usersTable.discordUsername })
    .from(usersTable)
    .where(and(
      eq(usersTable.guildId, gid),
      sql`lower(${usersTable.discordUsername}) = lower(${recipientInput}) OR ${usersTable.discordId} = ${recipientInput}`,
    ))
    .limit(1))[0];

  if (!recipientRow) {
    await interaction.reply({ content: `❌ Could not find user **${recipientInput}** in this server.`, ephemeral: true }); return;
  }

  if (recipientRow.discordId === interaction.user.id) {
    await interaction.reply({ content: "❌ You can't send coins to yourself.", ephemeral: true }); return;
  }

  const sender = await getOrCreateUser(interaction.user.id, interaction.user.username, gid);
  if (sender.balance < amount) {
    await interaction.reply({ content: `❌ Insufficient coins. You have **${sender.balance.toLocaleString()}**, trying to send **${amount.toLocaleString()}**.`, ephemeral: true }); return;
  }

  await getOrCreateUser(recipientRow.discordId, recipientRow.discordUsername, gid);
  await deductBalance(interaction.user.id, amount, gid);
  await addBalance(recipientRow.discordId, amount, gid);
  await logTransaction(interaction.user.id, -amount, "sendcoins_sent",     `Sent to ${recipientRow.discordUsername}${note ? `: ${note}` : ""}`,        gid, recipientRow.discordId);
  await logTransaction(recipientRow.discordId, amount, "sendcoins_received", `Received from ${interaction.user.username}${note ? `: ${note}` : ""}`, gid, interaction.user.id);

  await interaction.reply({
    ephemeral: true,
    embeds: [new EmbedBuilder()
      .setColor(Colors.Green)
      .setTitle("✅ Coins Sent")
      .setDescription(`Sent **${amount.toLocaleString()} coins** to **${recipientRow.discordUsername}**${note ? `\n*"${note}"*` : ""}`)],
    components: [backToHubRow()],
  });
}

// ── Interview ─────────────────────────────────────────────────────────────────

async function handleInterview(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  const [, season] = await Promise.all([
    getOrCreateUser(interaction.user.id, interaction.user.username, gid),
    getOrCreateActiveSeason(gid),
  ]);
  const currentWeek = (season as any).currentWeek ?? "1";
  const wkLabel     = weekLabel(currentWeek);

  const existing = (await db.select({ id: interviewRequestsTable.id, status: interviewRequestsTable.status })
    .from(interviewRequestsTable)
    .where(and(
      eq(interviewRequestsTable.discordId, interaction.user.id),
      eq(interviewRequestsTable.guildId, gid),
      eq(interviewRequestsTable.week, currentWeek),
      inArray(interviewRequestsTable.status, ["pending", "approved"]),
    ))
    .limit(1))[0];

  if (existing) {
    const stateLabel = existing.status === "approved" ? "already been approved" : "already been submitted and is pending review";
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(Colors.Yellow)
        .setTitle("⚠️ Interview Already Submitted")
        .setDescription(`Your interview for **${wkLabel}** has ${stateLabel} (ID: \`${existing.id}\`).\nOnly one interview per week.`)],
      components: [backToHubRow()],
    });
    return;
  }

  // Show type-selection screen
  const embed = new EmbedBuilder()
    .setColor(Colors.Blurple)
    .setTitle("🎙️ Request an Interview")
    .setDescription(
      `Choose the type of interview you'd like to submit for **${wkLabel}**.\n\n` +
      "**Pre-Game** — Talk about preparation, game plan, and expectations before the match.\n" +
      "**Post-Game** — Reflect on what happened, adjustments made, and the result.\n" +
      "**General** — A non-game-specific interview about your franchise and vision.",
    )
    .setFooter({ text: "You'll receive 3 randomly selected questions based on your choice." });

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("interview_typepick:pregame")
      .setLabel("🏟️ Pre-Game")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId("interview_typepick:postgame")
      .setLabel("📊 Post-Game")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId("interview_typepick:general")
      .setLabel("🎤 General")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_hub").setLabel("← Back").setStyle(ButtonStyle.Secondary),
  );

  await interaction.update({ embeds: [embed], components: [row] });
}

export async function handleInterviewTypePick(interaction: ButtonInteraction) {
  const type = interaction.customId.split(":")[1] as InterviewType;
  const gid  = interaction.guildId!;

  const season = await getOrCreateActiveSeason(gid);
  const currentWeek = (season as any).currentWeek ?? "1";
  const wkLabel     = weekLabel(currentWeek);

  // One-per-week guard — reply ephemerally if already submitted
  const existing = (await db.select({ id: interviewRequestsTable.id, status: interviewRequestsTable.status })
    .from(interviewRequestsTable)
    .where(and(
      eq(interviewRequestsTable.discordId, interaction.user.id),
      eq(interviewRequestsTable.guildId, gid),
      eq(interviewRequestsTable.week, currentWeek),
      inArray(interviewRequestsTable.status, ["pending", "approved"]),
    ))
    .limit(1))[0];

  if (existing) {
    const stateLabel = existing.status === "approved" ? "already been approved" : "already been submitted and is pending review";
    await interaction.reply({
      ephemeral: true,
      content: `⚠️ Your interview for **${wkLabel}** has ${stateLabel} (ID: \`${existing.id}\`). Only one interview per week.`,
    });
    return;
  }

  // Pick 3 questions and immediately show modal — do NOT update the message
  // so dismissing the modal (× or Back) naturally returns to type selection.
  const pool       = getQuestionPool(type);
  const title      = interviewTypeLabel(type);
  const [i1, i2, i3] = pickThreeIndices(pool.length);
  const q1 = pool[i1]!;
  const q2 = pool[i2]!;
  const q3 = pool[i3]!;
  const indicesStr = `${i1},${i2},${i3}`;
  const truncLabel = (q: string) => q.length <= 45 ? q : q.slice(0, 42) + "...";

  const modal = new ModalBuilder()
    .setCustomId(`interview_answer_modal:${indicesStr}:${type}`)
    .setTitle(`🎙️ ${title}`);

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("a1")
        .setLabel(truncLabel(q1))
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true)
        .setMinLength(10)
        .setMaxLength(1000)
        .setPlaceholder("Type your answer here…"),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("a2")
        .setLabel(truncLabel(q2))
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true)
        .setMinLength(10)
        .setMaxLength(1000)
        .setPlaceholder("Type your answer here…"),
    ),
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("a3")
        .setLabel(truncLabel(q3))
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true)
        .setMinLength(10)
        .setMaxLength(1000)
        .setPlaceholder("Type your answer here…"),
    ),
  );

  await interaction.showModal(modal);
}

// ── Tweet ─────────────────────────────────────────────────────────────────────

async function handleTweetModal(interaction: ButtonInteraction) {
  const modal = new ModalBuilder()
    .setCustomId("ac_modal_tweet")
    .setTitle("Post a Tweet")
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("tweet_text")
          .setLabel("Your tweet (max 280 characters)")
          .setStyle(TextInputStyle.Paragraph)
          .setMaxLength(280)
          .setRequired(true)
          .setPlaceholder("Write your tweet here…"),
      ),
    );
  await interaction.showModal(modal);
}

async function handleTweetSubmit(interaction: ModalSubmitInteraction, sess: ActionsSession) {
  const text = interaction.fields.getTextInputValue("tweet_text").trim();
  const gid  = interaction.guildId!;

  if (!text) { await interaction.reply({ content: "❌ Tweet cannot be empty.", ephemeral: true }); return; }

  const [season, user] = await Promise.all([
    getOrCreateActiveSeason(gid),
    getOrCreateUser(interaction.user.id, interaction.user.username, gid),
  ]);

  const weeklyLimit = await getPayoutValue("tweet_weekly_limit", gid);
  const payout      = await getPayoutValue("tweet_payout", gid);
  const currentWeek = (season as any).currentWeek ?? "1";

  // Count tweets this week
  const tweetsThisWeek = (await db.select({ id: guildTweetsTable.id })
    .from(guildTweetsTable)
    .where(and(
      eq(guildTweetsTable.discordId, interaction.user.id),
      eq(guildTweetsTable.guildId, gid),
      eq(guildTweetsTable.weekNumber, String(currentWeek)),
    ))).length;

  const willEarnCoins = weeklyLimit === 0 || tweetsThisWeek < weeklyLimit;
  const earnedCoins   = willEarnCoins ? payout : 0;

  await db.insert(guildTweetsTable).values({
    discordId:    interaction.user.id,
    guildId:      gid,
    seasonId:     season.id,
    weekNumber:   String(currentWeek),
    tweetText:    text,
    coinsAwarded: earnedCoins,
  });

  if (earnedCoins > 0) {
    await addBalance(interaction.user.id, earnedCoins, gid);
    await logTransaction(interaction.user.id, earnedCoins, "addcoins", `Tweet payout — Week ${currentWeek}`, gid);
  }

  // Post the tweet to the league twitter channel
  const twitterChannelId = await getGuildChannel(gid, CHANNEL_KEYS.LEAGUE_TWITTER);
  if (twitterChannelId) {
    try {
      const ch = await interaction.client.channels.fetch(twitterChannelId);
      if (ch?.isTextBased()) {
        await (ch as TextChannel).send({
          embeds: [new EmbedBuilder()
            .setColor(Colors.Blue)
            .setAuthor({
              name: `@${interaction.user.username}${user.team ? ` · ${user.team}` : ""}`,
              iconURL: interaction.user.displayAvatarURL(),
            })
            .setDescription(text)
            .setFooter({ text: `Week ${currentWeek} 🐦 League Twitter` })
            .setTimestamp()],
        });
      }
    } catch { /* channel fetch/send failure is non-fatal */ }
  }

  const limitNote = !willEarnCoins
    ? `\n*Weekly tweet limit reached (${weeklyLimit}) — no coins awarded.*`
    : earnedCoins > 0
      ? `\n**+${earnedCoins} coins** awarded!`
      : `\n*Tweet posted! (No coin payout configured this week.)*`;

  await interaction.reply({
    ephemeral: true,
    embeds: [new EmbedBuilder()
      .setColor(Colors.Blue)
      .setTitle("🐦 Tweet Posted!")
      .setDescription(`> ${text}${limitNote}`)
      .setFooter({ text: `Week ${currentWeek} • ${user.team ?? interaction.user.username}` })
      .setTimestamp()],
    components: [backToHubRow()],
  });
}

// ═══════════════════════════════════════════════════════════════════════════════
//  ROW 2 — Rosters
// ═══════════════════════════════════════════════════════════════════════════════

async function handleMyRoster(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  const [user, seasonId] = await Promise.all([
    getOrCreateUser(interaction.user.id, interaction.user.username, gid),
    getRosterSeasonId(gid),
  ]);

  if (!user.team) {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ You are not linked to a team. Ask a commissioner to link you with `/admin-linkteam`.")],
      components: [backToHubRow()],
    });
    return;
  }

  // Find teamId from franchiseMcaTeams — match on nickName first, then fullName as fallback
  const teamRow = (await db.select({ mcaTeamId: franchiseMcaTeamsTable.teamId, fullName: franchiseMcaTeamsTable.fullName })
    .from(franchiseMcaTeamsTable)
    .where(and(
      eq(franchiseMcaTeamsTable.seasonId, seasonId),
      or(
        sql`lower(${franchiseMcaTeamsTable.nickName}) = lower(${user.team})`,
        sql`lower(${franchiseMcaTeamsTable.fullName}) = lower(${user.team})`,
      ),
    ))
    .limit(1))[0];

  if (!teamRow) {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ Team **${user.team}** not found in the franchise database. Make sure MCA data is imported.\n\n*Your linked team name is "**${user.team}**" — ask a commissioner to check it matches your franchise data.*`)],
      components: [backToHubRow()],
    });
    return;
  }

  const displayName = teamRow.fullName ?? user.team;
  // Store in session so player-card and team-stats flows can use it
  sess.rosterViewTeamId   = teamRow.mcaTeamId;
  sess.rosterViewTeamName = displayName;
  sess.rosterViewSource   = "my";
  sess.rosterViewSeasonId = seasonId;

  const embed = new EmbedBuilder();
  await buildRosterEmbed(gid, seasonId, teamRow.mcaTeamId, displayName, embed);
  await interaction.update({ embeds: [embed], components: buildRosterNavRows("my") });
}

async function handleAnyRosterTeamPick(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid      = interaction.guildId!;
  const seasonId = await getRosterSeasonId(gid);

  // Fetch ALL teams (human and CPU) for this season
  const teams = await db.select({
    id:         franchiseMcaTeamsTable.id,
    mcaTeamId:  franchiseMcaTeamsTable.teamId,
    fullName:   franchiseMcaTeamsTable.fullName,
    nickName:   franchiseMcaTeamsTable.nickName,
    conference: franchiseMcaTeamsTable.conference,
    isHuman:    franchiseMcaTeamsTable.isHuman,
  })
    .from(franchiseMcaTeamsTable)
    .where(eq(franchiseMcaTeamsTable.seasonId, seasonId))
    .orderBy(franchiseMcaTeamsTable.conference, franchiseMcaTeamsTable.fullName);

  if (!teams.length) {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ No teams found. Import MCA data first.")],
      components: [backToHubRow()],
    });
    return;
  }

  // Split into AFC and NFC; fall back to NFL_DIVISION_MAP if conference field is missing
  const afcTeams = teams.filter(t => {
    const conf = t.conference?.toUpperCase();
    if (conf === "AFC") return true;
    if (conf === "NFC") return false;
    return NFL_DIVISION_MAP[t.nickName ?? ""]?.conference === "AFC";
  });
  const nfcTeams = teams.filter(t => {
    const conf = t.conference?.toUpperCase();
    if (conf === "NFC") return true;
    if (conf === "AFC") return false;
    return NFL_DIVISION_MAP[t.nickName ?? ""]?.conference === "NFC";
  });

  // Use MCA teamId (not serial PK) as select value — buildRosterEmbed needs MCA teamId
  // Each dropdown must have a unique customId — Discord rejects duplicate component IDs on the same message.
  const makeMenu = (conference: string, list: typeof teams) =>
    new StringSelectMenuBuilder()
      .setCustomId(`ac_anyroster_sel_${conference.toLowerCase()}`)
      .setPlaceholder(`${conference} — pick a team…`)
      .addOptions(
        list.slice(0, 25).map(t =>
          new StringSelectMenuOptionBuilder()
            .setLabel(t.fullName)
            .setDescription(t.isHuman ? "👤 Human" : "🤖 CPU")
            .setValue(String(t.mcaTeamId)),
        ),
      );

  const browseRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_allplayers").setLabel("🌐 All Players").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ac_freeagents").setLabel("🆓 Free Agents").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("ac_activeteams").setLabel("🟢 Active Teams").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_openteams").setLabel("🔴 Open Teams").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_hub").setLabel("← Back").setStyle(ButtonStyle.Secondary),
  );

  const components: ActionRowBuilder<StringSelectMenuBuilder | ButtonBuilder>[] = [];
  if (afcTeams.length) components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(makeMenu("AFC", afcTeams)));
  if (nfcTeams.length) components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(makeMenu("NFC", nfcTeams)));
  components.push(browseRow as any);

  await interaction.update({
    embeds: [new EmbedBuilder()
      .setColor(Colors.Blue)
      .setTitle("👥 Rosters")
      .setDescription("Select a team to view their roster — or browse **All Players** / **Free Agents** below.")
      .setFooter({ text: `${teams.length} teams loaded — 👤 Human · 🤖 CPU` })],
    components,
  });
}

async function handleAnyRosterShow(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  // Value is MCA teamId (integer) — NOT the serial PK
  const mcaTeamId = Number(interaction.values[0]);
  const gid       = interaction.guildId!;
  const seasonId  = await getRosterSeasonId(gid);

  const teamRow = (await db.select({ fullName: franchiseMcaTeamsTable.fullName })
    .from(franchiseMcaTeamsTable)
    .where(and(eq(franchiseMcaTeamsTable.seasonId, seasonId), eq(franchiseMcaTeamsTable.teamId, mcaTeamId)))
    .limit(1))[0];
  const teamName = teamRow?.fullName ?? "Unknown Team";

  // Store in session for player-card and team-stats flows
  sess.rosterViewTeamId   = mcaTeamId;
  sess.rosterViewTeamName = teamName;
  sess.rosterViewSource   = "any";
  sess.rosterViewSeasonId = seasonId;

  const embed = new EmbedBuilder();
  await buildRosterEmbed(gid, seasonId, mcaTeamId, teamName, embed);
  await interaction.update({ embeds: [embed], components: buildRosterNavRows("any") });
}

// ── Roster Card — View Player Cards flow ──────────────────────────────────────

async function handleRcPosPick(interaction: ButtonInteraction, sess: ActionsSession) {
  if (!sess.rosterViewTeamId || !sess.rosterViewTeamName || !sess.rosterViewSeasonId) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Session expired. Please open the roster again.")], components: [backToHubRow()] });
    return;
  }
  const gid = interaction.guildId!;

  // Fetch which positions are actually on this roster
  const posRows = await db.selectDistinct({ position: franchiseRostersTable.position })
    .from(franchiseRostersTable)
    .where(and(
      eq(franchiseRostersTable.seasonId, sess.rosterViewSeasonId),
      eq(franchiseRostersTable.teamId, sess.rosterViewTeamId),
    ));
  const onRoster = new Set(posRows.map(r => r.position?.toUpperCase() ?? ""));

  const positions = ROSTER_CARD_POSITIONS.filter(p => onRoster.has(p));
  if (!positions.length) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ No players found on this roster. Make sure MCA data has been imported.")], components: [buildRosterNavRows(sess.rosterViewSource ?? "my")[1]] });
    return;
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_rc_possel")
    .setPlaceholder("Select a position…")
    .addOptions(positions.map(p => new StringSelectMenuOptionBuilder().setLabel(p).setValue(p)));

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Blue).setTitle(`🃏 ${sess.rosterViewTeamName} — Player Cards`).setDescription("Select a position to browse players.")],
    components: [
      new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_rc_back_to_roster").setLabel("← Back to Roster").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
      ),
    ],
  });
}

async function handleRcPosSel(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  if (!sess.rosterViewTeamId || !sess.rosterViewTeamName || !sess.rosterViewSeasonId) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Session expired.")], components: [backToHubRow()] });
    return;
  }
  const position = interaction.values[0]!;
  sess.rosterViewPosition = position;

  await showPlayerDropdown(interaction, sess, position);
}

async function showPlayerDropdown(
  interaction: StringSelectMenuInteraction | ButtonInteraction,
  sess: ActionsSession,
  position: string,
) {
  const players = await db.select({
    playerId: franchiseRostersTable.playerId,
    firstName: franchiseRostersTable.firstName,
    lastName:  franchiseRostersTable.lastName,
    overall:   franchiseRostersTable.overall,
    devTrait:  franchiseRostersTable.devTrait,
  })
    .from(franchiseRostersTable)
    .where(and(
      eq(franchiseRostersTable.seasonId, sess.rosterViewSeasonId!),
      eq(franchiseRostersTable.teamId, sess.rosterViewTeamId!),
      sql`upper(${franchiseRostersTable.position}) = upper(${position})`,
    ))
    .orderBy(desc(franchiseRostersTable.overall));

  if (!players.length) {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(Colors.Grey).setDescription(`No **${position}** players found on this team's roster.`)],
      components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_rc_cards").setLabel("← Back to Positions").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
      )],
    });
    return;
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_rc_playersel")
    .setPlaceholder(`Select a ${position}…`)
    .addOptions(players.slice(0, 25).map(p =>
      new StringSelectMenuOptionBuilder()
        .setLabel(`${p.firstName} ${p.lastName} — OVR ${p.overall}${devBadgeText(p.devTrait ?? 0)}`)
        .setValue(String(p.playerId)),
    ));

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Blue).setTitle(`🃏 ${sess.rosterViewTeamName} — ${position}`).setDescription("Select a player to view their full player card.")],
    components: [
      new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_rc_cards").setLabel("← Back to Positions").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
      ),
    ],
  });
}

async function handleRcPlayerSel(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  if (!sess.rosterViewTeamId || !sess.rosterViewSeasonId) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Session expired.")], components: [backToHubRow()] });
    return;
  }
  const playerId = Number(interaction.values[0]);
  sess.rosterCardPlayerId = playerId;
  sess.rosterCardPage     = 1;
  await showPlayerCardPage(interaction, sess);
}

async function showPlayerCardPage(
  interaction: StringSelectMenuInteraction | ButtonInteraction,
  sess: ActionsSession,
) {
  const page = sess.rosterCardPage ?? 1;
  const [rosterRow, statsRow, seasonRow] = await Promise.all([
    db.select().from(franchiseRostersTable)
      .where(and(
        eq(franchiseRostersTable.seasonId, sess.rosterViewSeasonId!),
        eq(franchiseRostersTable.teamId, sess.rosterViewTeamId!),
        eq(franchiseRostersTable.playerId, sess.rosterCardPlayerId!),
      )).limit(1).then(r => r[0]),
    db.select().from(playerSeasonStatsTable)
      .where(and(
        eq(playerSeasonStatsTable.seasonId, sess.rosterViewSeasonId!),
        eq(playerSeasonStatsTable.playerId, sess.rosterCardPlayerId!),
      )).limit(1).then(r => r[0]),
    db.select({ seasonNumber: seasonsTable.seasonNumber })
      .from(seasonsTable)
      .where(eq(seasonsTable.id, sess.rosterViewSeasonId!))
      .limit(1).then(r => r[0]),
  ]);

  if (!rosterRow) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Player not found.")], components: [backToHubRow()] });
    return;
  }

  const seasonNum = seasonRow?.seasonNumber ?? 1;
  const pages     = buildPlayerCardPages(rosterRow, statsRow, seasonNum);
  const embed     = pages[page - 1] ?? pages[0]!;

  await interaction.update({
    embeds: [embed],
    components: [
      buildCardPageRow(page, pages.length),
      buildCardBackRow(),
    ],
  });
}

async function handleRcCardPage(interaction: ButtonInteraction, sess: ActionsSession) {
  if (!sess.rosterViewTeamId || !sess.rosterCardPlayerId) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Session expired.")], components: [backToHubRow()] });
    return;
  }
  const page = Number(interaction.customId.split(":")[1]);
  if (!Number.isFinite(page) || page < 1 || page > 3) return;
  sess.rosterCardPage = page;
  await showPlayerCardPage(interaction, sess);
}

async function handleRcBackToPlayers(interaction: ButtonInteraction, sess: ActionsSession) {
  if (!sess.rosterViewPosition) {
    await handleRcPosPick(interaction, sess);
    return;
  }
  await showPlayerDropdown(interaction, sess, sess.rosterViewPosition);
}

async function handleRcTeamStats(interaction: ButtonInteraction, sess: ActionsSession) {
  if (!sess.rosterViewTeamId || !sess.rosterViewTeamName || !sess.rosterViewSeasonId) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Session expired. Please open the roster again.")], components: [backToHubRow()] });
    return;
  }
  const [teamStats, seasonRow] = await Promise.all([
    db.select().from(teamSeasonStatsTable)
      .where(and(
        eq(teamSeasonStatsTable.seasonId, sess.rosterViewSeasonId),
        eq(teamSeasonStatsTable.teamId, sess.rosterViewTeamId),
      )).limit(1).then(r => r[0]),
    db.select({ seasonNumber: seasonsTable.seasonNumber })
      .from(seasonsTable)
      .where(eq(seasonsTable.id, sess.rosterViewSeasonId))
      .limit(1).then(r => r[0]),
  ]);

  const backRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_rc_back_to_roster").setLabel("← Back to Roster").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
  );

  if (!teamStats) {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(Colors.Grey).setTitle(`🏟️ ${sess.rosterViewTeamName} — Team Stats`).setDescription("No team stats found yet this season. Import MCA data to populate.")],
      components: [backRow],
    });
    return;
  }

  const embed = buildTeamStatsEmbed(sess.rosterViewTeamName, seasonRow?.seasonNumber ?? 1, teamStats);
  await interaction.update({ embeds: [embed], components: [backRow] });
}

async function handleRcBackToRoster(interaction: ButtonInteraction, sess: ActionsSession) {
  if (!sess.rosterViewTeamId || !sess.rosterViewTeamName || !sess.rosterViewSeasonId) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Session expired.")], components: [backToHubRow()] });
    return;
  }
  const embed = new EmbedBuilder();
  await buildRosterEmbed(interaction.guildId!, sess.rosterViewSeasonId, sess.rosterViewTeamId, sess.rosterViewTeamName, embed);
  await interaction.update({ embeds: [embed], components: buildRosterNavRows(sess.rosterViewSource ?? "my") });
}

// ── Free Agents & All Players — shared constants ──────────────────────────────

const BROWSE_POSITIONS = ["QB","HB","FB","WR","TE","LT","LG","C","RG","RT","LEDGE","REDGE","DT","WILL","MIKE","SAM","CB","FS","SS","K","P","LS"];
const FA_TEAM_ID_BROWSE = 999;

const ABBR_TO_ATTR_KEY: Record<string, string> = {
  SPD: "speedRating", ACC: "accelerationRating", AGI: "agilityRating",
  STR: "strengthRating", JMP: "jumpingRating", AWR: "awareRating",
  COD: "changeOfDirectionRating",
  THP: "throwPowerRating", SAC: "throwAccuracyShortRating", MAC: "throwAccuracyMidRating",
  DAC: "throwAccuracyDeepRating", TOR: "throwOnRunRating", TUP: "throwUnderPressureRating",
  BSK: "breakSackRating", PAC: "playActionRating",
  CAR: "carryingRating", BCV: "bCVisionRating", ELU: "elusivenessRating",
  BTK: "breakTackleRating", TRK: "truckingRating",
  CTH: "catchRating", SRR: "shortRouteRunRating", MRR: "medRouteRunRating", DRR: "deepRouteRunRating",
  SFA: "stiffArmRating", SPM: "spinMoveRating", JKM: "jukeMoveRating",
  CIT: "catchInTrafficRating", SPC: "spectacularCatchRating", RLS: "releaseRating",
  PBK: "passBlockRating", RBK: "runBlockRating", IBL: "impactBlockRating",
  PBP: "passBlockPowerRating", PBF: "passBlockFinesseRating",
  RBP: "runBlockPowerRating", RBF: "runBlockFinesseRating", LBK: "leadBlockRating",
  PMV: "powerMovesRating", FMV: "finessMovesRating", BSH: "blockShedRating",
  PUR: "pursuitRating", TAK: "tackleRating", HPW: "hitPowerRating",
  MCV: "manCoverRating", ZCV: "zoneCoverRating", PRS: "pressRating", PRC: "playRecRating",
  // Kicking — used by primary sort (not attr sort dropdown)
  KPW: "kickPowerRating", KAC: "kickAccuracyRating", KR: "kickReturnRating",
};

/**
 * EA exports sometimes use "short-Rating" hybrid key names instead of the
 * full canonical names.  When the primary key returns NULL from the JSON,
 * fall back to the alternate form so composite scores aren't silently zeroed.
 */
const ABBR_ATTR_FALLBACKS: Record<string, string> = {
  ACC: "accelRating",
  JMP: "jumpRating",
  TGH: "toughRating",
  BCV: "bCVRating",
  CAR: "carryRating",
  CIT: "cITRating",
  SRR: "routeRunShortRating",
  MRR: "routeRunMedRating",
  DRR: "routeRunDeepRating",
  SPC: "specCatchRating",
  FMV: "finesseMovesRating",  // primary ABBR_TO_ATTR_KEY has the EA typo "finessMovesRating"
  TRK: "truckRating",
  KAC: "kickAccRating",
  KR:  "kickRetRating",
};

const AP_ATTR_NAMES: Record<string, string> = {
  // Offensive
  SPD: "Speed", ACC: "Acceleration", AGI: "Agility", STR: "Strength", JMP: "Jumping",
  AWR: "Awareness", COD: "Change of Direction",
  THP: "Throw Power", SAC: "Short Acc", MAC: "Mid Acc", DAC: "Deep Acc",
  TOR: "Throw on Run", TUP: "Throw Under Press", BSK: "Break Sack", PAC: "Play Action",
  CAR: "Carrying", BCV: "Ball Carrier Vision", ELU: "Elusiveness", BTK: "Break Tackle", TRK: "Trucking",
  CTH: "Catching", SRR: "Short Route Run", MRR: "Mid Route Run", DRR: "Deep Route Run",
  // Defensive / Blocking / Skill
  PBK: "Pass Block", RBK: "Run Block", IBL: "Impact Block",
  PBP: "Pass Block Power", PBF: "Pass Block Finesse",
  RBP: "Run Block Power", RBF: "Run Block Finesse", LBK: "Lead Block",
  PMV: "Power Moves", FMV: "Finesse Moves", BSH: "Block Shed",
  PUR: "Pursuit", TAK: "Tackle", HPW: "Hit Power",
  MCV: "Man Coverage", ZCV: "Zone Coverage", PRS: "Press", PRC: "Play Recognition",
  SFA: "Stiff Arm", SPM: "Spin Move", JKM: "Juke Move", RLS: "Release",
  SPC: "Spec Catch", CIT: "Catch in Traffic",
  // Kicking sort labels (used in primary sort summary display)
  KPW: "Kick Power", KAC: "Kick Accuracy", KR: "Kick Return",
};

// ── Multi-sort helpers ─────────────────────────────────────────────────────────

const SORT_PRIMARY_LABELS: Record<string, string> = {
  overall_desc: "OVR ↓", overall_asc: "OVR ↑",
  age_asc: "Younger", age_desc: "Older",
  height_desc: "Height ↓", height_asc: "Height ↑",
  weight_desc: "Weight ↓", weight_asc: "Weight ↑",
  contract_asc: "Contract ↑", contract_desc: "Contract ↓",
  kpw_desc: "KPW ↓", kac_desc: "KAC ↓", kr_desc: "KR ↓",
};

/** Return a short human-readable label for a sort key */
function sortStackLabel(key: string): string {
  if (SORT_PRIMARY_LABELS[key]) return SORT_PRIMARY_LABELS[key];
  if (AP_ATTR_NAMES[key]) return `${AP_ATTR_NAMES[key]} ↓`;
  return key;
}

/**
 * Exponential weights by priority position.
 * 1st pick → 1.0, 2nd → 0.5, 3rd → 0.25, 4th → 0.125, 5th → 0.0625
 */
const SORT_WEIGHTS = [1.0, 0.5, 0.25, 0.125, 0.0625];
const SORT_WEIGHT_LABELS = ["100%", "50%", "25%", "12.5%", "6.25%"];

// ── Sort page data ─────────────────────────────────────────────────────────────

/** Page 0: Special/primary sorts (OVR, Age, physical stats, kicking) */
const SORT_PAGE_0_KEYS = [
  "overall_desc", "overall_asc", "age_asc", "age_desc", "height_desc",
  "weight_desc", "contract_desc", "kpw_desc", "kac_desc", "kr_desc",
];

/** Pages 1-5: All 48 attributes in category order, 10 per page */
const SORT_ATTR_PAGES: string[][] = [
  ["SPD","ACC","AGI","STR","JMP","AWR","COD","THP","SAC","MAC"],   // Athletic + Throwing
  ["DAC","TOR","TUP","BSK","PAC","CAR","BCV","ELU","BTK","TRK"],   // Throwing + Ball Carry
  ["SFA","SPM","JKM","CTH","SRR","MRR","DRR","SPC","CIT","RLS"],   // Ball Carry + Receiving
  ["PBK","RBK","IBL","PBP","PBF","RBP","RBF","LBK","PMV","FMV"],   // Blocking + Pass Rush
  ["BSH","PUR","TAK","HPW","MCV","ZCV","PRS","PRC"],                // Defense + Coverage
];

const SORT_ALL_PAGES: string[][] = [SORT_PAGE_0_KEYS, ...SORT_ATTR_PAGES];

const SORT_PAGE_LABELS = [
  "Pg 1/6 — Special",
  "Pg 2/6 — Athletic / Throwing",
  "Pg 3/6 — Throwing / Ball Carry",
  "Pg 4/6 — Ball Carry / Receiving",
  "Pg 5/6 — Blocking / Rush",
  "Pg 6/6 — Defense / Coverage",
];

/** Short label for a sort button (used as button label text). */
function sortBtnLabel(key: string, sortStack: string[]): string {
  const base = SORT_PRIMARY_LABELS[key] ?? key; // attr keys are their own abbr (SPD, ACC…)
  const idx  = sortStack.indexOf(key);
  if (idx < 0) return base;
  return `${base} (${SORT_WEIGHT_LABELS[idx] ?? "~6%"})`.slice(0, 80);
}

/** Rows 1 & 2 — sort toggle buttons for the current page (up to 10 keys, 5 per row). */
function buildSortPageRows(prefix: string, page: number, sortStack: string[]): ActionRowBuilder<ButtonBuilder>[] {
  const pageKeys = SORT_ALL_PAGES[page] ?? [];
  const rows: ActionRowBuilder<ButtonBuilder>[] = [];
  for (let r = 0; r < 2; r++) {
    const keys = pageKeys.slice(r * 5, (r + 1) * 5);
    if (!keys.length) break;
    rows.push(
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        ...keys.map(key =>
          new ButtonBuilder()
            .setCustomId(`${prefix}_stog|${key}`)
            .setLabel(sortBtnLabel(key, sortStack))
            .setStyle(sortStack.includes(key) ? ButtonStyle.Success : ButtonStyle.Secondary),
        ),
      ),
    );
  }
  return rows;
}

/** Row 3 — sort page navigation + clear sort. */
function buildSortNavRow(prefix: string, page: number, sortStack: string[]): ActionRowBuilder<ButtonBuilder> {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`${prefix}_sprev`).setLabel("◀ Prev")
      .setStyle(ButtonStyle.Secondary).setDisabled(page === 0),
    new ButtonBuilder().setCustomId(`${prefix}_spage_lbl`)
      .setLabel(SORT_PAGE_LABELS[page] ?? `Pg ${page + 1}/${SORT_ALL_PAGES.length}`)
      .setStyle(ButtonStyle.Primary).setDisabled(true),
    new ButtonBuilder().setCustomId(`${prefix}_snext`).setLabel("▶ Next")
      .setStyle(ButtonStyle.Secondary).setDisabled(page >= SORT_ALL_PAGES.length - 1),
    new ButtonBuilder().setCustomId(`${prefix}_sort_clear`).setLabel("🗑 Clear Sort")
      .setStyle(ButtonStyle.Danger).setDisabled(sortStack.length === 0),
  );
}

/** Row 4 — dev trait filter toggle buttons. */
function buildDevFilterRow(prefix: string, devFilters: number[]): ActionRowBuilder<ButtonBuilder> {
  const has = (v: number) => devFilters.includes(v);
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`${prefix}_dtog|0`).setLabel("Show Normal")
      .setStyle(has(0) ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`${prefix}_dtog|1`).setLabel("Show Star")
      .setStyle(has(1) ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`${prefix}_dtog|2`).setLabel("Show SS")
      .setStyle(has(2) ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`${prefix}_dtog|3`).setLabel("Show XF")
      .setStyle(has(3) ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`${prefix}_dev_clear`).setLabel("Clear Dev")
      .setStyle(ButtonStyle.Danger).setDisabled(devFilters.length === 0),
  );
}

/** Toggle one sort key in the stack (max 5). */
function toggleSortKey(stack: string[], key: string): string[] {
  if (stack.includes(key)) return stack.filter(k => k !== key);
  if (stack.length >= 5) return stack; // already at max
  return [...stack, key];
}

/** Toggle one dev-trait value in the filter array. */
function toggleDevFilter(filters: number[], val: number): number[] {
  return filters.includes(val) ? filters.filter(v => v !== val) : [...filters, val];
}

/**
 * Build a single composite SQL score expression from the sort stack.
 * Each term is a normalized (0-1) value multiplied by its exponential weight.
 * The resulting expression is sorted DESC so the "best fit" player ranks first.
 *
 * This produces Madden-style scouting: a player strong across ALL priorities
 * beats a player maxed on only the first pick but weak on others.
 */
function buildWeightedScoreExpr(stack: string[]): SQL | null {
  if (!stack.length) return null;

  const terms: string[] = [];

  for (let i = 0; i < stack.length; i++) {
    const key = stack[i]!;
    const w   = SORT_WEIGHTS[i] ?? 0.0625;

    if (ABBR_TO_ATTR_KEY[key]) {
      // 0-99 Madden attribute — normalize by 99.
      // Try both canonical and hybrid EA key names so the score isn't silently zeroed.
      const attrKey  = ABBR_TO_ATTR_KEY[key];
      const fallback = ABBR_ATTR_FALLBACKS[key];
      const coalesce = fallback
        ? `COALESCE((attributes->>'${attrKey}')::numeric, (attributes->>'${fallback}')::numeric, 0)`
        : `COALESCE((attributes->>'${attrKey}')::numeric, 0)`;
      terms.push(`${coalesce} / 99.0 * ${w}`);
    } else {
      const parts = key.split("_");
      const dir   = parts[parts.length - 1]; // "asc" or "desc"
      const field = parts.slice(0, -1).join("_");
      switch (field) {
        case "overall":
          // 0-99 range
          terms.push(dir === "desc"
            ? `COALESCE(overall, 0) / 99.0 * ${w}`
            : `(99.0 - COALESCE(overall, 99)) / 99.0 * ${w}`);
          break;
        case "age":
          // Typical Madden age range 21-45; asc = younger is better
          terms.push(dir === "asc"
            ? `(45.0 - COALESCE(age, 45)) / 24.0 * ${w}`
            : `(COALESCE(age, 21) - 21.0) / 24.0 * ${w}`);
          break;
        case "height":
          // Height stored as inches (~66-80)
          terms.push(dir === "desc"
            ? `(COALESCE((attributes->>'height')::numeric, 66) - 66.0) / 14.0 * ${w}`
            : `(80.0 - COALESCE((attributes->>'height')::numeric, 80)) / 14.0 * ${w}`);
          break;
        case "weight":
          // Weight stored as lbs (~150-380)
          terms.push(dir === "desc"
            ? `(COALESCE((attributes->>'weight')::numeric, 150) - 150.0) / 230.0 * ${w}`
            : `(380.0 - COALESCE((attributes->>'weight')::numeric, 380)) / 230.0 * ${w}`);
          break;
        case "contract":
          // Contract years remaining (~0-7); asc = shorter deal is better
          terms.push(dir === "asc"
            ? `(7.0 - COALESCE(contract_years_left, 7)) / 7.0 * ${w}`
            : `COALESCE(contract_years_left, 0) / 7.0 * ${w}`);
          break;
        case "kpw":
          terms.push(`COALESCE((attributes->>'kickPowerRating')::numeric, 0) / 99.0 * ${w}`);
          break;
        case "kac":
          terms.push(`COALESCE((attributes->>'kickAccuracyRating')::numeric, 0) / 99.0 * ${w}`);
          break;
        case "kr":
          terms.push(`COALESCE((attributes->>'kickReturnRating')::numeric, 0) / 99.0 * ${w}`);
          break;
      }
    }
  }

  if (!terms.length) return null;
  return sql.raw(`(${terms.join(" + ")}) DESC NULLS LAST`);
}

function buildApOrderBy(sess: ActionsSession): SQL[] {
  const expr = buildWeightedScoreExpr(sess.apSortStack ?? []);
  return [expr ?? desc(franchiseRostersTable.overall)];
}

function buildSortStackSummary(stack: string[]): string {
  if (!stack.length) return "";
  const WEIGHT_LABELS = ["100%", "50%", "25%", "12.5%", "6.25%"];
  return "**Sort (weighted):** " + stack.map((k, i) =>
    `${sortStackLabel(k)} [${WEIGHT_LABELS[i] ?? "~6%"}]`,
  ).join(" · ");
}

function buildApFilterSummary(sess: ActionsSession): string {
  const parts: string[] = [];
  if (sess.apNameFilter) parts.push(`Name: "${sess.apNameFilter}"`);
  const devFilters = sess.apDevFilters ?? [];
  if (devFilters.length > 0) {
    const devLabels: Record<number, string> = { 0: "Normal", 1: "★ Star", 2: "🌟 SS", 3: "⚡ XF" };
    parts.push(`Dev: ${devFilters.map(v => devLabels[v] ?? v).join(", ")}`);
  }
  const sortLine = buildSortStackSummary(sess.apSortStack ?? []);
  if (sortLine) parts.push(sortLine);
  return parts.length ? parts.join("\n") : "";
}

// ── Free Agents — player-card flow ───────────────────────────────────────────

async function handleFreeAgentsPosPick(interaction: ButtonInteraction, sess: ActionsSession) {
  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_fa_pos")
    .setPlaceholder("Select a position…")
    .addOptions(BROWSE_POSITIONS.map(p => new StringSelectMenuOptionBuilder().setLabel(p).setValue(p)));

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Green).setTitle("🆓 Free Agents — Select Position")
      .setDescription("Choose a position to view available free agents.")],
    components: [
      new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_anyroster").setLabel("← Back").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
      ),
    ],
  });
}

async function handleFaPosSel(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const pos = interaction.values[0]!;
  const gid = interaction.guildId!;
  const seasonId = await getRosterSeasonId(gid);
  sess.faPos = pos;
  sess.faSeasonId = seasonId;
  await showFaPlayerList(interaction, sess);
}

async function showFaPlayerList(
  interaction: ButtonInteraction | StringSelectMenuInteraction,
  sess: ActionsSession,
) {
  const pos = sess.faPos!;
  const seasonId = sess.faSeasonId!;

  const conditions: SQL<unknown>[] = [
    eq(franchiseRostersTable.seasonId, seasonId),
    eq(franchiseRostersTable.teamId, FA_TEAM_ID_BROWSE),
    sql`upper(${franchiseRostersTable.position}) = upper(${pos})`,
  ];
  const faDevFiltersX = sess.faDevFilters ?? [];
  if (faDevFiltersX.length > 0) conditions.push(inArray(franchiseRostersTable.devTrait, faDevFiltersX));
  if (sess.faNameFilter) {
    const namePat = `%${sess.faNameFilter}%`;
    conditions.push(sql`upper(${franchiseRostersTable.lastName}) like upper(${namePat})`);
  }

  const faWeightedExpr = buildWeightedScoreExpr(sess.faSortStack ?? []);
  const orderExprs: SQL[] = [faWeightedExpr ?? desc(franchiseRostersTable.overall)];

  const players = await db.select({
    playerId:  franchiseRostersTable.playerId,
    firstName: franchiseRostersTable.firstName,
    lastName:  franchiseRostersTable.lastName,
    overall:   franchiseRostersTable.overall,
    devTrait:  franchiseRostersTable.devTrait,
    age:       franchiseRostersTable.age,
  }).from(franchiseRostersTable)
    .where(and(...conditions))
    .orderBy(...orderExprs)
    .limit(24);

  if (!players.length) {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(Colors.Grey)
        .setTitle(`🆓 Free Agents — ${pos}`)
        .setDescription("No free agents found at this position.\n\nMake sure MCA data includes free agent roster data.")],
      components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_freeagents").setLabel("← Back").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
      )],
    });
    return;
  }

  const hasFilters = !!(sess.faNameFilter || (sess.faDevFilters?.length) || (sess.faSortStack?.length));
  const filterSummary = buildFaFilterSummary(sess);

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_fa_player")
    .setPlaceholder("Select a free agent to view their card…")
    .addOptions(players.map(p =>
      new StringSelectMenuOptionBuilder()
        .setLabel(`${p.firstName} ${p.lastName} — OVR ${p.overall}${devBadgeText(p.devTrait ?? 0)}`)
        .setDescription(`Age: ${p.age ?? "?"}`)
        .setValue(String(p.playerId)),
    ));

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Green)
      .setTitle(`🆓 Free Agents — ${pos}`)
      .setDescription(`Top ${players.length} free agents. Select one for their player card.\n${DEV_LEGEND}${filterSummary ? `\n${filterSummary}` : ""}`)],
    components: [
      new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_fa_filter").setLabel("🔍 Filter / Sort").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("ac_freeagents").setLabel("← Back").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
      ),
    ],
  });
}

async function handleFaPlayerSel(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const playerId = Number(interaction.values[0]);
  sess.faCardPlayerId = playerId;
  sess.faCardPage = 1;
  await showFaCard(interaction, sess);
}

async function showFaCard(
  interaction: ButtonInteraction | StringSelectMenuInteraction,
  sess: ActionsSession,
) {
  const gid = interaction.guildId!;
  const playerId = sess.faCardPlayerId!;
  const page = sess.faCardPage ?? 1;
  const seasonId = sess.faSeasonId ?? (await getRosterSeasonId(gid));
  const season = await getOrCreateActiveSeason(gid);

  const [roster, stats] = await Promise.all([
    db.select().from(franchiseRostersTable)
      .where(and(eq(franchiseRostersTable.seasonId, seasonId), eq(franchiseRostersTable.playerId, playerId)))
      .limit(1).then(r => r[0]),
    db.select().from(playerSeasonStatsTable)
      .where(and(eq(playerSeasonStatsTable.seasonId, seasonId), eq(playerSeasonStatsTable.playerId, playerId)))
      .limit(1).then(r => r[0]),
  ]);

  if (!roster) {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Player not found.")],
      components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_fa_back_to_players").setLabel("← Back").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close").setStyle(ButtonStyle.Danger),
      )],
    });
    return;
  }

  const pages = buildPlayerCardPages(roster, stats, season.seasonNumber ?? 1);
  const safePage = Math.min(Math.max(1, page), pages.length);
  const TOTAL = pages.length;

  await interaction.update({
    embeds: [pages[safePage - 1]!],
    components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId(`ac_fa_cardpage:${safePage - 1}`).setLabel("◀ Prev").setStyle(ButtonStyle.Secondary).setDisabled(safePage <= 1),
        new ButtonBuilder().setCustomId("ac_fa_cardpage_num").setLabel(`Page ${safePage} / ${TOTAL}`).setStyle(ButtonStyle.Secondary).setDisabled(true),
        new ButtonBuilder().setCustomId(`ac_fa_cardpage:${safePage + 1}`).setLabel("Next ▶").setStyle(ButtonStyle.Secondary).setDisabled(safePage >= TOTAL),
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_fa_back_to_players").setLabel("← Back to Players").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
      ),
    ],
  });
}

async function handleFaCardPage(interaction: ButtonInteraction, sess: ActionsSession) {
  const page = Number(interaction.customId.split(":")[1]);
  if (!Number.isFinite(page) || page < 1 || page > 10) return;
  sess.faCardPage = page;
  await showFaCard(interaction, sess);
}

async function handleFaBackToPlayers(interaction: ButtonInteraction, sess: ActionsSession) {
  if (!sess.faPos || !sess.faSeasonId) { await handleFreeAgentsPosPick(interaction, sess); return; }
  await showFaPlayerList(interaction, sess);
}

// ── All Players — Position picker, player list with filters, player cards ──────

async function handleAllPlayersPosPick(interaction: ButtonInteraction, sess: ActionsSession) {
  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_ap_pos")
    .setPlaceholder("Select a position…")
    .addOptions(BROWSE_POSITIONS.map(p => new StringSelectMenuOptionBuilder().setLabel(p).setValue(p)));

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Blue).setTitle("🌐 All Players — Select Position")
      .setDescription("Choose a position to browse all players across the league.")],
    components: [
      new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_anyroster").setLabel("← Back").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
      ),
    ],
  });
}

async function handleAllPlayersPosSel(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const pos = interaction.values[0]!;
  const gid = interaction.guildId!;
  const seasonId = await getRosterSeasonId(gid);
  if (sess.apPos !== pos) {
    sess.apNameFilter = undefined;
    sess.apDevFilters = [];
    sess.apSortStack  = [];
    sess.apSortPage   = 0;
  }
  sess.apPos = pos;
  sess.apSeasonId = seasonId;
  await showApPlayerList(interaction, sess);
}

async function showApPlayerList(
  interaction: ButtonInteraction | StringSelectMenuInteraction,
  sess: ActionsSession,
) {
  const pos = sess.apPos!;
  const seasonId = sess.apSeasonId!;

  const conditions: SQL<unknown>[] = [
    eq(franchiseRostersTable.seasonId, seasonId),
    sql`upper(${franchiseRostersTable.position}) = upper(${pos})`,
    sql`${franchiseRostersTable.teamId} != ${FA_TEAM_ID_BROWSE}`,
  ];
  if (sess.apNameFilter) {
    const namePat = `%${sess.apNameFilter}%`;
    conditions.push(sql`upper(${franchiseRostersTable.lastName}) like upper(${namePat})`);
  }
  const apDevFiltersQ = sess.apDevFilters ?? [];
  if (apDevFiltersQ.length > 0) conditions.push(inArray(franchiseRostersTable.devTrait, apDevFiltersQ));

  const orderExprs = buildApOrderBy(sess);
  const players = await db.select({
    playerId:  franchiseRostersTable.playerId,
    firstName: franchiseRostersTable.firstName,
    lastName:  franchiseRostersTable.lastName,
    overall:   franchiseRostersTable.overall,
    devTrait:  franchiseRostersTable.devTrait,
    age:       franchiseRostersTable.age,
    teamName:  franchiseRostersTable.teamName,
  }).from(franchiseRostersTable)
    .where(and(...conditions))
    .orderBy(...orderExprs)
    .limit(24);

  const filterSummary = buildApFilterSummary(sess);

  const noResultEmbed = new EmbedBuilder().setColor(Colors.Grey)
    .setTitle(`🌐 All Players — ${pos}`)
    .setDescription(`No players found matching your filters.\n\n${filterSummary}`);
  const noResultBtns = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_ap_filter").setLabel("Filter / Sort").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ac_allplayers").setLabel("← Back").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
  );

  if (!players.length) {
    await interaction.update({ embeds: [noResultEmbed], components: [noResultBtns] });
    return;
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_ap_player")
    .setPlaceholder("Select a player for their card…")
    .addOptions(players.map(p =>
      new StringSelectMenuOptionBuilder()
        .setLabel(`${p.firstName} ${p.lastName} — OVR ${p.overall}${devBadgeText(p.devTrait ?? 0)}`)
        .setDescription(`${p.teamName ?? "?"} · Age ${p.age ?? "?"}`)
        .setValue(String(p.playerId)),
    ));

  const descParts = [`Top ${players.length} ${pos}s. Select one for their player card.`];
  if (filterSummary) descParts.push(filterSummary);
  descParts.push(DEV_LEGEND);

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Blue).setTitle(`🌐 All Players — ${pos}`).setDescription(descParts.join("\n"))],
    components: [
      new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_ap_filter").setLabel("Filter / Sort").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("ac_allplayers").setLabel("← Back").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
      ),
    ],
  });
}

async function handleApPlayerSel(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  sess.apCardPlayerId = Number(interaction.values[0]);
  sess.apCardPage = 1;
  await showApCard(interaction, sess);
}

async function showApCard(
  interaction: ButtonInteraction | StringSelectMenuInteraction,
  sess: ActionsSession,
) {
  const gid = interaction.guildId!;
  const playerId = sess.apCardPlayerId!;
  const page = sess.apCardPage ?? 1;
  const seasonId = sess.apSeasonId ?? (await getRosterSeasonId(gid));
  const season = await getOrCreateActiveSeason(gid);

  const [roster, stats] = await Promise.all([
    db.select().from(franchiseRostersTable)
      .where(and(eq(franchiseRostersTable.seasonId, seasonId), eq(franchiseRostersTable.playerId, playerId)))
      .limit(1).then(r => r[0]),
    db.select().from(playerSeasonStatsTable)
      .where(and(eq(playerSeasonStatsTable.seasonId, seasonId), eq(playerSeasonStatsTable.playerId, playerId)))
      .limit(1).then(r => r[0]),
  ]);

  if (!roster) {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Player not found.")],
      components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_ap_back_to_players").setLabel("← Back").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close").setStyle(ButtonStyle.Danger),
      )],
    });
    return;
  }

  const pages = buildPlayerCardPages(roster, stats, season.seasonNumber ?? 1);
  const safePage = Math.min(Math.max(1, page), pages.length);
  const TOTAL = pages.length;

  await interaction.update({
    embeds: [pages[safePage - 1]!],
    components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId(`ac_ap_cardpage:${safePage - 1}`).setLabel("◀ Prev").setStyle(ButtonStyle.Secondary).setDisabled(safePage <= 1),
        new ButtonBuilder().setCustomId("ac_ap_cardpage_num").setLabel(`Page ${safePage} / ${TOTAL}`).setStyle(ButtonStyle.Secondary).setDisabled(true),
        new ButtonBuilder().setCustomId(`ac_ap_cardpage:${safePage + 1}`).setLabel("Next ▶").setStyle(ButtonStyle.Secondary).setDisabled(safePage >= TOTAL),
      ),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_ap_back_to_players").setLabel("← Back to Players").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
      ),
    ],
  });
}

async function handleApCardPage(interaction: ButtonInteraction, sess: ActionsSession) {
  const page = Number(interaction.customId.split(":")[1]);
  if (!Number.isFinite(page) || page < 1 || page > 10) return;
  sess.apCardPage = page;
  await showApCard(interaction, sess);
}

async function handleApBackToPlayers(interaction: ButtonInteraction, sess: ActionsSession) {
  if (!sess.apPos || !sess.apSeasonId) { await handleAllPlayersPosPick(interaction, sess); return; }
  await showApPlayerList(interaction, sess);
}

// ── All Players — Filter / Sort screen ────────────────────────────────────────

// Shared filter component builder — works for both AP and FA (prefix = "ac_ap" or "ac_fa")
// sortStack: ordered list of active sort keys (up to 5), priority = index 0 first
/** Row 5 — action buttons for AP filter screen. */
function buildApFilterActionRow(sess: ActionsSession): ActionRowBuilder<ButtonBuilder> {
  const hasFilters = !!(sess.apNameFilter || (sess.apDevFilters?.length) || (sess.apSortStack?.length));
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_ap_filter_name")
      .setLabel(sess.apNameFilter ? `🔍 "${sess.apNameFilter.slice(0, 20)}"` : "🔍 Name Search")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ac_ap_filter_apply").setLabel("✅ Apply & View").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("ac_ap_filter_clear").setLabel("🗑 Clear All").setStyle(ButtonStyle.Danger).setDisabled(!hasFilters),
    new ButtonBuilder().setCustomId("ac_ap_back_to_players").setLabel("← Back").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close").setStyle(ButtonStyle.Danger),
  );
}

async function showApFilterScreen(
  interaction: ButtonInteraction | StringSelectMenuInteraction,
  sess: ActionsSession,
) {
  const page      = sess.apSortPage ?? 0;
  const sortStack = sess.apSortStack ?? [];
  const devFilters = sess.apDevFilters ?? [];
  const summary   = buildApFilterSummary(sess);
  const stackFull = sortStack.length >= 5;

  const embed = new EmbedBuilder()
    .setColor(Colors.Blue)
    .setTitle(`🔍 Filter / Sort — ${sess.apPos ?? "All Players"}`)
    .setDescription(
      `Toggle buttons to build your sort priority (green = active). Up to **5 sort keys** max.\n` +
      (stackFull ? "⚠️ Sort full — deactivate a key before adding another.\n" : "") +
      `\n${summary || "*No active filters.*"}`,
    );

  const rows = [
    ...buildSortPageRows("ac_ap", page, sortStack),
    buildSortNavRow("ac_ap", page, sortStack),
    buildDevFilterRow("ac_ap", devFilters),
    buildApFilterActionRow(sess),
  ];
  await interaction.update({ embeds: [embed], components: rows as any[] });
}

async function handleApFilterScreen(interaction: ButtonInteraction, sess: ActionsSession) {
  await showApFilterScreen(interaction, sess);
}

async function handleApSortToggle(interaction: ButtonInteraction, sess: ActionsSession, key: string) {
  sess.apSortStack = toggleSortKey(sess.apSortStack ?? [], key);
  await showApFilterScreen(interaction, sess);
}

async function handleApDevToggle(interaction: ButtonInteraction, sess: ActionsSession, val: number) {
  sess.apDevFilters = toggleDevFilter(sess.apDevFilters ?? [], val);
  await showApFilterScreen(interaction, sess);
}

async function handleApDevClear(interaction: ButtonInteraction, sess: ActionsSession) {
  sess.apDevFilters = [];
  await showApFilterScreen(interaction, sess);
}

async function handleApSortClear(interaction: ButtonInteraction, sess: ActionsSession) {
  sess.apSortStack = [];
  await showApFilterScreen(interaction, sess);
}

async function handleApSortPage(interaction: ButtonInteraction, sess: ActionsSession, dir: "prev" | "next") {
  const current = sess.apSortPage ?? 0;
  const total = SORT_ALL_PAGES.length;
  sess.apSortPage = dir === "next" ? Math.min(current + 1, total - 1) : Math.max(current - 1, 0);
  await showApFilterScreen(interaction, sess);
}

async function handleApFilterNameModal(interaction: ButtonInteraction) {
  const modal = new ModalBuilder()
    .setCustomId("ac_modal_ap_name")
    .setTitle("Search by Player Last Name")
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("ap_name_input")
          .setLabel("Last name (partial match)")
          .setStyle(TextInputStyle.Short)
          .setPlaceholder("e.g. Smith, Allen, Mahomes")
          .setRequired(false)
          .setMaxLength(50),
      ),
    );
  await interaction.showModal(modal);
}

async function handleApFilterNameSubmit(interaction: ModalSubmitInteraction, sess: ActionsSession) {
  const raw = interaction.fields.getTextInputValue("ap_name_input").trim();
  sess.apNameFilter = raw.length ? raw : undefined;
  await interaction.deferUpdate();
  if (!sess.apPos || !sess.apSeasonId) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Session expired. Use /menu to start again.")],
      components: [],
    });
    return;
  }
  // Re-query and show player list (can't call interaction.update after modal deferUpdate)
  const pos = sess.apPos!;
  const seasonId = sess.apSeasonId!;
  const conditions: SQL<unknown>[] = [
    eq(franchiseRostersTable.seasonId, seasonId),
    sql`upper(${franchiseRostersTable.position}) = upper(${pos})`,
    sql`${franchiseRostersTable.teamId} != ${FA_TEAM_ID_BROWSE}`,
  ];
  if (sess.apNameFilter) {
    const namePat = `%${sess.apNameFilter}%`;
    conditions.push(sql`upper(${franchiseRostersTable.lastName}) like upper(${namePat})`);
  }
  const apDevF = sess.apDevFilters ?? [];
  if (apDevF.length > 0) conditions.push(inArray(franchiseRostersTable.devTrait, apDevF));
  const orderExprs = buildApOrderBy(sess);
  const players = await db.select({
    playerId:  franchiseRostersTable.playerId,
    firstName: franchiseRostersTable.firstName,
    lastName:  franchiseRostersTable.lastName,
    overall:   franchiseRostersTable.overall,
    devTrait:  franchiseRostersTable.devTrait,
    age:       franchiseRostersTable.age,
    teamName:  franchiseRostersTable.teamName,
  }).from(franchiseRostersTable)
    .where(and(...conditions))
    .orderBy(...orderExprs)
    .limit(24);

  const filterSummary = buildApFilterSummary(sess);
  if (!players.length) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(Colors.Grey).setTitle(`🌐 All Players — ${pos}`)
        .setDescription(`No players found matching your filters.\n\n${filterSummary}`)],
      components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_ap_filter").setLabel("Filter / Sort").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("ac_allplayers").setLabel("← Back").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
      )],
    });
    return;
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_ap_player")
    .setPlaceholder("Select a player for their card…")
    .addOptions(players.map(p =>
      new StringSelectMenuOptionBuilder()
        .setLabel(`${p.firstName} ${p.lastName} — OVR ${p.overall}${devBadgeText(p.devTrait ?? 0)}`)
        .setDescription(`${p.teamName ?? "?"} · Age ${p.age ?? "?"}`)
        .setValue(String(p.playerId)),
    ));

  const descParts = [`Top ${players.length} ${pos}s. Select one for their player card.`];
  if (filterSummary) descParts.push(filterSummary);
  descParts.push(DEV_LEGEND);

  await interaction.editReply({
    embeds: [new EmbedBuilder().setColor(Colors.Blue).setTitle(`🌐 All Players — ${pos}`).setDescription(descParts.join("\n"))],
    components: [
      new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_ap_filter").setLabel("Filter / Sort").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("ac_allplayers").setLabel("← Back").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
      ),
    ],
  });
}

async function handleApFilterApply(interaction: ButtonInteraction, sess: ActionsSession) {
  if (!sess.apPos || !sess.apSeasonId) { await handleAllPlayersPosPick(interaction, sess); return; }
  await showApPlayerList(interaction, sess);
  sess.apNameFilter = undefined;
  sess.apDevFilters = [];
  sess.apSortStack  = [];
  sess.apSortPage   = 0;
}

async function handleApFilterClear(interaction: ButtonInteraction, sess: ActionsSession) {
  sess.apNameFilter = undefined;
  sess.apDevFilters = [];
  sess.apSortStack  = [];
  sess.apSortPage   = 0;
  await showApFilterScreen(interaction, sess);
}

// ── Free Agents — Filter / Sort screen ────────────────────────────────────────

function buildFaFilterSummary(sess: ActionsSession): string {
  const parts: string[] = [];
  if (sess.faNameFilter) parts.push(`Name: "${sess.faNameFilter}"`);
  const devFilters = sess.faDevFilters ?? [];
  if (devFilters.length > 0) {
    const devLabels: Record<number, string> = { 0: "Normal", 1: "★ Star", 2: "🌟 SS", 3: "⚡ XF" };
    parts.push(`Dev: ${devFilters.map(v => devLabels[v] ?? v).join(", ")}`);
  }
  const sortLine = buildSortStackSummary(sess.faSortStack ?? []);
  if (sortLine) parts.push(sortLine);
  return parts.length ? parts.join("\n") : "";
}

/** Row 5 — action buttons for FA filter screen. */
function buildFaFilterActionRow(sess: ActionsSession): ActionRowBuilder<ButtonBuilder> {
  const hasFilters = !!(sess.faNameFilter || (sess.faDevFilters?.length) || (sess.faSortStack?.length));
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_fa_filter_name")
      .setLabel(sess.faNameFilter ? `🔍 "${sess.faNameFilter.slice(0, 20)}"` : "🔍 Name Search")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ac_fa_filter_apply").setLabel("✅ Apply & View").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("ac_fa_filter_clear").setLabel("🗑 Clear All").setStyle(ButtonStyle.Danger).setDisabled(!hasFilters),
    new ButtonBuilder().setCustomId("ac_fa_back_to_players").setLabel("← Back").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close").setStyle(ButtonStyle.Danger),
  );
}

async function showFaFilterScreen(
  interaction: ButtonInteraction | StringSelectMenuInteraction,
  sess: ActionsSession,
) {
  const page       = sess.faSortPage ?? 0;
  const sortStack  = sess.faSortStack ?? [];
  const devFilters = sess.faDevFilters ?? [];
  const summary    = buildFaFilterSummary(sess);
  const stackFull  = sortStack.length >= 5;

  const embed = new EmbedBuilder()
    .setColor(Colors.Green)
    .setTitle(`🔍 Filter / Sort — FA ${sess.faPos ?? "Free Agents"}`)
    .setDescription(
      `Toggle buttons to build your sort priority (green = active). Up to **5 sort keys** max.\n` +
      (stackFull ? "⚠️ Sort full — deactivate a key before adding another.\n" : "") +
      `\n${summary || "*No active filters.*"}`,
    );

  const rows = [
    ...buildSortPageRows("ac_fa", page, sortStack),
    buildSortNavRow("ac_fa", page, sortStack),
    buildDevFilterRow("ac_fa", devFilters),
    buildFaFilterActionRow(sess),
  ];
  await interaction.update({ embeds: [embed], components: rows as any[] });
}

async function handleFaFilterScreen(interaction: ButtonInteraction, sess: ActionsSession) {
  await showFaFilterScreen(interaction, sess);
}

async function handleFaSortToggle(interaction: ButtonInteraction, sess: ActionsSession, key: string) {
  sess.faSortStack = toggleSortKey(sess.faSortStack ?? [], key);
  await showFaFilterScreen(interaction, sess);
}

async function handleFaDevToggle(interaction: ButtonInteraction, sess: ActionsSession, val: number) {
  sess.faDevFilters = toggleDevFilter(sess.faDevFilters ?? [], val);
  await showFaFilterScreen(interaction, sess);
}

async function handleFaDevClear(interaction: ButtonInteraction, sess: ActionsSession) {
  sess.faDevFilters = [];
  await showFaFilterScreen(interaction, sess);
}

async function handleFaSortClear(interaction: ButtonInteraction, sess: ActionsSession) {
  sess.faSortStack = [];
  await showFaFilterScreen(interaction, sess);
}

async function handleFaSortPage(interaction: ButtonInteraction, sess: ActionsSession, dir: "prev" | "next") {
  const current = sess.faSortPage ?? 0;
  const total = SORT_ALL_PAGES.length;
  sess.faSortPage = dir === "next" ? Math.min(current + 1, total - 1) : Math.max(current - 1, 0);
  await showFaFilterScreen(interaction, sess);
}

async function handleFaFilterNameModal(interaction: ButtonInteraction) {
  const modal = new ModalBuilder()
    .setCustomId("ac_modal_fa_name")
    .setTitle("Search FA by Player Last Name")
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("fa_name_input")
          .setLabel("Last name (partial match)")
          .setStyle(TextInputStyle.Short)
          .setPlaceholder("e.g. Smith, Allen, Mahomes")
          .setRequired(false)
          .setMaxLength(50),
      ),
    );
  await interaction.showModal(modal);
}

async function handleFaFilterNameSubmit(interaction: ModalSubmitInteraction, sess: ActionsSession) {
  const raw = interaction.fields.getTextInputValue("fa_name_input").trim();
  sess.faNameFilter = raw.length ? raw : undefined;
  await interaction.deferUpdate();
  if (!sess.faPos || !sess.faSeasonId) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ Session expired. Use /menu to start again.")],
      components: [],
    });
    return;
  }
  // Re-query FA player list (can't call interaction.update after modal deferUpdate — must use editReply)
  const pos = sess.faPos!;
  const seasonId = sess.faSeasonId!;
  const conditions: SQL<unknown>[] = [
    eq(franchiseRostersTable.seasonId, seasonId),
    eq(franchiseRostersTable.teamId, FA_TEAM_ID_BROWSE),
    sql`upper(${franchiseRostersTable.position}) = upper(${pos})`,
  ];
  const faDevFiltersX = sess.faDevFilters ?? [];
  if (faDevFiltersX.length > 0) conditions.push(inArray(franchiseRostersTable.devTrait, faDevFiltersX));
  if (sess.faNameFilter) {
    const namePat = `%${sess.faNameFilter}%`;
    conditions.push(sql`upper(${franchiseRostersTable.lastName}) like upper(${namePat})`);
  }

  const faWeightedExpr = buildWeightedScoreExpr(sess.faSortStack ?? []);
  const orderExprs: SQL[] = [faWeightedExpr ?? desc(franchiseRostersTable.overall)];

  const players = await db.select({
    playerId:  franchiseRostersTable.playerId,
    firstName: franchiseRostersTable.firstName,
    lastName:  franchiseRostersTable.lastName,
    overall:   franchiseRostersTable.overall,
    devTrait:  franchiseRostersTable.devTrait,
    age:       franchiseRostersTable.age,
  }).from(franchiseRostersTable)
    .where(and(...conditions))
    .orderBy(...orderExprs)
    .limit(24);

  const filterSummary = buildFaFilterSummary(sess);
  if (!players.length) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(Colors.Grey).setTitle(`🆓 Free Agents — ${pos}`)
        .setDescription(`No free agents found.\n\n${filterSummary}`)],
      components: [new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_fa_filter").setLabel("🔍 Filter / Sort").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("ac_freeagents").setLabel("← Back").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
      )],
    });
    return;
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_fa_player")
    .setPlaceholder("Select a free agent to view their card…")
    .addOptions(players.map(p =>
      new StringSelectMenuOptionBuilder()
        .setLabel(`${p.firstName} ${p.lastName} — OVR ${p.overall}${devBadgeText(p.devTrait ?? 0)}`)
        .setDescription(`Age: ${p.age ?? "?"}`)
        .setValue(String(p.playerId)),
    ));

  await interaction.editReply({
    embeds: [new EmbedBuilder().setColor(Colors.Green)
      .setTitle(`🆓 Free Agents — ${pos}`)
      .setDescription(`${players.length} results.\n${DEV_LEGEND}\n${filterSummary}`)],
    components: [
      new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu),
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_fa_filter").setLabel("🔍 Filter / Sort").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("ac_freeagents").setLabel("← Back").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
      ),
    ],
  });
}

async function handleFaFilterApply(interaction: ButtonInteraction, sess: ActionsSession) {
  if (!sess.faPos || !sess.faSeasonId) { await handleFreeAgentsPosPick(interaction, sess); return; }
  await showFaPlayerList(interaction, sess);
  sess.faNameFilter = undefined;
  sess.faDevFilters = [];
  sess.faSortStack  = [];
  sess.faSortPage   = 0;
}

async function handleFaFilterClear(interaction: ButtonInteraction, sess: ActionsSession) {
  sess.faNameFilter  = undefined;
  sess.faDevFilters  = [];
  sess.faSortStack   = [];
  sess.faSortPage    = 0;
  await showFaFilterScreen(interaction, sess);
}

// ── Player Stats — removed; stats accessible via player cards in Rosters/FA/AP ─

// ── Team Stats ────────────────────────────────────────────────────────────────

async function handleTeamStatsTeamPick(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid      = interaction.guildId!;
  const season   = await getOrCreateActiveSeason(gid);
  const allTeams = await db.select({
    mcaTeamId:  franchiseMcaTeamsTable.teamId,
    fullName:   franchiseMcaTeamsTable.fullName,
    nickName:   franchiseMcaTeamsTable.nickName,
    conference: franchiseMcaTeamsTable.conference,
    isHuman:    franchiseMcaTeamsTable.isHuman,
  })
    .from(franchiseMcaTeamsTable)
    .where(and(eq(franchiseMcaTeamsTable.seasonId, season.id), eq(franchiseMcaTeamsTable.isHuman, true)))
    .orderBy(franchiseMcaTeamsTable.fullName);

  if (!allTeams.length) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ No teams found.")], components: [backToHubRow()] });
    return;
  }

  // Split by conference; fall back to NFL_DIVISION_MAP if conference field is null
  const afcTeams = allTeams.filter(t => {
    const c = t.conference?.toUpperCase();
    if (c === "AFC") return true;
    if (c === "NFC") return false;
    return NFL_DIVISION_MAP[t.nickName ?? ""]?.conference === "AFC";
  });
  const nfcTeams = allTeams.filter(t => {
    const c = t.conference?.toUpperCase();
    if (c === "NFC") return true;
    if (c === "AFC") return false;
    return NFL_DIVISION_MAP[t.nickName ?? ""]?.conference === "NFC";
  });

  // Use MCA teamId as value — teamSeasonStatsTable.teamId stores MCA ids
  const makeMenu = (conf: string, list: typeof allTeams) =>
    new StringSelectMenuBuilder()
      .setCustomId("ac_teamstats_sel")
      .setPlaceholder(`${conf} — pick a team…`)
      .addOptions(list.slice(0, 25).map(t =>
        new StringSelectMenuOptionBuilder().setLabel(t.fullName).setValue(String(t.mcaTeamId)),
      ));

  const components: ActionRowBuilder<StringSelectMenuBuilder | ButtonBuilder>[] = [];
  if (afcTeams.length) components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(makeMenu("🔴 AFC", afcTeams)));
  if (nfcTeams.length) components.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(makeMenu("🔵 NFC", nfcTeams)));
  components.push(cancelRow() as any);

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Blue).setTitle("🏟️ Team Stats — Select Team").setDescription("Pick a team from the **AFC** or **NFC** dropdown.")],
    components,
  });
}

async function handleTeamStatsShow(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  // Value is MCA teamId (not serial PK)
  const mcaTeamId = Number(interaction.values[0]);
  const gid       = interaction.guildId!;
  const season    = await getOrCreateActiveSeason(gid);

  const [teamRow, statsRow] = await Promise.all([
    db.select({ fullName: franchiseMcaTeamsTable.fullName })
      .from(franchiseMcaTeamsTable)
      .where(and(eq(franchiseMcaTeamsTable.seasonId, season.id), eq(franchiseMcaTeamsTable.teamId, mcaTeamId)))
      .limit(1).then(r => r[0]),
    db.select().from(teamSeasonStatsTable)
      .where(and(eq(teamSeasonStatsTable.seasonId, season.id), eq(teamSeasonStatsTable.teamId, mcaTeamId)))
      .limit(1).then(r => r[0]),
  ]);

  const teamName = teamRow?.fullName ?? "Unknown Team";

  if (!statsRow) {
    await interaction.update({ embeds: [new EmbedBuilder().setColor(Colors.Grey).setTitle(`🏟️ ${teamName} — Team Stats`).setDescription("No team stats found yet this season. Import MCA data to populate.")], components: [backToHubRow()] });
    return;
  }

  const ppg = statsRow.offPtsPerGame > 0 ? statsRow.offPtsPerGame.toFixed(1) : "N/A";
  const offPct = statsRow.offRedZonePct > 0 ? `${statsRow.offRedZonePct.toFixed(1)}%` : "N/A";
  const defPct = statsRow.defRedZonePct > 0 ? `${statsRow.defRedZonePct.toFixed(1)}%` : "N/A";

  const embed = new EmbedBuilder()
    .setColor(Colors.Blue)
    .setTitle(`🏟️ ${teamName} — Season ${season.seasonNumber} Stats`)
    .setDescription(`**Record: ${statsRow.wins}W-${statsRow.losses}L**`)
    .addFields(
      { name: "📤 Offense",       value: `Pass: ${statsRow.offPassYds.toLocaleString()} yds\nRush: ${statsRow.offRushYds.toLocaleString()} yds\nTotal: ${statsRow.offYds.toLocaleString()} yds\nPts/Game: ${ppg}\nRed Zone%: ${offPct}`, inline: true },
      { name: "📥 Defense",       value: `Pass Yds Allowed: ${statsRow.defPassYds.toLocaleString()}\nRush Yds Allowed: ${statsRow.defRushYds.toLocaleString()}\nSacks: ${statsRow.teamSacks}\nINTs: ${statsRow.teamInts}\nRZ% Allowed: ${defPct}`, inline: true },
      { name: "🔄 Turnovers",     value: `Turnover Diff: **${statsRow.turnoverDiff >= 0 ? "+" : ""}${statsRow.turnoverDiff}**\nFumbles Rec: ${statsRow.defFumblesRec}`, inline: true },
    )
    .setTimestamp();

  await interaction.update({ embeds: [embed], components: [backToHubRow()] });
}

// ═══════════════════════════════════════════════════════════════════════════════
//  ROW 3 — League Info
// ═══════════════════════════════════════════════════════════════════════════════

async function handleStandingsConfPick(interaction: ButtonInteraction, sess: ActionsSession) {
  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_standings_conf:AFC").setLabel("🔴 AFC").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId("ac_standings_conf:NFC").setLabel("🔵 NFC").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ac_standings_conf:ALL").setLabel("🌐 Both").setStyle(ButtonStyle.Secondary),
  );
  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_inthehunt").setLabel("🎯 In The Hunt").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_teamstowatch").setLabel("👀 Teams to Watch").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_hub").setLabel("← Back").setStyle(ButtonStyle.Secondary),
  );
  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Blue).setTitle("📈 Standings")
      .setDescription("Choose a conference view, or check In The Hunt / Teams to Watch.")],
    components: [row1, row2],
  });
}

async function handleStandingsShow(interaction: ButtonInteraction, sess: ActionsSession) {
  const conf = interaction.customId.split(":")[1] as "AFC" | "NFC" | "ALL";
  const gid  = interaction.guildId!;
  await interaction.deferUpdate();

  const season       = await getOrCreateActiveSeason(gid);
  const allStandings = await getArticleStandings(season.id, 18);

  if (conf === "ALL") {
    const afc = allStandings.filter(t => t.conference === "AFC");
    const nfc = allStandings.filter(t => t.conference === "NFC");
    if (!afc.length && !nfc.length) {
      await interaction.editReply({ embeds: [new EmbedBuilder().setColor(Colors.Grey).setTitle("League Standings").setDescription("No game data yet.")], components: [backToHubRow()] });
      return;
    }
    const embeds: EmbedBuilder[] = [];
    const buildConf = (conference: "AFC" | "NFC", teams: typeof allStandings) => {
      const sorted = [...teams].sort((a, b) => b.wins - a.wins || b.pointDifferential - a.pointDifferential);
      const lines  = sorted.map((t, i) => `**${i + 1}.** ${t.teamName} — ${t.wins}W-${t.losses}L (${t.pointDifferential >= 0 ? "+" : ""}${t.pointDifferential} pts)`);
      return new EmbedBuilder()
        .setColor(conference === "AFC" ? Colors.Red : Colors.Blue)
        .setTitle(`🏈 ${conference} Standings — Season ${season.seasonNumber}`)
        .setDescription(lines.join("\n") || "No data");
    };
    if (afc.length) embeds.push(buildConf("AFC", afc));
    if (nfc.length) embeds.push(buildConf("NFC", nfc));
    await interaction.editReply({ embeds, components: [backToHubRow()] });
    return;
  }

  const confTeams = allStandings.filter(t => t.conference === conf);
  if (!confTeams.length) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(Colors.Grey).setTitle(`${conf} Standings`).setDescription("No data yet.")], components: [backToHubRow()] });
    return;
  }

  const sorted = [...confTeams].sort((a, b) => b.wins - a.wins || b.pointDifferential - a.pointDifferential);
  const lines  = sorted.map((t, i) => `**${i + 1}.** ${t.teamName} — ${t.wins}W-${t.losses}L (${t.pointDifferential >= 0 ? "+" : ""}${t.pointDifferential} pts)`);

  const embed = new EmbedBuilder()
    .setColor(conf === "AFC" ? Colors.Red : Colors.Blue)
    .setTitle(`🏈 ${conf} Standings — Season ${season.seasonNumber}`)
    .setDescription(lines.join("\n"))
    .setTimestamp();

  await interaction.editReply({ embeds: [embed], components: [backToHubRow()] });
}

async function handleInTheHunt(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  await interaction.deferUpdate();

  const season       = await getOrCreateActiveSeason(gid);
  const allStandings = await getArticleStandings(season.id, 18);

  if (!allStandings.length) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(Colors.Grey).setTitle("🎯 In The Hunt").setDescription("No standings data yet.")],
      components: [backToHubRow()],
    });
    return;
  }

  const DIVISIONS = ["East", "North", "South", "West"] as const;

  const embeds: EmbedBuilder[] = [];

  for (const conf of ["AFC", "NFC"] as const) {
    const confTeams = allStandings.filter(t => t.conference === conf);
    if (!confTeams.length) continue;

    // Division leaders
    const divWinners = new Set<string>();
    for (const div of DIVISIONS) {
      const leader = confTeams
        .filter(t => t.division === div)
        .sort((a, b) => b.wins - a.wins || b.pointDifferential - a.pointDifferential)[0];
      if (leader) divWinners.add(leader.teamName);
    }

    const sortedWinners   = confTeams.filter(t =>  divWinners.has(t.teamName)).sort((a, b) => b.wins - a.wins || b.pointDifferential - a.pointDifferential);
    const sortedWildCards = confTeams.filter(t => !divWinners.has(t.teamName)).sort((a, b) => b.wins - a.wins || b.pointDifferential - a.pointDifferential);
    const seeds = [...sortedWinners, ...sortedWildCards];

    const wildCardSeeds = seeds.slice(4, 7);  // seeds 5-7
    const bubbleTeams   = seeds.slice(7, 10); // seeds 8-10
    const cutline       = wildCardSeeds[2];   // last team "in"

    const lines: string[] = [];

    lines.push("**Division Leaders (Seeds 1-4):**");
    sortedWinners.forEach((t, i) => {
      lines.push(`**#${i + 1}** ${t.teamName} — ${t.wins}-${t.losses}`);
    });

    if (wildCardSeeds.length) {
      lines.push("");
      lines.push("**🎯 Wild Card Race (Seeds 5-7):**");
      wildCardSeeds.forEach((t, i) => {
        const pd = t.pointDifferential >= 0 ? `+${t.pointDifferential}` : `${t.pointDifferential}`;
        lines.push(`✅ **#${i + 5}** ${t.teamName} — ${t.wins}-${t.losses} | PD ${pd} *(IN)*`);
      });
    }

    if (bubbleTeams.length && cutline) {
      lines.push("");
      lines.push("**⚠️ On The Bubble:**");
      bubbleTeams.forEach(t => {
        const gb = cutline.wins - t.wins;
        const pd = t.pointDifferential >= 0 ? `+${t.pointDifferential}` : `${t.pointDifferential}`;
        lines.push(`• ${t.teamName} — ${t.wins}-${t.losses} | PD ${pd} *(${gb} win${gb !== 1 ? "s" : ""} back)*`);
      });
    } else if (!wildCardSeeds.length) {
      lines.push("\n*Not enough teams to determine wild card race.*");
    }

    embeds.push(
      new EmbedBuilder()
        .setColor(conf === "AFC" ? Colors.Blue : Colors.Red)
        .setTitle(`🎯 ${conf} Playoff Hunt — Season ${season.seasonNumber}`)
        .setDescription(lines.join("\n"))
        .setTimestamp(),
    );
  }

  if (!embeds.length) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(Colors.Grey).setTitle("🎯 In The Hunt").setDescription("No conference data available.")],
      components: [backToHubRow()],
    });
    return;
  }

  await interaction.editReply({ embeds, components: [backToHubRow()] });
}

async function handleTeamsToWatch(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid  = interaction.guildId!;
  await interaction.deferUpdate();

  const season       = await getOrCreateActiveSeason(gid);
  const allStandings = await getArticleStandings(season.id, 18);

  if (!allStandings.length) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(Colors.Grey).setTitle("👀 Teams to Watch").setDescription("No standings data yet.")], components: [backToHubRow()] });
    return;
  }

  // Hot teams: most wins, best point differential among top-4 per conf
  const sorted = [...allStandings].sort((a, b) => b.wins - a.wins || b.pointDifferential - a.pointDifferential);
  const hot    = sorted.slice(0, 4);
  const cold   = [...sorted].sort((a, b) => a.wins - b.wins || a.pointDifferential - b.pointDifferential).slice(0, 4);

  const hotLines  = hot.map((t, i)  => `**${i + 1}.** ${t.teamName} (${t.conference}) — ${t.wins}W-${t.losses}L | ${t.pointDifferential >= 0 ? "+" : ""}${t.pointDifferential} pts`);
  const coldLines = cold.map((t, i) => `**${i + 1}.** ${t.teamName} (${t.conference}) — ${t.wins}W-${t.losses}L | ${t.pointDifferential >= 0 ? "+" : ""}${t.pointDifferential} pts`);

  const embed = new EmbedBuilder()
    .setColor(Colors.Orange)
    .setTitle(`👀 Teams to Watch — Season ${season.seasonNumber}`)
    .addFields(
      { name: "🔥 Best Performing",      value: hotLines.join("\n")  || "N/A", inline: false },
      { name: "❄️ Struggling Teams",     value: coldLines.join("\n") || "N/A", inline: false },
    )
    .setTimestamp();

  await interaction.editReply({ embeds: [embed], components: [backToHubRow()] });
}

async function handleAnyUserStatsTeamPick(interaction: ButtonInteraction, sess: ActionsSession) {
  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Blue).setTitle("👤 Any User Stats — Pick Conference")],
    components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_anyus_conf:AFC").setLabel("🔵 AFC").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("ac_anyus_conf:NFC").setLabel("🔴 NFC").setStyle(ButtonStyle.Danger),
      ),
      cancelRow(),
    ],
  });
}

async function handleAnyUserStatsConfPick(interaction: ButtonInteraction, sess: ActionsSession) {
  const conf = interaction.customId.split(":")[1] as "AFC" | "NFC";
  const gid  = interaction.guildId!;

  const allUsers = await db.select({ discordId: usersTable.discordId, discordUsername: usersTable.discordUsername, team: usersTable.team })
    .from(usersTable)
    .where(and(
      eq(usersTable.guildId, gid),
      isNotNull(usersTable.team),
      ne(usersTable.team, ""),
    ))
    .orderBy(usersTable.team);

  const confUsers = allUsers.filter(u => {
    const teamKey = (u.team ?? "").replace(/^(.*\s)?/, "").trim(); // try nickname last word
    const fullKey = (u.team ?? "").trim();
    const info = NFL_DIVISION_MAP[fullKey] ?? NFL_DIVISION_MAP[teamKey];
    return info?.conference === conf;
  });

  if (!confUsers.length) {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription(`❌ No ${conf} users found.`)],
      components: [backToHubRow()],
    });
    return;
  }

  const menu = new StringSelectMenuBuilder()
    .setCustomId("ac_anyus_sel")
    .setPlaceholder(`Select a ${conf} team owner…`)
    .addOptions(
      confUsers.slice(0, 25).map(u =>
        new StringSelectMenuOptionBuilder()
          .setLabel(`${u.team ?? u.discordUsername}`)
          .setDescription(`@${u.discordUsername}`)
          .setValue(u.discordId),
      ),
    );

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Blue).setTitle(`👤 Any User Stats — ${conf} Owners`)],
    components: [new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu), cancelRow()],
  });
}

async function handleAnyUserStatsShow(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const targetId = interaction.values[0]!;
  const gid      = interaction.guildId!;
  await interaction.deferUpdate();

  const [season, settings] = await Promise.all([
    getOrCreateActiveSeason(gid),
    getServerSettings(gid),
  ]);
  const rules = await getSeasonRules(season);

  const [targetUser, savingsRow, recordRow, seasonStatsRow, globalRecord, eaIds, lastTxns] = await Promise.all([
    db.select().from(usersTable).where(and(eq(usersTable.discordId, targetId), eq(usersTable.guildId, gid))).limit(1).then(r => r[0]),
    db.select({ balance: userSavingsTable.balance }).from(userSavingsTable).where(eq(userSavingsTable.discordId, targetId)).limit(1).then(r => r[0]),
    db.select().from(userRecordsTable).where(and(eq(userRecordsTable.discordId, targetId), eq(userRecordsTable.seasonId, season.id))).limit(1).then(r => r[0]),
    getSeasonStats(targetId, season.id),
    db.select({ wins: globalUserRecordsTable.wins, losses: globalUserRecordsTable.losses })
      .from(globalUserRecordsTable).where(eq(globalUserRecordsTable.discordId, targetId)).limit(1).then(r => r[0]),
    db.select({ eaId: playerEaIdsTable.eaId, console: playerEaIdsTable.console, slot: playerEaIdsTable.slot })
      .from(playerEaIdsTable).where(eq(playerEaIdsTable.discordId, targetId)).orderBy(playerEaIdsTable.slot),
    db.select({ amount: coinTransactionsTable.amount, description: coinTransactionsTable.description, createdAt: coinTransactionsTable.createdAt })
      .from(coinTransactionsTable)
      .where(and(eq(coinTransactionsTable.discordId, targetId), eq(coinTransactionsTable.guildId, gid)))
      .orderBy(desc(coinTransactionsTable.createdAt)).limit(10),
  ]);

  if (!targetUser) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(Colors.Red).setDescription("❌ User not found.")], components: [backToHubRow()] });
    return;
  }

  // Legends scoped to this guild via seasonId → seasonsTable.guildId join
  const legendRows = await db.select({ legendName: inventoryTable.legendName, legendCategory: inventoryTable.legendCategory })
    .from(inventoryTable)
    .innerJoin(seasonsTable, eq(inventoryTable.seasonId, seasonsTable.id))
    .where(and(
      eq(inventoryTable.itemType, "legend"),
      eq(seasonsTable.guildId, gid),
      eq(inventoryTable.discordId, targetId),
    ));

  // Custom players scoped to this guild via seasonId → seasonsTable.guildId join
  const customPlayerRows = await db.select({
    firstName: customPlayersTable.firstName, lastName: customPlayersTable.lastName,
    position: customPlayersTable.position, packageTier: customPlayersTable.packageTier,
  }).from(customPlayersTable)
    .innerJoin(seasonsTable, eq(customPlayersTable.seasonId, seasonsTable.id))
    .where(and(
      eq(customPlayersTable.discordId, targetId),
      eq(seasonsTable.guildId, gid),
      ne(customPlayersTable.status, "refunded"),
    ));

  const savings = savingsRow?.balance ?? 0;
  const total   = targetUser.balance + savings;
  const ssW     = recordRow?.wins          ?? 0;
  const ssL     = recordRow?.losses        ?? 0;
  const atW     = globalRecord?.wins       ?? 0;
  const atL     = globalRecord?.losses     ?? 0;
  const sbW     = recordRow?.superbowlWins ?? 0;

  const embed = new EmbedBuilder()
    .setColor(Colors.Blue)
    .setTitle(`👤 ${targetUser.team ?? targetUser.discordUsername} — User Stats`)
    .addFields(
      { name: "💰 Balance",       value: `Wallet: **${targetUser.balance.toLocaleString()}**\nSavings: **${savings.toLocaleString()}**\nTotal: **${total.toLocaleString()}**`, inline: true },
      { name: "📊 Season Record", value: `${ssW}W-${ssL}L`, inline: true },
      { name: "🏆 All-Time",      value: `${atW}W-${atL}L | ${sbW} SB${sbW !== 1 ? "s" : ""}`, inline: true },
    );

  if (eaIds.length) {
    embed.addFields({ name: "🎮 EA IDs", value: eaIds.map(e => `${e.console.toUpperCase()}: **${e.eaId}**`).join("\n"), inline: false });
  }

  if (seasonStatsRow) {
    const { devUpsPurchased, ageResetsPurchased } = seasonStatsRow;
    const ecoOn  = settings.coinEconomy;
    const devOn  = ecoOn && settings.devUpgradesEnabled;
    const ageOn  = ecoOn && settings.ageResetsEnabled;
    const devFmt = devOn ? `${devUpsPurchased ?? 0} (${rules.devUpsCap})`       : `${devUpsPurchased ?? 0} (n/a)`;
    const ageFmt = ageOn ? `${ageResetsPurchased ?? 0} (${rules.ageResetsCap})` : `${ageResetsPurchased ?? 0} (n/a)`;
    embed.addFields({
      name: "🛒 This Season's Purchases",
      value: `Dev Ups: ${devFmt} | Age Resets: ${ageFmt}`,
      inline: false,
    });
  }

  const vaultLegends   = legendRows.filter(l => l.legendCategory === "permanent");
  const currentLegends = legendRows.filter(l => l.legendCategory !== "permanent");
  if (legendRows.length) {
    const parts: string[] = [];
    if (currentLegends.length) parts.push(`Season: ${currentLegends.map(l => l.legendName).join(", ")}`);
    if (vaultLegends.length)   parts.push(`Vault: ${vaultLegends.map(l => l.legendName).join(", ")}`);
    embed.addFields({ name: "🏅 Legends", value: parts.join("\n"), inline: false });
  }

  if (customPlayerRows.length) {
    embed.addFields({
      name: "⚡ Custom Players",
      value: customPlayerRows.map(p => `${p.firstName} ${p.lastName} (${p.position}) — ${p.packageTier}`).join("\n"),
      inline: false,
    });
  }

  if (lastTxns.length) {
    const txLines = lastTxns.map(t => {
      const sign = t.amount >= 0 ? "+" : "";
      const ts   = `<t:${Math.floor(new Date(t.createdAt).getTime() / 1000)}:d>`;
      return `${ts} **${sign}${t.amount.toLocaleString()}** — ${t.description}`;
    });
    embed.addFields({ name: "📋 Last 10 Transactions", value: txLines.join("\n"), inline: false });
  }

  embed.setTimestamp();
  await interaction.editReply({ embeds: [embed], components: [backToHubRow()] });
}

// ═══════════════════════════════════════════════════════════════════════════════
//  ROW 4 — Rankings & Payouts
// ═══════════════════════════════════════════════════════════════════════════════

async function handleSeasonPR(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  await interaction.deferUpdate();

  const season  = await getOrCreateActiveSeason(gid);
  // Query directly — do NOT overlay allTimeSuperbowlWins (cross-guild contamination risk).
  // seasonId is unique per guild so this is already guild-scoped.
  const dbRows = await db.select().from(userRecordsTable)
    .where(eq(userRecordsTable.seasonId, season.id));

  if (!dbRows.length) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(Colors.Blue).setTitle(`📊 Season ${season.seasonNumber} Power Rankings`).setDescription("No game records yet.")], components: [backToHubRow()] });
    return;
  }

  const ranked = dbRows.map(r => ({
    discordId:         r.discordId,
    discordUsername:   r.discordUsername,
    team:              r.team ?? null,
    wins:              r.wins,
    losses:            r.losses,
    pointDifferential: r.pointDifferential,
    playoffWins:       r.playoffWins,
    playoffLosses:     r.playoffLosses,
    superbowlWins:     r.superbowlWins,
    superbowlLosses:   r.superbowlLosses,
    gp: r.wins + r.losses,
    pr: calcPRScore(r.wins, r.losses, r.pointDifferential),
    label: r.team ?? r.discordUsername,
  })).sort((a, b) => b.pr - a.pr);

  const medals = ["🥇", "🥈", "🥉"];
  const lines  = ranked.map((r, i) => {
    const badge   = medals[i] ?? `**${ordinal(i + 1)}**`;
    const winPct  = r.gp > 0 ? ((r.wins / r.gp) * 100).toFixed(1) : "0.0";
    const postseason = [
      r.playoffWins + r.playoffLosses > 0 ? `PO: ${r.playoffWins}W-${r.playoffLosses}L` : "",
      r.superbowlWins + r.superbowlLosses > 0 ? `🏆SB: ${r.superbowlWins}W-${r.superbowlLosses}L` : "",
    ].filter(Boolean).join(" | ");
    return `${badge} **${r.label}** — ${r.wins}W-${r.losses}L | ${fmtDiff(r.pointDifferential)} pts | ${winPct}% | PR: ${r.pr.toFixed(1)}${postseason ? ` *(${postseason})*` : ""}`;
  });

  const embed = new EmbedBuilder()
    .setColor(Colors.Gold)
    .setTitle(`📊 Season ${season.seasonNumber} Power Rankings`)
    .setDescription(lines.join("\n"))
    .setFooter({ text: "PR Score = 60% × (W-L Diff) + 40% × (Point Diff)" })
    .setTimestamp();

  await interaction.editReply({ embeds: [embed], components: [backToHubRow()] });
}

async function handleAllTimePR(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  await interaction.deferUpdate();

  // Get season IDs belonging to this guild only — avoids cross-guild record contamination.
  const guildSeasonRows = await db.select({ id: seasonsTable.id }).from(seasonsTable)
    .where(eq(seasonsTable.guildId, gid));
  const guildSeasonIds = guildSeasonRows.map(s => s.id);

  const dbRows = guildSeasonIds.length
    ? await db.select().from(userRecordsTable).where(inArray(userRecordsTable.seasonId, guildSeasonIds))
    : [];

  // Load current guild roster for team labels and allTimeSuperbowlWins (guild-scoped)
  const guildUsers = await db.select({
    discordId:            usersTable.discordId,
    discordUsername:      usersTable.discordUsername,
    team:                 usersTable.team,
    allTimeSuperbowlWins: usersTable.allTimeSuperbowlWins,
    allTimeSuperbowlLosses: usersTable.allTimeSuperbowlLosses,
  }).from(usersTable).where(eq(usersTable.guildId, gid));

  const guildTeamMap = new Map(guildUsers.map(u => [u.discordId, u]));

  // Aggregate across seasons (within this guild)
  const agg = new Map<string, {
    discordId: string; discordUsername: string; team: string | null;
    wins: number; losses: number; pointDifferential: number;
    playoffWins: number; playoffLosses: number; superbowlWins: number; superbowlLosses: number;
  }>();
  for (const r of dbRows) {
    const ex = agg.get(r.discordId);
    if (ex) {
      ex.wins               += r.wins;
      ex.losses             += r.losses;
      ex.pointDifferential  += r.pointDifferential;
      ex.playoffWins        += r.playoffWins;
      ex.playoffLosses      += r.playoffLosses;
      ex.superbowlWins      += r.superbowlWins;
      ex.superbowlLosses    += r.superbowlLosses;
      if (r.team) ex.team    = r.team;
      ex.discordUsername     = r.discordUsername;
    } else {
      agg.set(r.discordId, {
        discordId:         r.discordId,
        discordUsername:   r.discordUsername,
        team:              r.team ?? null,
        wins:              r.wins,
        losses:            r.losses,
        pointDifferential: r.pointDifferential,
        playoffWins:       r.playoffWins,
        playoffLosses:     r.playoffLosses,
        superbowlWins:     r.superbowlWins,
        superbowlLosses:   r.superbowlLosses,
      });
    }
  }

  // Overlay allTimeSuperbowlWins/Losses from usersTable (guild-scoped — no cross-guild bleed)
  for (const [id, rec] of agg) {
    const u = guildTeamMap.get(id);
    if (u) {
      rec.superbowlWins   = Math.max(rec.superbowlWins,   u.allTimeSuperbowlWins   ?? 0);
      rec.superbowlLosses = Math.max(rec.superbowlLosses, u.allTimeSuperbowlLosses ?? 0);
    }
  }

  // Filter to only users who are in this guild
  const filtered = [...agg.values()].filter(r => guildTeamMap.has(r.discordId));

  if (!filtered.length) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(Colors.Blue).setTitle("🏆 All-Time Power Rankings").setDescription("No all-time records yet.")], components: [backToHubRow()] });
    return;
  }

  const ranked = filtered.map(r => {
    const u = guildTeamMap.get(r.discordId);
    const currentTeam = u?.team ?? null;
    let teamSuffix: string;
    if (currentTeam && currentTeam.trim() !== "") {
      teamSuffix = ` (${currentTeam})`;
    } else if (r.team && r.team.trim() !== "") {
      teamSuffix = ` (PREV "${r.team}")`;
    } else {
      teamSuffix = "";
    }
    return {
      ...r,
      gp:    r.wins + r.losses,
      pr:    calcPRScore(r.wins, r.losses, r.pointDifferential),
      label: `${r.discordUsername}${teamSuffix}`,
    };
  }).sort((a, b) => b.pr - a.pr);

  const medals = ["🥇", "🥈", "🥉"];
  const lines  = ranked.map((r, i) => {
    const badge   = medals[i] ?? `**${ordinal(i + 1)}**`;
    const winPct  = r.gp > 0 ? ((r.wins / r.gp) * 100).toFixed(1) : "0.0";
    const postseason = [
      r.playoffWins + r.playoffLosses > 0 ? `PO: ${r.playoffWins}W-${r.playoffLosses}L` : "",
      r.superbowlWins + r.superbowlLosses > 0 ? `🏆SB: ${r.superbowlWins}W-${r.superbowlLosses}L` : "",
    ].filter(Boolean).join(" | ");
    return `${badge} **${r.label}** — ${r.wins}W-${r.losses}L | ${fmtDiff(r.pointDifferential)} pts | ${winPct}% | PR: ${r.pr.toFixed(1)}${postseason ? ` *(${postseason})*` : ""}`;
  });

  const embed = new EmbedBuilder()
    .setColor(Colors.Purple)
    .setTitle("🏆 All-Time Power Rankings")
    .setDescription(lines.join("\n"))
    .setFooter({ text: "PR Score = 60% × (W-L Diff) + 40% × (Point Diff)" })
    .setTimestamp();

  await interaction.editReply({ embeds: [embed], components: [backToHubRow()] });
}

async function handleGlobalPR(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  await interaction.deferUpdate();

  // Step 1: fetch guild members only (for the display list)
  const guildUsers = await db.select({
    discordId:       usersTable.discordId,
    team:            usersTable.team,
    discordUsername: usersTable.discordUsername,
    walletBalance:   usersTable.balance,
  }).from(usersTable)
    .where(and(
      eq(usersTable.guildId, gid),
      isNotNull(usersTable.team),
      ne(usersTable.team, ""),
      ne(usersTable.discordUsername, "Open Slot"),
    ));

  if (!guildUsers.length) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(Colors.Blue).setTitle("🌐 Global Power Rankings").setDescription("No linked users found in this server.")], components: [backToHubRow()] });
    return;
  }

  // Step 2: fetch ALL global records (for accurate global rank)
  const allGlobalRecords = await db.select({
    discordId: globalUserRecordsTable.discordId,
    wins:      globalUserRecordsTable.wins,
    losses:    globalUserRecordsTable.losses,
    pointDiff: globalUserRecordsTable.pointDifferential,
  }).from(globalUserRecordsTable);

  // Step 3: rank ALL global records by PR score
  const globalRanked = allGlobalRecords
    .map(r => ({ discordId: r.discordId, pr: calcPRScore(r.wins ?? 0, r.losses ?? 0, r.pointDiff ?? 0), wins: r.wins ?? 0, losses: r.losses ?? 0, pd: r.pointDiff ?? 0 }))
    .sort((a, b) => b.pr - a.pr);

  const globalRankMap = new Map<string, { rank: number; wins: number; losses: number; pd: number; pr: number }>();
  globalRanked.forEach((r, i) => globalRankMap.set(r.discordId, { rank: i + 1, wins: r.wins, losses: r.losses, pd: r.pd, pr: r.pr }));

  // Step 3b: aggregate global playoff / SB data from userRecordsTable across all seasons & guilds
  const allSeasonRecords = await db.select({
    discordId:      userRecordsTable.discordId,
    playoffWins:    userRecordsTable.playoffWins,
    playoffLosses:  userRecordsTable.playoffLosses,
    superbowlWins:  userRecordsTable.superbowlWins,
    superbowlLosses: userRecordsTable.superbowlLosses,
  }).from(userRecordsTable);

  const globalPostseasonMap = new Map<string, { pw: number; pl: number; sw: number; sl: number }>();
  for (const r of allSeasonRecords) {
    const ex = globalPostseasonMap.get(r.discordId);
    if (ex) {
      ex.pw += r.playoffWins;
      ex.pl += r.playoffLosses;
      ex.sw += r.superbowlWins;
      ex.sl += r.superbowlLosses;
    } else {
      globalPostseasonMap.set(r.discordId, { pw: r.playoffWins, pl: r.playoffLosses, sw: r.superbowlWins, sl: r.superbowlLosses });
    }
  }

  // Step 4: fetch savings balances for guild users
  const guildIds = guildUsers.map(u => u.discordId);
  const savingsRows = guildIds.length
    ? await db.select({ discordId: userSavingsTable.discordId, balance: userSavingsTable.balance })
        .from(userSavingsTable)
        .where(inArray(userSavingsTable.discordId, guildIds))
    : [];
  const savingsMap = new Map(savingsRows.map(s => [s.discordId, s.balance]));

  // Step 5: build display rows for guild users (sorted by global rank)
  const displayRows = guildUsers
    .map(u => {
      const g  = globalRankMap.get(u.discordId);
      const ps = globalPostseasonMap.get(u.discordId);
      return {
        discordId:     u.discordId,
        username:      u.discordUsername ?? u.discordId,
        team:          u.team ?? "",
        globalRank:    g?.rank ?? 99999,
        wins:          g?.wins ?? 0,
        losses:        g?.losses ?? 0,
        pd:            g?.pd ?? 0,
        pr:            g?.pr ?? 0,
        totalCoins:    (u.walletBalance ?? 0) + (savingsMap.get(u.discordId) ?? 0),
        playoffWins:   ps?.pw ?? 0,
        playoffLosses: ps?.pl ?? 0,
        superbowlWins: ps?.sw ?? 0,
        superbowlLosses: ps?.sl ?? 0,
      };
    })
    .sort((a, b) => a.globalRank - b.globalRank);

  const medals = ["🥇", "🥈", "🥉"];
  const lines = displayRows.map(r => {
    const gp        = r.wins + r.losses;
    const winPct    = gp > 0 ? ((r.wins / gp) * 100).toFixed(1) : "0.0";
    const rankBadge = medals[r.globalRank - 1] ?? `**#${r.globalRank}**`;
    const label     = r.team ? `${r.username} (${r.team})` : r.username;
    const postseason = [
      r.playoffWins + r.playoffLosses > 0 ? `PO: ${r.playoffWins}W-${r.playoffLosses}L` : "",
      r.superbowlWins + r.superbowlLosses > 0 ? `🏆SB: ${r.superbowlWins}W-${r.superbowlLosses}L` : "",
    ].filter(Boolean).join(" | ");
    return `${rankBadge} ${label} — ${r.wins}W-${r.losses}L | ${fmtDiff(r.pd)} pts | ${winPct}% | PR: ${r.pr.toFixed(1)} | 🪙 ${r.totalCoins.toLocaleString()}${postseason ? ` *(${postseason})*` : ""}`;
  });

  const embed = new EmbedBuilder()
    .setColor(Colors.Green)
    .setTitle("🌐 Global Power Rankings")
    .setDescription(lines.join("\n") || "No data")
    .setFooter({ text: `${displayRows.length} members shown • Global rank shown (#) • Coins = wallet + savings` })
    .setTimestamp();

  await interaction.editReply({ embeds: [embed], components: [backToHubRow()] });
}

async function handleWeeklyPayouts(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  await interaction.deferUpdate();

  const [
    h2hWin, h2hLoss, cpuWin,
    hlPay, hlPostPay, hlLimit,
    streamPay,
    tweetPay, tweetLimit,
    interviewPay,
    gotwReg, gotwPo, potwBonus,
  ] = await Promise.all([
    getPayoutValue(PAYOUT_KEYS.H2H_WIN,                gid),
    getPayoutValue(PAYOUT_KEYS.H2H_LOSS,               gid),
    getPayoutValue(PAYOUT_KEYS.CPU_WIN,                gid),
    getPayoutValue(PAYOUT_KEYS.HIGHLIGHT_PAYOUT,       gid),
    getPayoutValue(PAYOUT_KEYS.HIGHLIGHT_PLAYOFF_PAYOUT, gid),
    getPayoutValue(PAYOUT_KEYS.HIGHLIGHT_LIMIT,        gid),
    getPayoutValue(PAYOUT_KEYS.STREAM_PAYOUT,          gid),
    getPayoutValue(PAYOUT_KEYS.TWEET_PAYOUT,           gid),
    getPayoutValue(PAYOUT_KEYS.TWEET_WEEKLY_LIMIT,     gid),
    getPayoutValue(PAYOUT_KEYS.INTERVIEW_PAYOUT,       gid),
    getPayoutValue(PAYOUT_KEYS.GOTW_REGULAR_BONUS,     gid),
    getPayoutValue(PAYOUT_KEYS.GOTW_PLAYOFF_BONUS,     gid),
    getPayoutValue(PAYOUT_KEYS.POTW_BONUS,             gid),
  ]);

  const hlCapNote   = hlLimit > 0 ? ` *(max ${hlLimit}/week)*` : "";
  const tweetCapNote = tweetLimit > 0 ? ` *(max ${tweetLimit}/week)*` : " *(no weekly limit)*";

  const embed = new EmbedBuilder()
    .setColor(Colors.Gold)
    .setTitle("📅 Weekly Payout Schedule")
    .setDescription("Coins earned each week through games, activity, and league engagement.")
    .addFields(
      {
        name: "🏈 Game Results",
        value: [
          `H2H Win: **${h2hWin.toLocaleString()}** coins`,
          `H2H Loss: **${h2hLoss.toLocaleString()}** coins`,
          `CPU / Force Win: **${cpuWin.toLocaleString()}** coins`,
        ].join("\n"),
        inline: false,
      },
      {
        name: "📺 Activity Payouts",
        value: [
          `Highlight (Regular Season): **${hlPay.toLocaleString()}** coins per video${hlCapNote}`,
          `Highlight (Postseason): **${hlPostPay.toLocaleString()}** coins per video${hlCapNote}`,
          `Twitch Stream: **${streamPay.toLocaleString()}** coins per side (streamer + opponent)`,
          `Tweet: **${tweetPay.toLocaleString()}** coins per post${tweetCapNote}`,
          `Interview: **${interviewPay.toLocaleString()}** coins per approved submission`,
        ].join("\n"),
        inline: false,
      },
      {
        name: "🏆 Weekly Bonuses",
        value: [
          `GOTW Correct Guess (Regular Season): **${gotwReg.toLocaleString()}** coins`,
          `GOTW Correct Guess (Playoffs): **${gotwPo.toLocaleString()}** coins`,
          `Player of the Week Winner: **${potwBonus.toLocaleString()}** coins`,
        ].join("\n"),
        inline: false,
      },
    )
    .setFooter({ text: "Payout amounts set by your commissioner · /admin-payout" })
    .setTimestamp();

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_hub").setLabel("← Back to Hub").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close Menu").setStyle(ButtonStyle.Danger),
  );

  await interaction.editReply({ embeds: [embed], components: [row] });
}

async function handleEosPayouts(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  await interaction.deferUpdate();

  const season = await getOrCreateActiveSeason(gid);

  const [configMap, tierRows] = await Promise.all([
    getAllPayoutConfig(gid),
    db.select().from(seasonStatTierConfigsTable)
      .where(eq(seasonStatTierConfigsTable.seasonId, season.id)),
  ]);
  const allKeys = getAllPayoutKeys();

  // ── Flat payout categories ───────────────────────────────────────────────────
  const cats: Record<string, string[]> = {};
  for (const meta of allKeys) {
    const val = configMap.get(meta.key as any) ?? meta.defaultValue;
    const cat = meta.category ?? "General";
    if (!cats[cat]) cats[cat] = [];
    cats[cat].push(`${meta.description}: **${val.toLocaleString()}** coins`);
  }

  const embed = new EmbedBuilder()
    .setColor(Colors.Gold)
    .setTitle("💰 Payout Tiers");

  for (const [cat, items] of Object.entries(cats)) {
    const chunk = items.join("\n");
    if (chunk) embed.addFields({ name: cat, value: chunk.slice(0, 1024), inline: false });
  }

  // ── Stat tier thresholds (passing yards, rushing yards, etc.) ────────────────
  const tiersByCategory = new Map<string, { tier: number; threshold: number; payout: number }[]>();
  for (const row of tierRows) {
    if (!tiersByCategory.has(row.statCategory)) tiersByCategory.set(row.statCategory, []);
    tiersByCategory.get(row.statCategory)!.push({ tier: row.tier, threshold: row.threshold, payout: row.payout });
  }
  for (const [key, defaults] of Object.entries(STAT_TIER_DEFAULTS)) {
    if (!tiersByCategory.has(key)) {
      tiersByCategory.set(key, defaults.map((d, i) => ({ tier: i + 1, threshold: d.threshold, payout: d.payout })));
    }
  }

  const dirSym = (dir: string) => dir === "higher" ? "≥" : "≤";
  const statLines: string[] = [];
  for (const cat of STAT_CATEGORIES) {
    const tiers = tiersByCategory.get(cat.key);
    if (!tiers || !tiers.length) continue;
    const sorted = [...tiers].sort((a, b) => a.tier - b.tier);
    const sym    = dirSym(cat.direction);
    const tierStr = sorted.map(t => `T${t.tier}:${sym}${t.threshold.toLocaleString()} →${t.payout}c`).join(" | ");
    statLines.push(`**${cat.label}:** ${tierStr}`);
  }
  if (statLines.length) {
    embed.addFields({ name: "📊 EOS Stat Tier Bonuses", value: statLines.join("\n").slice(0, 1024), inline: false });
  }

  embed.setTimestamp();
  await interaction.editReply({ embeds: [embed], components: [backToHubRow()] });
}

async function handleMilestonePayouts(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  await interaction.deferUpdate();

  const tiers = await getMilestoneTiers(gid);

  if (!tiers.length) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(Colors.Grey).setTitle("🎯 Milestone Payouts").setDescription("No milestone tiers configured yet. Ask a commissioner to set them up with `/admin-payout`.")], components: [backToHubRow()] });
    return;
  }

  const lines = tiers.map(t =>
    `**Tier ${t.tier}** — ${t.bonus.toLocaleString()} coins (Threshold: ${t.wins.toLocaleString()} wins)`
  );

  const embed = new EmbedBuilder()
    .setColor(Colors.Gold)
    .setTitle("🎯 Milestone Payout Tiers")
    .setDescription(lines.join("\n"))
    .setTimestamp();

  await interaction.editReply({ embeds: [embed], components: [backToHubRow()] });
}

// ═══════════════════════════════════════════════════════════════════════════════
//  ROW 5 — Requests
// ═══════════════════════════════════════════════════════════════════════════════

async function handleActiveTeams(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  await interaction.deferUpdate();

  const users = await db.select({ discordId: usersTable.discordId, team: usersTable.team })
    .from(usersTable)
    .where(and(eq(usersTable.guildId, gid), isNotNull(usersTable.team), ne(usersTable.team, "")));

  // Build team → discordId map using economy_users.team which is always the
  // canonical NFL_TEAMS name set by the admin link button
  const activeMap = new Map<string, string>();
  for (const u of users) {
    if (u.discordId.startsWith("unlinked_") || !u.team) continue;
    activeMap.set(u.team, u.discordId);
  }

  if (!activeMap.size) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(Colors.Grey).setTitle("🟢 Active Teams").setDescription("No active teams found.")], components: [backToHubRow()] });
    return;
  }

  const CONF_EMOJI: Record<string, string> = { AFC: "🔴", NFC: "🔵" };
  const DIV_ORDER = ["East", "North", "South", "West"] as const;

  const embed = new EmbedBuilder()
    .setColor(Colors.Green)
    .setTitle(`🟢 Active Teams (${activeMap.size})`)
    .setTimestamp();

  for (const conf of ["AFC", "NFC"] as const) {
    for (const div of DIV_ORDER) {
      const divTeams = NFL_TEAMS.filter(t => NFL_DIVISION_MAP[t]?.conference === conf && NFL_DIVISION_MAP[t]?.division === div);
      const activeLines = divTeams
        .filter(t => activeMap.has(t))
        .map(t => `• **${t}** — <@${activeMap.get(t)!}>`);

      if (activeLines.length) {
        embed.addFields({ name: `${CONF_EMOJI[conf]} ${conf} ${div}`, value: activeLines.join("\n"), inline: true });
      }
    }
  }

  await interaction.editReply({ embeds: [embed], components: [backToHubRow()] });
}

async function handleOpenTeams(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  await interaction.deferUpdate();

  const takenRows = await db.select({ team: usersTable.team, discordId: usersTable.discordId })
    .from(usersTable)
    .where(and(eq(usersTable.guildId, gid), isNotNull(usersTable.team)));

  // Taken = teams held by real (non-unlinked) users.
  // usersTable.team is always a canonical NFL_TEAMS name (set by admin on link).
  // MCA nickNames like "Bolts", "Jags", "G-Men", "Niners", "Pack", "Pats" do NOT
  // match NFL_TEAMS, so we rely on usersTable — not MCA — as the source of truth.
  const taken = new Set<string>();
  for (const r of takenRows) {
    if (!r.discordId || r.discordId.startsWith("unlinked_")) continue;
    if (r.team) taken.add(r.team);
  }

  const openTeams = NFL_TEAMS.filter(t => !taken.has(t));

  if (!openTeams.length) {
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(Colors.Grey).setTitle("🔴 Open Teams").setDescription("All 32 teams are currently claimed!")], components: [backToHubRow()] });
    return;
  }

  const embed = new EmbedBuilder()
    .setColor(Colors.Red)
    .setTitle(`🔴 Open Teams (${openTeams.length} available)`)
    .setTimestamp();

  const OPEN_CONF_EMOJI: Record<string, string> = { AFC: "🔴", NFC: "🔵" };
  const DIV_ORDER_OPEN = ["East", "North", "South", "West"] as const;
  for (const conf of ["AFC", "NFC"] as const) {
    for (const div of DIV_ORDER_OPEN) {
      const divTeams = openTeams
        .filter(t => NFL_DIVISION_MAP[t]?.conference === conf && NFL_DIVISION_MAP[t]?.division === div)
        .sort();
      if (divTeams.length) {
        embed.addFields({ name: `${OPEN_CONF_EMOJI[conf]} ${conf} ${div}`, value: divTeams.map(t => `• ${t}`).join("\n"), inline: true });
      }
    }
  }

  await interaction.editReply({ embeds: [embed], components: [backToHubRow()] });
}

async function handleAutoPilotModal(interaction: ButtonInteraction) {
  const modal = new ModalBuilder()
    .setCustomId("ac_modal_autopilot")
    .setTitle("Request Auto-Pilot Coverage")
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("weeks")
          .setLabel("How many weeks do you need coverage?")
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setPlaceholder("e.g. 2")
          .setMaxLength(3),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("reason")
          .setLabel("Reason for Auto-Pilot request")
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(500)
          .setPlaceholder("Briefly explain why you need auto-pilot coverage…"),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("arrangement")
          .setLabel("Any arrangement details? (optional)")
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(false)
          .setMaxLength(300)
          .setPlaceholder("e.g. Back by Week 8, sim-only, specific plays, etc."),
      ),
    );
  await interaction.showModal(modal);
}

async function handleAutoPilotSubmit(interaction: ModalSubmitInteraction, sess: ActionsSession) {
  const weeks       = interaction.fields.getTextInputValue("weeks").trim();
  const reason      = interaction.fields.getTextInputValue("reason").trim();
  const arrangement = interaction.fields.getTextInputValue("arrangement").trim();
  const gid         = interaction.guildId!;

  const weeksNum = parseInt(weeks, 10);
  if (isNaN(weeksNum) || weeksNum < 1) {
    await interaction.reply({ content: "❌ Invalid week count.", ephemeral: true }); return;
  }

  const [season, user] = await Promise.all([
    getOrCreateActiveSeason(gid),
    getOrCreateUser(interaction.user.id, interaction.user.username, gid),
  ]);

  await db.insert(autoPilotRequestsTable).values({
    discordId:      interaction.user.id,
    guildId:        gid,
    teamName:       user.team ?? null,
    weeksRequested: weeksNum,
    reason:         arrangement ? `${reason}\n\nArrangement: ${arrangement}` : reason,
    status:         "pending",
  });

  // Notify commissioner log
  const logChannelId = await getGuildChannel(gid, CHANNEL_KEYS.COMMISSIONER_LOG)
    ?? await getGuildChannel(gid, CHANNEL_KEYS.COMMISSIONER);

  if (logChannelId) {
    const channel = await interaction.client.channels.fetch(logChannelId).catch(() => null);
    if (channel?.isTextBased()) {
      const requestEmbed = new EmbedBuilder()
        .setColor(Colors.Yellow)
        .setTitle("✈️ Auto-Pilot Request")
        .setDescription(`**${user.team ?? interaction.user.username}** (<@${interaction.user.id}>) has requested auto-pilot coverage.`)
        .addFields(
          { name: "⏱️ Weeks", value: String(weeksNum), inline: true },
          { name: "📝 Reason", value: reason, inline: false },
        )
        .setTimestamp();
      if (arrangement) requestEmbed.addFields({ name: "📋 Arrangement", value: arrangement, inline: false });

      const btnRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId(`ac_ap_approve:${interaction.user.id}`).setLabel("✅ Approve").setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId(`ac_ap_deny:${interaction.user.id}`).setLabel("❌ Deny").setStyle(ButtonStyle.Danger),
      );

      await (channel as TextChannel).send({ embeds: [requestEmbed], components: [btnRow] }).catch(console.error);
    }
  }

  await interaction.reply({
    ephemeral: true,
    embeds: [new EmbedBuilder()
      .setColor(Colors.Yellow)
      .setTitle("⏳ Auto-Pilot Request Submitted")
      .setDescription(`Your auto-pilot request for **${weeksNum} week${weeksNum !== 1 ? "s" : ""}** has been sent to the commissioners.\n\n**Reason:** ${reason}`)],
  });
}

async function handleApproveAutoPilot(interaction: ButtonInteraction) {
  const targetId = interaction.customId.split(":")[1];
  const gid      = interaction.guildId!;

  await db.update(autoPilotRequestsTable)
    .set({ status: "approved", reviewedBy: interaction.user.id, reviewedAt: new Date() })
    .where(and(
      eq(autoPilotRequestsTable.discordId, targetId!),
      eq(autoPilotRequestsTable.guildId, gid),
      eq(autoPilotRequestsTable.status, "pending"),
    ));

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Green).setTitle("✅ Auto-Pilot Approved").setDescription(`Auto-pilot request for <@${targetId}> has been **approved** by <@${interaction.user.id}>.`)],
    components: [],
  });

  // DM the user
  const client = interaction.client;
  const dUser  = await client.users.fetch(targetId!).catch(() => null);
  if (dUser) {
    await dUser.send({ content: `✅ Your auto-pilot request has been **approved** by the commissioners. You're covered!` }).catch(() => {});
  }
}

async function handleDenyAutoPilot(interaction: ButtonInteraction) {
  const targetId = interaction.customId.split(":")[1];
  const gid      = interaction.guildId!;

  await db.update(autoPilotRequestsTable)
    .set({ status: "denied", reviewedBy: interaction.user.id, reviewedAt: new Date() })
    .where(and(
      eq(autoPilotRequestsTable.discordId, targetId!),
      eq(autoPilotRequestsTable.guildId, gid),
      eq(autoPilotRequestsTable.status, "pending"),
    ));

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Red).setTitle("❌ Auto-Pilot Denied").setDescription(`Auto-pilot request for <@${targetId}> has been **denied** by <@${interaction.user.id}>.`)],
    components: [],
  });

  const client = interaction.client;
  const dUser  = await client.users.fetch(targetId!).catch(() => null);
  if (dUser) {
    await dUser.send({ content: `❌ Your auto-pilot request has been **denied** by the commissioners. Please reach out if you have questions.` }).catch(() => {});
  }
}

// ── Rule Violation ─────────────────────────────────────────────────────────────

async function handleViolationModal(interaction: ButtonInteraction) {
  const modal = new ModalBuilder()
    .setCustomId("ac_modal_violation")
    .setTitle("Report a Rule Violation")
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("week_number")
          .setLabel("Week number this occurred")
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(4)
          .setPlaceholder("e.g. 5"),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("violation_type")
          .setLabel("Type of violation")
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(100)
          .setPlaceholder("e.g. Stat padding, Rage quit, Missed game, etc."),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("offender")
          .setLabel("Offender — username or team name")
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(100),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("description")
          .setLabel("Describe what happened")
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(900)
          .setPlaceholder("Provide details, evidence links, context, etc."),
      ),
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("media_urls")
          .setLabel("Media URLs (optional, space or comma separated)")
          .setStyle(TextInputStyle.Short)
          .setRequired(false)
          .setMaxLength(500)
          .setPlaceholder("https://... (screenshots, clips, etc.)"),
      ),
    );
  await interaction.showModal(modal);
}

async function handleViolationSubmit(interaction: ModalSubmitInteraction, sess: ActionsSession) {
  const weekNumber    = interaction.fields.getTextInputValue("week_number").trim();
  const violationType = interaction.fields.getTextInputValue("violation_type").trim();
  const offender      = interaction.fields.getTextInputValue("offender").trim();
  const rawDesc       = interaction.fields.getTextInputValue("description").trim();
  const rawMedia      = interaction.fields.getTextInputValue("media_urls").trim();
  const description   = `[${violationType}] Against: ${offender}\n\n${rawDesc}`;
  const gid           = interaction.guildId!;

  // Parse media URLs (space or comma separated)
  const mediaUrls = rawMedia
    ? rawMedia.split(/[\s,]+/).map(u => u.trim()).filter(u => u.startsWith("http"))
    : [];

  const [season, user] = await Promise.all([
    getOrCreateActiveSeason(gid),
    getOrCreateUser(interaction.user.id, interaction.user.username, gid),
  ]);

  // Insert and retrieve the new violation ID
  const [inserted] = await db.insert(ruleViolationsTable).values({
    reporterId:   interaction.user.id,
    guildId:      gid,
    seasonId:     season.id,
    reporterTeam: user.team ?? null,
    opponentTeam: offender,
    weekNumber,
    description,
    mediaUrls,
    status:       "pending",
  }).returning({ id: ruleViolationsTable.id });

  const violationId = inserted?.id ?? 0;

  // Send to commissioner log
  const logChannelId = await getGuildChannel(gid, CHANNEL_KEYS.VIOLATION_LOG)
    ?? await getGuildChannel(gid, CHANNEL_KEYS.COMMISSIONER_LOG)
    ?? await getGuildChannel(gid, CHANNEL_KEYS.COMMISSIONER);

  if (logChannelId) {
    const channel = await interaction.client.channels.fetch(logChannelId).catch(() => null);
    if (channel?.isTextBased()) {
      const reportEmbed = new EmbedBuilder()
        .setColor(Colors.Red)
        .setTitle("🚨 Rule Violation Report")
        .setDescription(`**Reporter:** ${user.team ?? interaction.user.username} (<@${interaction.user.id}>)`)
        .addFields(
          { name: "⚠️ Violation Type",  value: violationType, inline: true },
          { name: "👤 Offender",         value: offender,      inline: true },
          { name: "📅 Week",             value: weekNumber,    inline: true },
          { name: "📝 Description",      value: rawDesc,       inline: false },
        )
        .setTimestamp()
        .setFooter({ text: `Violation ID: ${violationId}` });

      if (mediaUrls.length > 0) {
        reportEmbed.addFields({ name: "🖼️ Media", value: mediaUrls.join("\n"), inline: false });
        if (mediaUrls[0]) reportEmbed.setImage(mediaUrls[0]);
      }

      const btnRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId(`ac_rv_approve:${violationId}`)
          .setLabel("✅ Approve")
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId(`ac_rv_deny:${violationId}`)
          .setLabel("❌ Deny")
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId(`ac_rv_note:${interaction.user.id}`)
          .setLabel("📋 Add Note")
          .setStyle(ButtonStyle.Secondary),
      );

      const commMsg = await (channel as TextChannel).send({ embeds: [reportEmbed], components: [btnRow] }).catch(() => null);
      if (commMsg && violationId) {
        await db.update(ruleViolationsTable)
          .set({ commMessageId: commMsg.id })
          .where(eq(ruleViolationsTable.id, violationId));
      }
    }
  }

  await interaction.reply({
    ephemeral: true,
    embeds: [new EmbedBuilder()
      .setColor(Colors.Orange)
      .setTitle("🚨 Violation Report Submitted")
      .setDescription(`Your report against **${offender}** for **${violationType}** has been sent to the commissioners.\n\nThey will review it and take appropriate action.`)],
  });
}

async function handleViolationApprove(interaction: ButtonInteraction) {
  const violationId = parseInt(interaction.customId.split(":")[1] ?? "0", 10);
  if (!violationId) { await interaction.reply({ content: "❌ Invalid violation ID.", ephemeral: true }); return; }

  const gid = interaction.guildId!;
  const [violation] = await db.select().from(ruleViolationsTable)
    .where(and(eq(ruleViolationsTable.id, violationId), eq(ruleViolationsTable.guildId, gid)));
  if (!violation) { await interaction.reply({ content: "❌ Violation not found.", ephemeral: true }); return; }

  await db.update(ruleViolationsTable)
    .set({ status: "approved" })
    .where(eq(ruleViolationsTable.id, violationId));

  // Post to VIOLATION_LOG channel
  const logChannelId = await getGuildChannel(gid, CHANNEL_KEYS.VIOLATION_LOG)
    ?? await getGuildChannel(gid, CHANNEL_KEYS.COMMISSIONER_LOG)
    ?? await getGuildChannel(gid, CHANNEL_KEYS.COMMISSIONER);

  if (logChannelId) {
    const ch = await interaction.client.channels.fetch(logChannelId).catch(() => null);
    if (ch?.isTextBased()) {
      const approvedEmbed = new EmbedBuilder()
        .setColor(Colors.Green)
        .setTitle("✅ Violation Approved")
        .addFields(
          { name: "📝 Description", value: violation.description ?? "N/A", inline: false },
          { name: "👤 Offender",    value: violation.opponentTeam ?? "N/A", inline: true },
          { name: "📅 Week",        value: violation.weekNumber ?? "N/A",   inline: true },
          { name: "🔍 Reviewed by", value: `<@${interaction.user.id}>`,     inline: true },
        )
        .setTimestamp()
        .setFooter({ text: `Violation ID: ${violationId}` });

      if (violation.mediaUrls?.length) {
        approvedEmbed.addFields({ name: "🖼️ Media", value: violation.mediaUrls.join("\n"), inline: false });
        if (violation.mediaUrls[0]) approvedEmbed.setImage(violation.mediaUrls[0]);
      }
      await (ch as TextChannel).send({ embeds: [approvedEmbed] }).catch(console.error);
    }
  }

  // DM reporter
  if (violation.reporterId) {
    const reporter = await interaction.client.users.fetch(violation.reporterId).catch(() => null);
    if (reporter) {
      await reporter.send({
        embeds: [new EmbedBuilder()
          .setColor(Colors.Green)
          .setTitle("✅ Violation Report Approved")
          .setDescription(`Your violation report (ID: ${violationId}) has been **approved** by the commissioners.\n\nThank you for keeping the league fair.`)
          .setTimestamp()],
      }).catch(console.error);
    }
  }

  // Update the original commissioner message to show resolved state
  await interaction.update({
    components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId("ac_rv_noop")
          .setLabel("✅ Approved")
          .setStyle(ButtonStyle.Success)
          .setDisabled(true),
      ) as ActionRowBuilder<any>,
    ],
  });
}

async function handleViolationDeny(interaction: ButtonInteraction) {
  const violationId = interaction.customId.split(":")[1] ?? "0";
  const modal = new ModalBuilder()
    .setCustomId(`ac_rv_deny_submit:${violationId}`)
    .setTitle("Deny Violation Report")
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("reason")
          .setLabel("Reason for denial")
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(800)
          .setPlaceholder("Explain why the report is being denied…"),
      ),
    );
  await interaction.showModal(modal);
}

async function handleViolationDenySubmit(interaction: ModalSubmitInteraction) {
  const violationId = parseInt(interaction.customId.split(":")[1] ?? "0", 10);
  const reason      = interaction.fields.getTextInputValue("reason").trim();
  const gid         = interaction.guildId!;

  if (!violationId) { await interaction.reply({ content: "❌ Invalid violation ID.", ephemeral: true }); return; }

  const [violation] = await db.select().from(ruleViolationsTable)
    .where(and(eq(ruleViolationsTable.id, violationId), eq(ruleViolationsTable.guildId, gid)));
  if (!violation) { await interaction.reply({ content: "❌ Violation not found.", ephemeral: true }); return; }

  await db.update(ruleViolationsTable)
    .set({ status: "denied" })
    .where(eq(ruleViolationsTable.id, violationId));

  // DM reporter with deny reason
  if (violation.reporterId) {
    const reporter = await interaction.client.users.fetch(violation.reporterId).catch(() => null);
    if (reporter) {
      await reporter.send({
        embeds: [new EmbedBuilder()
          .setColor(Colors.Red)
          .setTitle("❌ Violation Report Denied")
          .setDescription(`Your violation report (ID: ${violationId}) has been **denied** by the commissioners.`)
          .addFields({ name: "📋 Reason", value: reason, inline: false })
          .setTimestamp()],
      }).catch(console.error);
    }
  }

  // Try to update the original commissioner message buttons
  try {
    const logChannelId = await getGuildChannel(gid, CHANNEL_KEYS.VIOLATION_LOG)
      ?? await getGuildChannel(gid, CHANNEL_KEYS.COMMISSIONER_LOG)
      ?? await getGuildChannel(gid, CHANNEL_KEYS.COMMISSIONER);
    if (logChannelId && violation.commMessageId) {
      const ch = await interaction.client.channels.fetch(logChannelId).catch(() => null);
      if (ch?.isTextBased()) {
        const msg = await (ch as TextChannel).messages.fetch(violation.commMessageId).catch(() => null);
        if (msg) {
          await msg.edit({
            components: [
              new ActionRowBuilder<ButtonBuilder>().addComponents(
                new ButtonBuilder()
                  .setCustomId("ac_rv_noop")
                  .setLabel("❌ Denied")
                  .setStyle(ButtonStyle.Danger)
                  .setDisabled(true),
              ) as ActionRowBuilder<any>,
            ],
          }).catch(console.error);
        }
      }
    }
  } catch { /* swallow */ }

  await interaction.reply({
    ephemeral: true,
    content: `✅ Violation #${violationId} has been denied and the reporter has been notified.`,
  });
}

async function handleViolationNote(interaction: ButtonInteraction) {
  const modal = new ModalBuilder()
    .setCustomId(`ac_rv_note_submit:${interaction.customId.split(":")[1]}`)
    .setTitle("Commissioner Note")
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("note")
          .setLabel("Commissioner note / ruling")
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(1000),
      ),
    );
  await interaction.showModal(modal);
}

// ═══════════════════════════════════════════════════════════════════════════════
//  ROW 5 — Rules (read-only view with optional public display)
// ═══════════════════════════════════════════════════════════════════════════════

async function handleRulesStart(interaction: ButtonInteraction, sess: ActionsSession) {
  const guildId  = interaction.guildId!;
  const sections = await getAllSections(guildId);
  const entries  = Object.entries(sections);

  if (entries.length === 0) {
    await interaction.update({
      embeds: [new EmbedBuilder().setColor(Colors.Orange).setTitle("📜 Rules").setDescription("No rule sections have been set up yet.")],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder().setCustomId("ac_rules_close").setLabel("✖ Close").setStyle(ButtonStyle.Secondary),
        ) as ActionRowBuilder<any>,
      ],
    });
    return;
  }

  const select = new StringSelectMenuBuilder()
    .setCustomId("ac_rules_section")
    .setPlaceholder("Select a rules section...")
    .addOptions(
      entries.slice(0, 25).map(([key, meta]) =>
        new StringSelectMenuOptionBuilder()
          .setLabel(meta.title.replace(/[\u{1F300}-\u{1FFFF}]/gu, "").trim() || key)
          .setValue(key),
      ),
    );

  const closeRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_rules_close").setLabel("✖ Close").setStyle(ButtonStyle.Secondary),
  );

  await interaction.update({
    embeds: [
      new EmbedBuilder()
        .setColor(0x3498db)
        .setTitle("📜 League Rules")
        .setDescription("Select a section to view the rules."),
    ],
    components: [
      new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select) as ActionRowBuilder<any>,
      closeRow,
    ],
  });
}

function buildRulesSectionEmbed(
  section: string,
  meta: { title: string; color: number },
  rules: string[],
  page: number,
): EmbedBuilder {
  const pages    = buildRulesPages(rules);
  const maxPage  = Math.max(0, pages.length - 1);
  const safePage = Math.min(Math.max(0, page), maxPage);
  const content  = pages[safePage] ?? "_No rules in this section yet._";
  const footer   = pages.length > 1
    ? `${rules.length} rule${rules.length !== 1 ? "s" : ""} · Page ${safePage + 1}/${pages.length}`
    : `${rules.length} rule${rules.length !== 1 ? "s" : ""}`;
  return new EmbedBuilder()
    .setColor(meta.color)
    .setTitle(meta.title)
    .setDescription(content)
    .setFooter({ text: footer });
}

function buildRulesSectionButtons(rules: string[], page: number, totalPages: number): ActionRowBuilder<ButtonBuilder>[] {
  const navRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_rules_display").setLabel("📢 Display Publicly").setStyle(ButtonStyle.Primary).setDisabled(rules.length === 0),
    new ButtonBuilder().setCustomId("ac_rules_goback").setLabel("← Sections").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_rules_close").setLabel("✖ Close").setStyle(ButtonStyle.Secondary),
  );
  if (totalPages <= 1) return [navRow];
  const pageRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId(`ac_rules_page:${page - 1}`).setLabel("◀ Prev").setStyle(ButtonStyle.Secondary).setDisabled(page <= 0),
    new ButtonBuilder().setCustomId(`ac_rules_page:${page + 1}`).setLabel("Next ▶").setStyle(ButtonStyle.Secondary).setDisabled(page >= totalPages - 1),
  );
  return [navRow, pageRow];
}

async function handleRulesSection(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const guildId = interaction.guildId!;
  const section = interaction.values[0]!;
  sess.acRulesSection = section;
  sess.acRulesPage    = 0;

  const sections = await getAllSections(guildId);
  const meta     = sections[section];
  if (!meta) {
    await interaction.update({ content: "❌ Section not found.", components: [] });
    return;
  }

  const rules      = await getOrSeedRules(section, guildId);
  const totalPages = buildRulesPages(rules).length;
  const embed      = buildRulesSectionEmbed(section, meta, rules, 0);

  await interaction.update({ embeds: [embed], components: buildRulesSectionButtons(rules, 0, totalPages) });
}

async function handleRulesPage(interaction: ButtonInteraction, sess: ActionsSession) {
  const guildId  = interaction.guildId!;
  const page     = parseInt(interaction.customId.split(":")[1] ?? "0", 10);
  const section  = sess.acRulesSection;

  if (!section) {
    await interaction.reply({ content: "❌ Session expired — open /menu again.", ephemeral: true });
    return;
  }

  const sections = await getAllSections(guildId);
  const meta     = sections[section];
  if (!meta) {
    await interaction.update({ content: "❌ Section not found.", components: [] });
    return;
  }

  const rules      = await getOrSeedRules(section, guildId);
  const totalPages = buildRulesPages(rules).length;
  const safePage   = Math.min(Math.max(0, page), Math.max(0, totalPages - 1));
  sess.acRulesPage = safePage;
  const embed      = buildRulesSectionEmbed(section, meta, rules, safePage);

  await interaction.update({ embeds: [embed], components: buildRulesSectionButtons(rules, safePage, totalPages) });
}

async function handleRulesDisplayChoice(interaction: ButtonInteraction, sess: ActionsSession) {
  if (!sess.acRulesSection) {
    await interaction.reply({ content: "❌ Session expired — open /menu again.", ephemeral: true });
    return;
  }

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_rules_display_full").setLabel("📋 Full Section").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ac_rules_display_bynum").setLabel("🔢 By Rule #").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId("ac_rules_goback").setLabel("← Back").setStyle(ButtonStyle.Secondary),
  );

  await interaction.update({
    embeds: [
      new EmbedBuilder()
        .setColor(0x3498db)
        .setTitle("📢 Display Rules")
        .setDescription("Choose how to display the rules publicly in this channel:"),
    ],
    components: [row],
  });
}

async function handleRulesDisplayFull(interaction: ButtonInteraction, sess: ActionsSession) {
  const guildId = interaction.guildId!;
  if (!sess.acRulesSection) {
    await interaction.reply({ content: "❌ Session expired — open /menu again.", ephemeral: true });
    return;
  }

  const sections = await getAllSections(guildId);
  const meta     = sections[sess.acRulesSection]!;
  const rules    = await getOrSeedRules(sess.acRulesSection, guildId);
  const lines    = rules.length > 0
    ? rules.map((r, i) => `**${i + 1}.** ${r}`)
    : ["_No rules in this section yet._"];

  const embed = new EmbedBuilder()
    .setColor(meta.color)
    .setTitle(meta.title)
    .setDescription(lines.join("\n\n"))
    .setTimestamp();

  await (interaction.channel as TextChannel | null)?.send({ embeds: [embed] }).catch(console.error);

  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.Green).setDescription("✅ Rules posted to the channel.")],
    components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_rules_goback").setLabel("← Sections").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_rules_close").setLabel("✖ Close").setStyle(ButtonStyle.Secondary),
      ) as ActionRowBuilder<any>,
    ],
  });
}

async function handleRulesDisplayByNumModal(interaction: ButtonInteraction, _sess: ActionsSession) {
  const modal = new ModalBuilder()
    .setCustomId("ac_modal_rules_bynum")
    .setTitle("Display Rule by Number");

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId("rule_num")
        .setLabel("Rule Number")
        .setStyle(TextInputStyle.Short)
        .setPlaceholder("e.g. 3")
        .setRequired(true)
        .setMinLength(1)
        .setMaxLength(3),
    ),
  );

  await interaction.showModal(modal);
}

async function handleRulesByNumSubmit(interaction: ModalSubmitInteraction, sess: ActionsSession) {
  const guildId = interaction.guildId!;
  if (!sess.acRulesSection) {
    await interaction.reply({ content: "❌ Session expired — open /menu again.", ephemeral: true });
    return;
  }

  const ruleNum = parseInt(interaction.fields.getTextInputValue("rule_num"), 10);
  if (isNaN(ruleNum) || ruleNum < 1) {
    await interaction.reply({ content: "❌ Invalid rule number.", ephemeral: true });
    return;
  }

  const sections = await getAllSections(guildId);
  const meta     = sections[sess.acRulesSection]!;
  const rules    = await getOrSeedRules(sess.acRulesSection, guildId);

  if (ruleNum > rules.length) {
    await interaction.reply({ content: `❌ Rule #${ruleNum} does not exist. This section has ${rules.length} rule(s).`, ephemeral: true });
    return;
  }

  const embed = new EmbedBuilder()
    .setColor(meta.color)
    .setTitle(`${meta.title} — Rule #${ruleNum}`)
    .setDescription(rules[ruleNum - 1]!)
    .setTimestamp();

  await (interaction.channel as TextChannel | null)?.send({ embeds: [embed] }).catch(console.error);

  await interaction.reply({
    embeds: [new EmbedBuilder().setColor(Colors.Green).setDescription(`✅ Rule #${ruleNum} posted to the channel.`)],
    ephemeral: true,
  });
}

async function handleRulesClose(interaction: ButtonInteraction) {
  await interaction.update({
    embeds: [new EmbedBuilder().setColor(Colors.DarkGrey).setDescription("📜 Rules closed.")],
    components: [],
  });
}

// ═══════════════════════════════════════════════════════════════════════════════
//  UNLINKED USER — Request handlers
// ═══════════════════════════════════════════════════════════════════════════════

// ── Helpers: build open-team and all-team dual dropdowns ─────────────────────

function buildOpenTeamSelectRows(
  afcOpen: string[],
  nfcOpen: string[],
  selected?: string,
): ActionRowBuilder<StringSelectMenuBuilder>[] {
  const rows: ActionRowBuilder<StringSelectMenuBuilder>[] = [];

  if (afcOpen.length) {
    const menu = new StringSelectMenuBuilder()
      .setCustomId("ac_req_openteam_sel_afc")
      .setPlaceholder("🔵 AFC — Pick an open team")
      .addOptions(afcOpen.map(t =>
        new StringSelectMenuOptionBuilder().setLabel(t).setValue(t).setDefault(t === selected),
      ));
    rows.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu));
  }

  if (nfcOpen.length) {
    const menu = new StringSelectMenuBuilder()
      .setCustomId("ac_req_openteam_sel_nfc")
      .setPlaceholder("🔴 NFC — Pick an open team")
      .addOptions(nfcOpen.map(t =>
        new StringSelectMenuOptionBuilder().setLabel(t).setValue(t).setDefault(t === selected),
      ));
    rows.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu));
  }

  return rows;
}

function buildAllTeamSelectRows(
  selected?: string,
): ActionRowBuilder<StringSelectMenuBuilder>[] {
  const afc = NFL_TEAMS.filter(t => NFL_DIVISION_MAP[t]?.conference === "AFC").sort();
  const nfc = NFL_TEAMS.filter(t => NFL_DIVISION_MAP[t]?.conference === "NFC").sort();

  const rows: ActionRowBuilder<StringSelectMenuBuilder>[] = [];

  const afcMenu = new StringSelectMenuBuilder()
    .setCustomId("ac_req_waitlist_sel_afc")
    .setPlaceholder("🔵 AFC — Pick your target team")
    .addOptions(afc.map(t =>
      new StringSelectMenuOptionBuilder().setLabel(t).setValue(t).setDefault(t === selected),
    ));
  rows.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(afcMenu));

  const nfcMenu = new StringSelectMenuBuilder()
    .setCustomId("ac_req_waitlist_sel_nfc")
    .setPlaceholder("🔴 NFC — Pick your target team")
    .addOptions(nfc.map(t =>
      new StringSelectMenuOptionBuilder().setLabel(t).setValue(t).setDefault(t === selected),
    ));
  rows.push(new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(nfcMenu));

  return rows;
}

// ── Shared helper: resolve currently taken teams from usersTable ───────────────
async function getTakenTeams(gid: string): Promise<Set<string>> {
  const takenRows = await db.select({ team: usersTable.team, discordId: usersTable.discordId })
    .from(usersTable)
    .where(and(eq(usersTable.guildId, gid), isNotNull(usersTable.team)));

  // usersTable.team is always canonical (NFL_TEAMS name set by admin on link).
  // MCA nickNames like "Bolts", "Jags", "G-Men", "Niners", "Pack", "Pats" do NOT
  // match NFL_TEAMS, so we rely on usersTable — not MCA — as the source of truth.
  const taken = new Set<string>();
  for (const r of takenRows) {
    if (!r.discordId || r.discordId.startsWith("unlinked_")) continue;
    if (r.team) taken.add(r.team);
  }
  return taken;
}

// ── Request Open Team: step 1 — show dual dropdowns with open teams ───────────

async function handleReqOpenTeam(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  await interaction.deferUpdate();

  sess.pendingTeamRequest = undefined;

  const taken = await getTakenTeams(gid);
  const open     = NFL_TEAMS.filter(t => !taken.has(t));
  const afcOpen  = open.filter(t => NFL_DIVISION_MAP[t]?.conference === "AFC").sort();
  const nfcOpen  = open.filter(t => NFL_DIVISION_MAP[t]?.conference === "NFC").sort();

  if (!open.length) {
    await interaction.editReply({
      embeds: [new EmbedBuilder()
        .setColor(Colors.Grey)
        .setTitle("🔴 No Open Teams")
        .setDescription("All 32 teams are currently claimed. You can add yourself to the waitlist instead.")],
      components: [backToHubRow()],
    });
    return;
  }

  const selectRows = buildOpenTeamSelectRows(afcOpen, nfcOpen);
  const actionRow  = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_req_openteam_submit").setLabel("✅ Submit Request").setStyle(ButtonStyle.Success).setDisabled(true),
    new ButtonBuilder().setCustomId("ac_hub").setLabel("✖ Close").setStyle(ButtonStyle.Secondary),
  ) as ActionRowBuilder<any>;

  const embed = new EmbedBuilder()
    .setColor(Colors.Blue)
    .setTitle("🏈 Request an Open Team")
    .setDescription("Pick a team from either dropdown below, then click **Submit Request**.\n\n⚠️ You may only select **one team**. Selecting from one conference clears the other.");

  await interaction.editReply({ embeds: [embed], components: [...selectRows, actionRow] });
}

// ── Request Open Team: step 2 — user selects a team ─────────────────────────

async function handleReqOpenTeamSel(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const gid  = interaction.guildId!;
  const team = interaction.values[0]!;
  await interaction.deferUpdate();

  sess.pendingTeamRequest = team;

  const taken   = await getTakenTeams(gid);
  const open    = NFL_TEAMS.filter(t => !taken.has(t));
  const afcOpen = open.filter(t => NFL_DIVISION_MAP[t]?.conference === "AFC").sort();
  const nfcOpen = open.filter(t => NFL_DIVISION_MAP[t]?.conference === "NFC").sort();

  const selectRows = buildOpenTeamSelectRows(afcOpen, nfcOpen, team);
  const actionRow  = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_req_openteam_submit").setLabel("✅ Submit Request").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("ac_hub").setLabel("✖ Close").setStyle(ButtonStyle.Secondary),
  ) as ActionRowBuilder<any>;

  const embed = new EmbedBuilder()
    .setColor(Colors.Blue)
    .setTitle("🏈 Request an Open Team")
    .setDescription(`Pick a team from either dropdown below, then click **Submit Request**.\n\n✅ **Selected:** ${team}\n\nClick **Submit Request** to send your request to the commissioner.`);

  await interaction.editReply({ embeds: [embed], components: [...selectRows, actionRow] });
}

// ── Request Open Team: step 3 — submit to commissioner log ───────────────────

async function handleReqOpenTeamSubmit(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid  = interaction.guildId!;
  const uid  = interaction.user.id;
  const team = sess.pendingTeamRequest;
  await interaction.deferUpdate();

  if (!team) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(Colors.Red).setTitle("❌ No Team Selected").setDescription("Please select a team from the dropdown first.")],
      components: [backToHubRow()],
    });
    return;
  }

  // Verify team is still open at submit time
  const taken = await getTakenTeams(gid);
  if (taken.has(team)) {
    await interaction.editReply({
      embeds: [new EmbedBuilder()
        .setColor(Colors.Orange)
        .setTitle("⚠️ Team No Longer Available")
        .setDescription(`The **${team}** were claimed since you started browsing. Please go back and pick another team.`)],
      components: [backToHubRow()],
    });
    return;
  }

  const logChannelId = await getGuildChannel(gid, CHANNEL_KEYS.COMMISSIONER_LOG)
    ?? await getGuildChannel(gid, CHANNEL_KEYS.COMMISSIONER);

  if (logChannelId) {
    const channel = await interaction.client.channels.fetch(logChannelId).catch(() => null);
    if (channel?.isTextBased()) {
      await (channel as TextChannel).send({
        embeds: [new EmbedBuilder()
          .setColor(Colors.Yellow)
          .setTitle("🔔 Open Team Request")
          .setDescription(`<@${uid}> has requested an open team.`)
          .addFields({ name: "🏈 Team Requested", value: team, inline: true })
          .setTimestamp()],
        components: [
          new ActionRowBuilder<ButtonBuilder>().addComponents(
            new ButtonBuilder()
              .setCustomId(`treq_link|${uid}|${team}`)
              .setLabel("🔗 Link User")
              .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
              .setCustomId(`treq_deny|${uid}|${team}`)
              .setLabel("❌ Deny Request")
              .setStyle(ButtonStyle.Danger),
          ),
        ],
      }).catch(console.error);
    }
  }

  sess.pendingTeamRequest = undefined;

  await interaction.editReply({
    embeds: [new EmbedBuilder()
      .setColor(Colors.Green)
      .setTitle("✅ Request Submitted")
      .setDescription(`Your request for the **${team}** has been sent to the commissioner. You'll be notified once a decision is made.`)],
    components: [backToHubRow()],
  });
}

// ── Add to Waitlist: step 1 — show dual dropdowns with ALL teams ──────────────

async function handleReqAddWaitlist(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  const uid = interaction.user.id;
  await interaction.deferUpdate();

  // Check if already on waitlist
  const [existing] = await db.select({ id: waitlistTable.id, status: waitlistTable.status, team: waitlistTable.team })
    .from(waitlistTable)
    .where(and(eq(waitlistTable.guildId, gid), eq(waitlistTable.discordId, uid)));

  if (existing) {
    const teamInfo = existing.team ? ` for the **${existing.team}**` : "";
    await interaction.editReply({
      embeds: [new EmbedBuilder()
        .setColor(Colors.Yellow)
        .setTitle("⚠️ Already on Waitlist")
        .setDescription(`You're already on the waitlist${teamInfo} (status: **${existing.status}**).\n\nUse **Remove from Waitlist** if you'd like to change your team preference.`)],
      components: [backToHubRow()],
    });
    return;
  }

  sess.pendingTeamRequest = undefined;

  const selectRows = buildAllTeamSelectRows();
  const actionRow  = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_req_waitlist_next").setLabel("📋 Add to Waitlist").setStyle(ButtonStyle.Primary).setDisabled(true),
    new ButtonBuilder().setCustomId("ac_hub").setLabel("✖ Close").setStyle(ButtonStyle.Secondary),
  ) as ActionRowBuilder<any>;

  const embed = new EmbedBuilder()
    .setColor(Colors.Blue)
    .setTitle("📋 Add to Waitlist")
    .setDescription(
      "Pick the **specific team** you want to waitlist for, then click **Add to Waitlist**.\n\n" +
      "If that team is already open, you'll be redirected to Request it directly.\n" +
      "If it's taken, you'll be added to the waitlist and notified when they become available.",
    );

  await interaction.editReply({ embeds: [embed], components: [...selectRows, actionRow] });
}

// ── Add to Waitlist: step 2 — user selects their target team ─────────────────

async function handleReqWaitlistSel(interaction: StringSelectMenuInteraction, sess: ActionsSession) {
  const team = interaction.values[0]!;
  await interaction.deferUpdate();

  sess.pendingTeamRequest = team;

  const selectRows = buildAllTeamSelectRows(team);
  const actionRow  = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_req_waitlist_next").setLabel("📋 Add to Waitlist").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("ac_hub").setLabel("✖ Close").setStyle(ButtonStyle.Secondary),
  ) as ActionRowBuilder<any>;

  const embed = new EmbedBuilder()
    .setColor(Colors.Blue)
    .setTitle("📋 Add to Waitlist")
    .setDescription(
      "Pick the **specific team** you want to waitlist for, then click **Add to Waitlist**.\n\n" +
      `✅ **Selected:** ${team}\n\nClick **Add to Waitlist** to continue.`,
    );

  await interaction.editReply({ embeds: [embed], components: [...selectRows, actionRow] });
}

// ── Add to Waitlist: step 3 — check open/taken and act ───────────────────────

async function handleReqWaitlistNext(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid  = interaction.guildId!;
  const uid  = interaction.user.id;
  const team = sess.pendingTeamRequest;
  await interaction.deferUpdate();

  if (!team) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(Colors.Red).setTitle("❌ No Team Selected").setDescription("Please select a team from the dropdown first.")],
      components: [backToHubRow()],
    });
    return;
  }

  // Check if team is open or taken
  const taken = await getTakenTeams(gid);

  if (!taken.has(team)) {
    // Team is open — redirect to Request Open Team flow
    await interaction.editReply({
      embeds: [new EmbedBuilder()
        .setColor(Colors.Yellow)
        .setTitle("🟢 Team Is Open!")
        .setDescription(`The **${team}** are actually available right now! Use **Request Open Team** to claim them directly instead of waiting.`)],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder().setCustomId("ac_req_openteam").setLabel("🏈 Request Open Team").setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId("ac_hub").setLabel("← Back").setStyle(ButtonStyle.Secondary),
        ) as ActionRowBuilder<any>,
      ],
    });
    return;
  }

  // Team is taken — add to waitlist
  const [existing] = await db.select({ id: waitlistTable.id })
    .from(waitlistTable)
    .where(and(eq(waitlistTable.guildId, gid), eq(waitlistTable.discordId, uid)));

  if (existing) {
    await interaction.editReply({
      embeds: [new EmbedBuilder()
        .setColor(Colors.Yellow)
        .setTitle("⚠️ Already on Waitlist")
        .setDescription("You're already on the waitlist. Use **Remove from Waitlist** first if you want to change your team preference.")],
      components: [backToHubRow()],
    });
    return;
  }

  await db.insert(waitlistTable).values({ guildId: gid, discordId: uid, addedBy: uid, team, status: "waiting" });

  // Notify commissioner
  const logChannelId = await getGuildChannel(gid, CHANNEL_KEYS.COMMISSIONER_LOG)
    ?? await getGuildChannel(gid, CHANNEL_KEYS.COMMISSIONER);
  if (logChannelId) {
    const channel = await interaction.client.channels.fetch(logChannelId).catch(() => null);
    if (channel?.isTextBased()) {
      await (channel as TextChannel).send({
        embeds: [new EmbedBuilder()
          .setColor(Colors.Blue)
          .setTitle("📋 Waitlist Request")
          .setDescription(`<@${uid}> has added themselves to the waitlist for the **${team}**.`)
          .setTimestamp()],
      }).catch(console.error);
    }
  }

  sess.pendingTeamRequest = undefined;

  await interaction.editReply({
    embeds: [new EmbedBuilder()
      .setColor(Colors.Green)
      .setTitle("✅ Added to Waitlist")
      .setDescription(`You've been added to the waitlist for the **${team}**!\n\nYou'll receive a DM when the ${team} become available. The commissioner has also been notified.`)],
    components: [backToHubRow()],
  });
}

// ── Remove from Waitlist: confirm step ───────────────────────────────────────

async function handleReqRmWaitlist(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  const uid = interaction.user.id;
  await interaction.deferUpdate();

  const [existing] = await db.select({ id: waitlistTable.id, status: waitlistTable.status, team: waitlistTable.team })
    .from(waitlistTable)
    .where(and(eq(waitlistTable.guildId, gid), eq(waitlistTable.discordId, uid)));

  if (!existing) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(Colors.Grey).setTitle("ℹ️ Not on Waitlist").setDescription("You are not currently on the waitlist.")],
      components: [backToHubRow()],
    });
    return;
  }

  const teamInfo = existing.team ? ` for the **${existing.team}**` : "";

  const confirmRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder().setCustomId("ac_req_rmwl_confirm").setLabel("✅ Yes, Remove Me").setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId("ac_hub").setLabel("← Cancel").setStyle(ButtonStyle.Secondary),
  ) as ActionRowBuilder<any>;

  await interaction.editReply({
    embeds: [new EmbedBuilder()
      .setColor(Colors.Yellow)
      .setTitle("⚠️ Confirm Waitlist Removal")
      .setDescription(`You are currently on the waitlist${teamInfo} (status: **${existing.status}**).\n\nAre you sure you want to remove yourself?`)],
    components: [confirmRow],
  });
}

async function handleReqRmWaitlistConfirm(interaction: ButtonInteraction, sess: ActionsSession) {
  const gid = interaction.guildId!;
  const uid = interaction.user.id;
  await interaction.deferUpdate();

  const [existing] = await db.select({ team: waitlistTable.team })
    .from(waitlistTable)
    .where(and(eq(waitlistTable.guildId, gid), eq(waitlistTable.discordId, uid)));

  await db.delete(waitlistTable).where(and(eq(waitlistTable.guildId, gid), eq(waitlistTable.discordId, uid)));

  const teamInfo = existing?.team ? ` (${existing.team})` : "";

  const logChannelId = await getGuildChannel(gid, CHANNEL_KEYS.COMMISSIONER_LOG)
    ?? await getGuildChannel(gid, CHANNEL_KEYS.COMMISSIONER);
  if (logChannelId) {
    const channel = await interaction.client.channels.fetch(logChannelId).catch(() => null);
    if (channel?.isTextBased()) {
      await (channel as TextChannel).send({
        embeds: [new EmbedBuilder()
          .setColor(Colors.Grey)
          .setTitle("📋 Waitlist Removal")
          .setDescription(`<@${uid}> has removed themselves from the waitlist${teamInfo}.`)
          .setTimestamp()],
      }).catch(console.error);
    }
  }

  await interaction.editReply({
    embeds: [new EmbedBuilder()
      .setColor(Colors.Green)
      .setTitle("✅ Removed from Waitlist")
      .setDescription("You've been removed from the waitlist. You can re-add yourself at any time.")],
    components: [backToHubRow()],
  });
}

// ── Season Schedule ────────────────────────────────────────────────────────────

async function handleSchedule(interaction: ButtonInteraction, sess: ActionsSession) {
  await interaction.deferUpdate();

  const guildId = sess.guildId;
  const userId  = sess.userId;

  const MIN_COMPLETED_STATUS = 2;

  const user = await getOrCreateUser(userId, interaction.user.username, guildId);

  if (!user.team) {
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(Colors.Orange).setTitle("📅 Season Schedule").setDescription("❌ You don't have a registered team. Ask the commissioner to set you up.")],
      components: [backToHubRow() as ActionRowBuilder<any>],
    });
    return;
  }

  const season           = await getOrCreateActiveSeason(guildId);
  const scheduleSeasonId = await getScheduleSeasonId(guildId);

  // Use scheduleSeasonId for the MCA lookup so team names are consistent with
  // the schedule data — e.g. if the active season has no schedule yet, both
  // the MCA entry and the schedule rows come from the same prior season.
  const [mcaEntry] = await db
    .select({ fullName: franchiseMcaTeamsTable.fullName, nickName: franchiseMcaTeamsTable.nickName })
    .from(franchiseMcaTeamsTable)
    .where(and(
      eq(franchiseMcaTeamsTable.seasonId,  scheduleSeasonId),
      eq(franchiseMcaTeamsTable.discordId, userId),
    ))
    .limit(1);

  const candidateNames: string[] = [];
  if (mcaEntry?.fullName) candidateNames.push(mcaEntry.fullName.toLowerCase().trim());
  if (mcaEntry?.nickName) candidateNames.push(mcaEntry.nickName.toLowerCase().trim());
  if (user.team)          candidateNames.push(user.team.toLowerCase().trim());

  const uniqueNames = [...new Set(candidateNames)];

  const nameConditions = uniqueNames.flatMap(name => [
    sql`lower(${franchiseScheduleTable.homeTeamName}) = ${name}`,
    sql`lower(${franchiseScheduleTable.awayTeamName}) = ${name}`,
  ]);

  const allGames = await db
    .select()
    .from(franchiseScheduleTable)
    .where(and(
      eq(franchiseScheduleTable.seasonId, scheduleSeasonId),
      or(...nameConditions),
    ))
    .orderBy(asc(franchiseScheduleTable.weekIndex));

  const regularGames = allGames.filter(g => g.weekIndex >= 0 && g.weekIndex <= 17);

  // Resolve the season number to display — may differ from the active season
  // when scheduleSeasonId falls back to a prior season's data.
  let displaySeasonNumber = season.seasonNumber;
  if (scheduleSeasonId !== season.id) {
    const [altSeason] = await db.select({ seasonNumber: seasonsTable.seasonNumber })
      .from(seasonsTable).where(eq(seasonsTable.id, scheduleSeasonId)).limit(1);
    if (altSeason) displaySeasonNumber = altSeason.seasonNumber;
  }

  if (regularGames.length === 0) {
    const teamDisplay = mcaEntry?.fullName ?? user.team;
    await interaction.editReply({
      embeds: [new EmbedBuilder().setColor(Colors.Orange).setTitle("📅 Season Schedule").setDescription(`📭 No schedule data found for **${teamDisplay}** in Season ${displaySeasonNumber}. Make sure the full season schedule has been imported.`)],
      components: [backToHubRow() as ActionRowBuilder<any>],
    });
    return;
  }

  const scheduleTeamName = regularGames[0]
    ? (uniqueNames.find(n =>
        regularGames[0]!.homeTeamName.toLowerCase().trim() === n ||
        regularGames[0]!.awayTeamName.toLowerCase().trim() === n
      ) ?? uniqueNames[0]!)
    : uniqueNames[0]!;

  const played = regularGames.filter(g => g.status >= MIN_COMPLETED_STATUS).length;

  const lines = regularGames.map(g => {
    const isHome   = g.homeTeamName.toLowerCase().trim() === scheduleTeamName;
    const opponent = isHome ? g.awayTeamName : g.homeTeamName;
    const location = isHome ? "vs" : "@";
    const myScore  = isHome ? g.homeScore : g.awayScore;
    const oppScore = isHome ? g.awayScore : g.homeScore;
    const weekNum  = g.weekIndex + 1;

    if (g.status >= MIN_COMPLETED_STATUS && myScore !== null && oppScore !== null) {
      const tied  = myScore === oppScore;
      const won   = myScore > oppScore;
      const label = tied ? "T" : (won ? "W" : "L");
      const emoji = tied ? "🤝" : (won ? "✅" : "❌");
      return `**Wk ${weekNum}** ${location} ${opponent} — ${emoji} **${label}** (${myScore}–${oppScore})`;
    }
    return `**Wk ${weekNum}** ${location} ${opponent} — ⏳ Upcoming`;
  });

  const description = lines.join("\n");
  const displayName = mcaEntry?.fullName ?? user.team ?? "Your Team";

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setColor(Colors.Blue)
        .setTitle(`📅 ${displayName} — Season ${displaySeasonNumber} Schedule`)
        .setDescription(description.length > 4000 ? description.slice(0, 3997) + "..." : description)
        .setFooter({ text: `${played} of ${regularGames.length} games played` })
        .setTimestamp(),
    ],
    components: [
      new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder().setCustomId("ac_hub").setLabel("← Back to Hub").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("ac_close").setLabel("✖ Close").setStyle(ButtonStyle.Danger),
      ) as ActionRowBuilder<any>,
    ],
  });
}
